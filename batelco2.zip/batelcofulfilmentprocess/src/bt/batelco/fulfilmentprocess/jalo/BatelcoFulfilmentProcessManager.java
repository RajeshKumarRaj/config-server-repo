package bt.batelco.fulfilmentprocess.jalo;

import bt.batelco.fulfilmentprocess.constants.BatelcoFulfilmentProcessConstants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.extension.ExtensionManager;
import org.apache.log4j.Logger;

@SuppressWarnings("PMD")
public class BatelcoFulfilmentProcessManager extends GeneratedBatelcoFulfilmentProcessManager
{
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger( BatelcoFulfilmentProcessManager.class.getName() );
	
	public static final BatelcoFulfilmentProcessManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (BatelcoFulfilmentProcessManager) em.getExtension(BatelcoFulfilmentProcessConstants.EXTENSIONNAME);
	}
	
}
