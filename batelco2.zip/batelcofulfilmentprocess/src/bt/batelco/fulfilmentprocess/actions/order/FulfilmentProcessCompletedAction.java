/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.fulfilmentprocess.actions.order;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;
import de.hybris.platform.processengine.action.AbstractAction;
import de.hybris.platform.servicelayer.event.EventService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.HashSet;
import java.util.Set;

import bt.batelco.core.event.OrderStatusChangedEvent;


/**
 * Send event representing the completion of an order process.
 */
public class FulfilmentProcessCompletedAction extends AbstractAction<OrderProcessModel> {
    private static final Logger LOG = Logger.getLogger(FulfilmentProcessCompletedAction.class);

    private EventService eventService;

    @Override
    public String execute(final OrderProcessModel process) {
        getEventService().publishEvent(new OrderStatusChangedEvent(process.getOrder()));
        OrderStatus orderStatus = process.getOrder().getStatus();
        if (LOG.isInfoEnabled()) {
            LOG.info("Process: " + process.getCode() + " in step " + getClass() + " with order status: " + orderStatus.getCode());
        }

        if(OrderStatus.PREORDER_COMPLETED == orderStatus) {
          return Transition.PREORDER_COMPLETED.toString();
        }
        if(OrderStatus.COMPLETED == orderStatus) {
          return Transition.COMPLETED.toString();
        }

        return Transition.CANCELED.toString();
    }

    @Override
    public Set<String> getTransitions() {
        return FulfilmentProcessCompletedAction.Transition.getStringValues();
    }

    public enum Transition {
        COMPLETED,
        PREORDER_COMPLETED,
        CANCELED;

        Transition() {
        }

        public static Set<String> getStringValues() {
            Set<String> values = new HashSet<>();
            FulfilmentProcessCompletedAction.Transition[] transitions = values();
            for (Transition transition : transitions) {
                values.add(transition.toString());
            }
            return values;
        }
    }

    protected EventService getEventService() {
        return eventService;
    }

    @Required
    public void setEventService(final EventService eventService) {
        this.eventService = eventService;
    }
}
