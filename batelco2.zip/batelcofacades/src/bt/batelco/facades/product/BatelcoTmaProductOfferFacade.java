package bt.batelco.facades.product;

import de.hybris.platform.b2ctelcofacades.product.TmaProductOfferFacade;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;

/**
 * Facade that handles operations related to {@link TmaProductOfferingModel} and Batelco specific logic.
 */
public interface BatelcoTmaProductOfferFacade extends TmaProductOfferFacade {

  /**
   * Get canonical link for product model
   *
   * @param productModel product model
   * @return canonical link or <code>null</code> if product is not variant
   */
  String getCanonicalLink(TmaProductOfferingModel productModel);
}
