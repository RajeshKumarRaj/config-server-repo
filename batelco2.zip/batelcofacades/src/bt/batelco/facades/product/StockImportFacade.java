package bt.batelco.facades.product;

import de.hybris.platform.stock.StockService;

import java.util.List;

/**
 * Interface for dealing with stock import
 */
public interface StockImportFacade {

  /**
   * Import a stock value by calling the {@link StockService}.
   *
   * @param lines - list of values to be imported
   * @return number of lines that were not imported
   */
  int performImport(List<String> lines);

}
