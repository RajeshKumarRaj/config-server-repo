package bt.batelco.facades.product.impl;

import com.sun.xml.internal.txw2.output.IndentingXMLStreamWriter;
import de.hybris.platform.acceleratorservices.urlresolver.SiteBaseUrlResolutionService;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.catalog.enums.ArticleApprovalStatus;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.converters.Converters;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.site.BaseSiteService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import bt.batelco.facades.product.BatelcoExportProductFacade;
import bt.batelco.facades.product.dto.Channel;
import bt.batelco.facades.product.dto.ExportProductDTO;

public class DefaultBatelcoExportProductFacade implements BatelcoExportProductFacade {

    private static final Logger LOG = Logger.getLogger(DefaultBatelcoExportProductFacade.class);
    private  static final String BASESITE_UID ="batelco";
    private  static final String PATH ="";
    private static final String BATELCO_ESHOP_TITLE = "Batelco eShop" ;
    private static final String BATELCO_DESCRIPTION = "Welcome to Batelco eShop";
    private static final String NAME_SPACE_URI = "http://base.google.com/ns/1.0";
    private static final String PREFIX = "g";
    private static final String VERSION = "version";
    private static final String TAG_RSS = "rss";
    private static final String VERSION_ID = "2.0";
    private static final String FILE_NAME = "Batelco-FaceBook-ProductFeed.xml";
    private static final String XML_TAG = "<?xml version='1.0' encoding='UTF-8'?>";
    private static final String FB_XML_TAG =  "<?xml version=\"1.0\"?>";

    private Converter<ProductModel, ExportProductDTO> exportProductConverter;
    private SiteBaseUrlResolutionService siteBaseUrlResolutionService;
    private BaseSiteService baseSiteService;
    private MediaService mediaService;
    private ModelService modelService;
    private ProductService productService;

    /**
     * Generates product feed for Facebook and persists the feed file as Media in Hybris
     * @param mediaModel
     *    Media model
     * @param catalogVersion
     *      Catalog version considered for product fetching
     * @throws Exception
     *          Exception
     */
    @Override
    public void performProductExport(MediaModel mediaModel,CatalogVersionModel catalogVersion) throws Exception {

        try {
            List<ProductModel>  allProducts = getProductService().getAllProductsForCatalogVersion(catalogVersion);
            List<ProductModel>  productsForExport = filterOutInvalidProducts(allProducts);
            LOG.info("Size of products collection to export:"+productsForExport.size());
            List<ExportProductDTO> exportProductDTOS = Converters.convertAll(productsForExport,exportProductConverter);
            Channel channel= getChannel(exportProductDTOS);
            marshalProdutFeedAndSaveFile(channel,mediaModel);
        } catch (Exception e) {
            throw new Exception(e.getMessage(),e);
        }
    }


    /**
     * Filtering the collection [filters out BaseProducts, unapproved, check] to consider only TmaSPO, TmaPOVariant
     * @param allProducts
     *       Collection of products got from DB
     * @return
     *     returns collection of Products
     */
    private List<ProductModel> filterOutInvalidProducts(List<ProductModel> allProducts) {

        if(CollectionUtils.isNotEmpty(allProducts)){
            allProducts = allProducts.stream()
            .filter(product -> product.getApprovalStatus().equals(ArticleApprovalStatus.APPROVED))
            .filter(product -> !(product instanceof TmaBundledProductOfferingModel))
                    .collect(Collectors.toList());

            Set<ProductModel> baseProductsCollection = allProducts.stream()
                    .filter(product -> product instanceof TmaPoVariantModel && ((TmaPoVariantModel)product).getTmaBasePo()!=null)
                    .map(product->((TmaPoVariantModel)product).getTmaBasePo()).collect(Collectors.toSet());

            if(CollectionUtils.isNotEmpty(baseProductsCollection)){
                allProducts = (List<ProductModel>) CollectionUtils.removeAll(allProducts,baseProductsCollection);
            }
        }

        return allProducts;
    }

    /**
     *  Generate and persist the batelco facebook product feed xml in hybris as Media
     * @param channel
     *      Channel DTO
     * @param mediaModel
     *    Hybris MediaModel holding batelco facebook product feed File
     * @throws Exception
     *          Exception
     */
    private void marshalProdutFeedAndSaveFile(Channel channel, MediaModel mediaModel) throws Exception {

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try
        {
            JAXBContext jaxbContext = JAXBContext.newInstance(Channel.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
            XMLStreamWriter writer = new IndentingXMLStreamWriter(XMLOutputFactory.newInstance().createXMLStreamWriter(byteArrayOutputStream));
            writer.writeStartDocument();
            writer.writeStartElement(TAG_RSS);
            writer.writeNamespace(PREFIX, NAME_SPACE_URI);
            writer.writeAttribute(VERSION, VERSION_ID);
            jaxbMarshaller.marshal(channel, writer);
            writer.writeCharacters("\n");
            writer.writeEndElement();
            writer.writeEndDocument();
            writer.flush();
            writer.close();
            byteArrayOutputStream.close();
            saveFile(mediaModel, byteArrayOutputStream.toByteArray());
        } catch (IOException | JAXBException | XMLStreamException e) {
            throw new Exception(e.getMessage(),e);
        } finally
        {
            byteArrayOutputStream.close();
        }
    }

    /**
     * Saving the Feed to Media i Hybris
     * @param mediaModel
     *          MediaModel
     * @param dataBytes
     *          Bytes
     */
    private void saveFile(MediaModel mediaModel, byte[] dataBytes){
        String mediaString = new String(dataBytes, StandardCharsets.UTF_8);
        if(StringUtils.containsIgnoreCase(mediaString,XML_TAG)){
            mediaString = StringUtils.replace(mediaString,XML_TAG, FB_XML_TAG);
        }
        if(LOG.isDebugEnabled()){
            LOG.debug("mediaString:" +mediaString);
        }
        mediaModel.setRealFileName(FILE_NAME);
        getMediaService().setDataForMedia(mediaModel,mediaString.getBytes());
        getModelService().save(mediaModel);
        if(LOG.isDebugEnabled()){
            byte[] mediaDataBytes = getMediaService().getDataFromMedia(mediaModel);
            String stringContent = new String(dataBytes, StandardCharsets.UTF_8);
            LOG.debug("stringContent:" +stringContent);
        }
    }

    /**
     *  Populates the Channel and returns Channel instance
     * @param exportProductDTOS
     *          List of productDTO
     * @return
     *      return Channel
     */
    private Channel getChannel(List<ExportProductDTO> exportProductDTOS) {
        Channel channel = new Channel();
        channel.setTitle(BATELCO_ESHOP_TITLE);
        channel.setDescription(BATELCO_DESCRIPTION);
        channel.setLink(siteBaseUrlResolutionService.getWebsiteUrlForSite(getBaseSite(),Boolean.TRUE,PATH));
        channel.setProducts(exportProductDTOS);
        return channel;
    }

    private BaseSiteModel getBaseSite(){
        return baseSiteService.getBaseSiteForUID(BASESITE_UID);
    }

    @Required
    public void setExportProductConverter(Converter<ProductModel, ExportProductDTO> exportProductConverter) {
        this.exportProductConverter = exportProductConverter;
    }

    @Required
    public void setSiteBaseUrlResolutionService(SiteBaseUrlResolutionService siteBaseUrlResolutionService) {
        this.siteBaseUrlResolutionService = siteBaseUrlResolutionService;
    }

    @Required
    public void setBaseSiteService(BaseSiteService baseSiteService) {
        this.baseSiteService = baseSiteService;
    }

    @Required
    public void setMediaService(MediaService mediaService) {
        this.mediaService = mediaService;
    }

    @Required
    public void setModelService(ModelService modelService) {
        this.modelService = modelService;
    }

    public MediaService getMediaService() {
        return mediaService;
    }

    public ModelService getModelService() {
        return modelService;
    }

    public ProductService getProductService() {
        return productService;
    }

    @Required
    public void setProductService(ProductService productService) {
        this.productService = productService;
    }
}