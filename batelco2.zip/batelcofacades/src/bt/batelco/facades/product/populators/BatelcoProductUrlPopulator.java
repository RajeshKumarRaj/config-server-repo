package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.product.converters.populator.ProductUrlPopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

import org.apache.commons.collections.CollectionUtils;

/**
 * Custom implementation of {@link ProductUrlPopulator}
 */
public class BatelcoProductUrlPopulator extends ProductUrlPopulator {
  @Override
  public void populate(final ProductModel source, final ProductData target) {
    super.populate(source, target);

    if (source instanceof TmaSimpleProductOfferingModel
        && CollectionUtils.isNotEmpty(((TmaSimpleProductOfferingModel) source).getTmaPoVariants())) {
      ((TmaSimpleProductOfferingModel) source).getTmaPoVariants().stream()
          .findAny().map(product -> getProductModelUrlResolver().resolve(product))
          .ifPresent(target::setUrl);
    }
  }
}
