package bt.batelco.facades.product.populators;

import de.hybris.platform.acceleratorservices.urlresolver.SiteBaseUrlResolutionService;
import de.hybris.platform.b2ctelcofacades.constants.B2ctelcofacadesConstants;
import de.hybris.platform.b2ctelcofacades.product.TmaProductOfferFacade;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.basecommerce.enums.StockLevelStatus;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.category.CategoryService;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.converters.ConfigurablePopulator;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.deliveryzone.model.ZoneDeliveryModeModel;
import de.hybris.platform.deliveryzone.model.ZoneDeliveryModeValueModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.site.BaseSiteService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import bt.batelco.facades.product.dto.ExportProductDTO;
import bt.batelco.facades.product.dto.Shipping;


public class BatelcoExportProductPopulator implements Populator<ProductModel, ExportProductDTO> {

    private static final Logger LOG = Logger.getLogger(BatelcoExportProductPopulator.class);
    private static final String BASESITE_UID ="batelco";
    private static final String BATELCO = "Batelco" ;
    private static final String BRAND = "brand_";
    private static final String NEW = "new";
    private static final String IN_STOCK = "in stock";
    private static final String OUT_OF_STOCK = "out of stock";
    private static final String SERVICE_PLAN_CLASSIFICATION = "serviceplanclassification";
    private static final String PREORDER = "preorder";
    private static final String HTML_PARSE_REGEX = "\\<.*?\\>";
    private static final String CURRENCY_SYMBOL = "BD ";

    private BaseSiteService baseSiteService;
    private BaseStoreService baseStoreService;
    private UrlResolver<ProductModel> productModelUrlResolver;
    private SiteBaseUrlResolutionService siteBaseUrlResolutionService;
    private TmaProductOfferFacade productOfferFacade;
    private Converter<ProductModel, ProductData> productConverter;
    private ConfigurablePopulator<ProductModel, ProductData, ProductOption> productConfiguredPopulator;
    private PriceDataFactory priceDataFactory;
    private CategoryService categoryService;

    /**
     * Populate the values from product model, if value required by facebook is missing populate with EMPTY, to make the tag visible in XML feed.
     * @param source
     *              ProductModel
     * @param target
     *          ExportProductDTO
     * @throws ConversionException
     *          ConversionException
     */
    @Override
    public void populate(ProductModel source, ExportProductDTO target) throws ConversionException {

        final ProductData productData = productConverter.convert(source);
        final List<ProductOption> basicOptions = Arrays.asList(ProductOption.BASIC,ProductOption.PRICE,ProductOption.SUMMARY,
                ProductOption.DESCRIPTION,ProductOption.STOCK);
        productConfiguredPopulator.populate(source, productData, basicOptions);

        try{
            populatePrice(target, productData);
            populateMedia(source, target);
            target.setProductId(productData.getCode());

            if(StringUtils.isNotEmpty(productData.getName())){
                target.setName(productData.getName());
            }else{
                LOG.warn("Name is missing/not configured for product:"+productData.getCode());
                target.setName(StringUtils.EMPTY);
            }

            populateDescription(productData,target);

            final String productUrl = getSiteBaseUrlResolutionService().getWebsiteUrlForSite(getBaseSite(), Boolean.TRUE, productData.getUrl());
            target.setUrl(productUrl);
            populateBrand(source, target, productData);
            //Condition of the item in your store. Supported values: new, refurbished, used.
            target.setCondition(NEW);
            populateStockAvailability(source,target,productData);
            //Shipping is optional
            populateShippingDetails(target);
        }catch(Exception e){
            LOG.error("Exception while populating product:"+productData.getCode(),e);
        }
    }

    /**
     * Populate the description using summary and replace html chars.
     * @param productData
     *  ProductData
     * @param target
     *          ExportProductDTO
     */
    private void populateDescription(ProductData productData, ExportProductDTO target) {
        if(StringUtils.isNotEmpty(productData.getSummary())){
            target.setDescription(productData.getSummary().replaceAll(HTML_PARSE_REGEX, StringUtils.EMPTY));
        }else{
            LOG.warn("Summary is missing/not configured for product:"+productData.getCode());
            target.setDescription(StringUtils.EMPTY);
        }
    }

    /**
     * Current availability of the item in your store. Must be written in U.S. English. Must be one of the following values:
     *   in stock - Item ships immediately
     *   available for order - Ships in 1-2 weeks
     *   preorder - Limited availability feature. Please contact your Facebook representative to get access.
     *   out of stock - Not available in current stock
     *   discontinued - Discontinued
     * @param productModel
     *      ProductModel
     * @param target
     *          ExportProductDTO
     * @param productData
     */
    private void populateStockAvailability(ProductModel productModel, ExportProductDTO target, ProductData productData) {
        if(productModel.getPreorderProduct()){
            target.setStockAvailability(PREORDER);
        }else if(productData.getStock().getStockLevelStatus().equals(StockLevelStatus.INSTOCK) ||
                productData.getStock().getStockLevelStatus().equals(StockLevelStatus.LOWSTOCK)){
            target.setStockAvailability(IN_STOCK);
        }else if(productData.getStock().getStockLevelStatus().equals(StockLevelStatus.OUTOFSTOCK)){
            target.setStockAvailability(OUT_OF_STOCK);
        }
    }

    /**
     *  Populates the Brand
     * @param productModel
     *          ProductModel
     * @param target
     *          ExportProductDTO
     * @param productData
     *              ProductData
     */
    private void populateBrand(ProductModel productModel, ExportProductDTO target, ProductData productData) {

        if(isAddonProduct(productModel) || isBatelcoProduct(productModel)){
            target.setBrandName(BATELCO);
            return;
        }else if(productModel instanceof TmaPoVariantModel){
            productModel.getSupercategories().stream()
                    .filter(category-> StringUtils.containsIgnoreCase(category.getCode(),BRAND))
                    .findFirst().ifPresent(category ->target.setBrandName(category.getName()));
        }else{
            LOG.info("Brand is missing/not configured for Product: "+productData.getCode());
            target.setBrandName(StringUtils.EMPTY);
        }
    }

    private boolean isAddonProduct(final ProductModel product)
    {
        final List<CategoryModel> categoryList = getCategoryService().getCategoryPathForProduct(product);
        return categoryList.stream()
                .anyMatch(category -> category.getCode().equalsIgnoreCase(B2ctelcofacadesConstants.ADDONS_CATEGORY_CODE));
    }

    /**
     * Identifies if a product is subscription product
     * @param product
     *     ProductModel
     * @return
     *    return boolean
     */
    private boolean isBatelcoProduct(final ProductModel product)
    {
        return (CollectionUtils.isNotEmpty(product.getClassificationClasses())) &&  product.getClassificationClasses().stream()
                .filter( classificationClass -> classificationClass.getCode().equalsIgnoreCase(SERVICE_PLAN_CLASSIFICATION))
                .findAny().isPresent();
    }

    /**
     *  Populates the Shipping details, these details are optional for feed.
     * @param target
     *          ExportProductDTO
     */
    private void populateShippingDetails(ExportProductDTO target) {
        Shipping shipping = new Shipping();
        BaseStoreModel baseStoreModel = getBaseStoreService().getAllBaseStores().stream().findFirst().get();
        shipping.setCountry(baseStoreModel.getDeliveryCountries().stream().findFirst().get().getName());
        ZoneDeliveryModeModel deliveryModeModel = (ZoneDeliveryModeModel) baseStoreModel.getDeliveryModes().stream().findFirst().get();
        ZoneDeliveryModeValueModel zoneDeliveryModeValue = deliveryModeModel.getValues().stream().findFirst().get();
        PriceData shippingPriceData = getPriceDataFactory().create(PriceDataType.BUY, BigDecimal.valueOf(zoneDeliveryModeValue.getValue()),
                zoneDeliveryModeValue.getCurrency().getIsocode());
        BigDecimal shippingPrice = shippingPriceData.getValue().setScale(1, RoundingMode.DOWN);
        shipping.setPrice(shippingPrice.toString());
        shipping.setService(deliveryModeModel.getName());
        target.setShipping(shipping);
    }

    /**
     *  Populates the Media link. If media is not configured, set with empty so as to reflect the tag in XML feed, as this tag is mandatory.
     * @param source
     *          ProductModel
     * @param target
     *          ExportProductDTO
     */
    private void populateMedia(ProductModel source, ExportProductDTO target) {
        final String mediaUrl = getSiteBaseUrlResolutionService().getMediaUrlForSite(getBaseSite(), Boolean.FALSE);
        target.setImageUrl(source.getPicture() != null ? mediaUrl != null ? mediaUrl + source.getPicture().getURL() : source.getPicture().getURL() : "");
        if(StringUtils.isEmpty(target.getImageUrl())){
            LOG.warn("Media is missing/not configured for product:"+source.getCode());
        }
    }

    /**
     *  Populates the price
     * @param target
     *          ExportProductDTO
     * @param productData
     *              ProductData
     */
    private void populatePrice(ExportProductDTO target, ProductData productData) {
        try{
            target.setPrice(productData.getPrice().getFormattedValue().replace(CURRENCY_SYMBOL,StringUtils.EMPTY));
        }catch(Exception e){
            LOG.error("Price is missing/not configured for product: "+productData.getCode());
            target.setPrice(StringUtils.EMPTY);
        }
    }


    private BaseSiteModel getBaseSite(){
        return getBaseSiteService().getBaseSiteForUID(BASESITE_UID);
    }

    protected SiteBaseUrlResolutionService getSiteBaseUrlResolutionService()
    {
        return siteBaseUrlResolutionService;
    }

    protected UrlResolver<ProductModel> getProductModelUrlResolver()
    {
        return productModelUrlResolver;
    }

    public BaseSiteService getBaseSiteService() {
        return baseSiteService;
    }

    public BaseStoreService getBaseStoreService() {
        return baseStoreService;
    }

    public PriceDataFactory getPriceDataFactory() {
        return priceDataFactory;
    }

    public CategoryService getCategoryService() {
        return categoryService;
    }

    @Required
    public void setSiteBaseUrlResolutionService(SiteBaseUrlResolutionService siteBaseUrlResolutionService) {
        this.siteBaseUrlResolutionService = siteBaseUrlResolutionService;
    }

    @Required
    public void setProductOfferFacade(TmaProductOfferFacade productOfferFacade) {
        this.productOfferFacade = productOfferFacade;
    }

    @Required
    public void setProductModelUrlResolver(final UrlResolver<ProductModel> productModelUrlResolver)
    {
        this.productModelUrlResolver = productModelUrlResolver;
    }

    @Required
    public void setBaseSiteService(BaseSiteService baseSiteService) {
        this.baseSiteService = baseSiteService;
    }

    @Required
    public void setProductConfiguredPopulator(
            final ConfigurablePopulator<ProductModel, ProductData, ProductOption> productConfiguredPopulator)
    {
        this.productConfiguredPopulator = productConfiguredPopulator;
    }

    @Required
    public void setProductConverter(Converter<ProductModel, ProductData> productConverter) {
        this.productConverter = productConverter;
    }

    @Required
    public void setBaseStoreService(BaseStoreService baseStoreService) {
        this.baseStoreService = baseStoreService;
    }

    @Required
    public void setPriceDataFactory(PriceDataFactory priceDataFactory) {
        this.priceDataFactory = priceDataFactory;
    }

    @Required
    public void setCategoryService(CategoryService categoryService) {
        this.categoryService = categoryService;
    }
}