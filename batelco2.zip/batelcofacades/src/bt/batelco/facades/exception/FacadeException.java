package bt.batelco.facades.exception;

public class FacadeException extends RuntimeException {

  /**
   * Constructs a new facade exception
   *
   * @param message exception message
   */
  public FacadeException(final String message) {
    super(message);
  }

  /**
   * Constructs a new facade exception
   *
   * @param message exception message
   */
  public FacadeException(String message, Throwable cause) {
    super(message, cause);
  }


  /**
   * Constructs a new facade exception
   *
   * @param cause throwable
   */
  public FacadeException(final Throwable cause) {
    super(cause);
  }
}