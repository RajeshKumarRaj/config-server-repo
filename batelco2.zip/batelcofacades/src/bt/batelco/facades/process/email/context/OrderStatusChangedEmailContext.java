/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.facades.process.email.context;

import de.hybris.platform.acceleratorservices.model.cms2.pages.EmailPageModel;
import de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.exceptions.AmbiguousIdentifierException;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.subscriptionfacades.data.OrderPriceData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import bt.batelco.core.model.processes.OrderStatusChangedProcessModel;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.CATALOG_ONLINE;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.CONTENT_CATALOG_ID;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.EMAIL_LOGO_IDENTIFIER;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.TERMS_AND_CONDITIONS_MEDIA_IDENTIFIER;

import static bt.batelco.facades.constants.BatelcoFacadesConstants.*;


/**
 * Velocity context for a order notification email.
 */
public class OrderStatusChangedEmailContext extends AbstractEmailContext<OrderStatusChangedProcessModel> {

  private static final Logger LOG = LoggerFactory.getLogger(OrderStatusChangedEmailContext.class);

  private static final String PREORDER_PAYNOW_CODE = "preorderPaynow";
  private static final String MONTHLY = "Monthly";

  @Resource(name = "catalogVersionService")
  private CatalogVersionService catalogVersionService;

  @Resource(name = "mediaService")
  private MediaService mediaService;

  @Resource(name = "priceDataFactory")
  private PriceDataFactory priceDataFactory;

  private String siteLogoUrl;
  private String termsAndContionsUrl;
  private Converter<OrderModel, OrderData> orderConverter;
  private OrderData orderData;
  private String messageToCustomer;
  private PriceData orderTotalOtherThanMonthly;

  @Override
  public void init(final OrderStatusChangedProcessModel orderProcessModel, final EmailPageModel emailPageModel) {
    super.init(orderProcessModel, emailPageModel);
    orderData = getOrderConverter().convert(orderProcessModel.getOrder());
    String orderUrl = getOrderUrl(orderProcessModel.getOrder().getCode());
    messageToCustomer = String.format(orderProcessModel.getMessageToCustomer(), orderUrl, orderData.getCode());
    try {
      final CatalogVersionModel
          contentCatalogOnline =
          catalogVersionService.getCatalogVersion(CONTENT_CATALOG_ID, CATALOG_ONLINE);

      final MediaModel siteLogo = mediaService.getMedia(contentCatalogOnline, EMAIL_LOGO_IDENTIFIER);
      siteLogoUrl = siteLogo.getURL2();
      final MediaModel termsAndContions = mediaService.getMedia(TERMS_AND_CONDITIONS_MEDIA_IDENTIFIER);
      termsAndContionsUrl = termsAndContions.getURL2();
      orderTotalOtherThanMonthly = calculateOrderTotalsOtherThanMonthly(orderData);
    } catch (UnknownIdentifierException | AmbiguousIdentifierException ex) {
      LOG.warn(ex.getMessage());
    }catch (Exception ex) {
      LOG.error("Exception",ex);
    }
  }

  public PriceDataFactory getPriceDataFactory() {
    return priceDataFactory;
  }


  private PriceData calculateOrderTotalsOtherThanMonthly(OrderData orderData) {

    BigDecimal priceSumUp = new BigDecimal(BigInteger.ZERO);

    List<OrderPriceData> orderPrices;
    if (orderData.getPreorder()) {
      orderPrices = orderData.getOrderPrices().stream()
              .filter(orderPriceData -> orderPriceData.getBillingTime() != null)
              .filter(orderPriceData -> PREORDER_PAYNOW_CODE.equalsIgnoreCase(orderPriceData.getBillingTime().getCode()))
              .collect(Collectors.toList());

      priceSumUp = sumUpPrices(orderPrices);

    } else {
      orderPrices = orderData.getOrderPrices().stream()
              .filter(orderPriceData -> orderPriceData.getBillingTime() != null)
              .filter(orderPriceData -> !MONTHLY.equalsIgnoreCase(orderPriceData.getBillingTime().getCode()))
              .collect(Collectors.toList());

      priceSumUp = sumUpPrices(orderPrices);
    }

    return getPriceDataFactory().create(PriceDataType.BUY, priceSumUp, orderData.getTotalPrice().getCurrencyIso());
  }

  private BigDecimal sumUpPrices(List<OrderPriceData> orderPrices) {
    BigDecimal orderTotalPrice;
    orderTotalPrice = orderPrices.stream()
            .map(OrderPriceData::getTotalPrice)
            .map(PriceData::getValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    return orderTotalPrice;
  }

  private String getOrderUrl(String orderCode) {

    return getSecureBaseUrl() + "/my-account/order/" + orderCode;
  }

  @Override
  protected BaseSiteModel getSite(final OrderStatusChangedProcessModel orderProcessModel) {
    return orderProcessModel.getOrder().getSite();
  }

  @Override
  protected CustomerModel getCustomer(final OrderStatusChangedProcessModel orderProcessModel) {
    return (CustomerModel) orderProcessModel.getOrder().getUser();
  }

  protected Converter<OrderModel, OrderData> getOrderConverter() {
    return orderConverter;
  }

  @Required
  public void setOrderConverter(final Converter<OrderModel, OrderData> orderConverter) {
    this.orderConverter = orderConverter;
  }

  public OrderData getOrder() {
    return orderData;
  }

  @Override
  protected LanguageModel getEmailLanguage(final OrderStatusChangedProcessModel orderProcessModel) {
    return orderProcessModel.getOrder().getLanguage();
  }

  public String getMessageToCustomer() {
    return messageToCustomer;
  }

  public PriceData getOrderTotalOtherThanMonthly() {
    return orderTotalOtherThanMonthly;
  }

  public String getSiteLogoUrl() {
    return siteLogoUrl;
  }

  public String getTermsAndContionsUrl() {
    return termsAndContionsUrl;
  }
}
