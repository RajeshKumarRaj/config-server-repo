package bt.batelco.facades.search.solrfacetsearch.populators;

import de.hybris.platform.b2ctelcofacades.search.solrfacetsearch.populators.TmaSearchResultPoPopulator;
import de.hybris.platform.basecommerce.enums.StockLevelStatus;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commerceservices.search.resultdata.SearchResultValueData;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.stock.BatelcoStockFacade;

public class BatelcoTmaSearchResultPoPopulator extends TmaSearchResultPoPopulator {

  private static final Logger LOG = Logger.getLogger(BatelcoTmaSearchResultPoPopulator.class);

  private static final String IS_PREORDER_INDEXED_PROPERTY = "isPreorder";
  private static final String STOCK_LEVEL_STATUS = "stockLevelStatus";

  private BatelcoStockFacade batelcoStockFacade;

  @Override
  protected void populatePrices(final SearchResultValueData source, final ProductData target) {
    super.populatePrices(source, target);

    boolean isPreorder = getValue(source, IS_PREORDER_INDEXED_PROPERTY);
    target.setIsPreorder(isPreorder);
  }

  @Override
  protected void populateStock(final SearchResultValueData source, final ProductData target) {
    final String stockLevelStatus = this.getValue(source, STOCK_LEVEL_STATUS);
    if (StringUtils.isEmpty(stockLevelStatus)) {
      LOG.debug("No stock level found");
      return;
    }
    final StockLevelStatus stockLevelStatusEnum = StockLevelStatus.valueOf(stockLevelStatus);

    if (StockLevelStatus.LOWSTOCK.equals(stockLevelStatusEnum) ||
        StockLevelStatus.OUTOFSTOCK.equals(stockLevelStatusEnum)) {
      target.setStock(batelcoStockFacade.evaluateStockLevel(target.getCode(), stockLevelStatusEnum));
    } else {
      target.setStock(getStockLevelStatusConverter().convert(stockLevelStatusEnum));
    }
  }

  @Required
  public void setBatelcoStockFacade(BatelcoStockFacade batelcoStockFacade) {
    this.batelcoStockFacade = batelcoStockFacade;
  }
}
