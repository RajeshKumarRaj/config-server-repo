package bt.batelco.facades.populators;

import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;

import org.springframework.beans.factory.annotation.Required;

/**
 * Populator for address from register form
 */
public class BatelcoRegisterAddressReversePopulator implements Populator<RegisterData, AddressModel> {

  private CommonI18NService commonI18NService;

  @Override
  public void populate(RegisterData registerData, AddressModel addressModel) throws ConversionException {
    addressModel.setFirstname(registerData.getFirstName());
    addressModel.setLastname(registerData.getLastName());
    addressModel.setEmail(registerData.getLogin());
    addressModel.setPhone1(registerData.getPhone());
    addressModel.setCountry(commonI18NService.getCountry(registerData.getCountryCode()));
    addressModel.setTown(registerData.getCity());
    addressModel.setStreetname(registerData.getAddressLine1());
    addressModel.setStreetnumber(registerData.getAddressLine2());
    addressModel.setPostalcode(registerData.getZipCode());
    addressModel.setShippingAddress(Boolean.TRUE);
  }

  @Required
  public void setCommonI18NService(CommonI18NService commonI18NService) {
    this.commonI18NService = commonI18NService;
  }
}
