package bt.batelco.facades.populators;

import de.hybris.platform.catalog.model.CatalogModel;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.cmsfacades.data.MediaData;
import de.hybris.platform.cmsfacades.uniqueidentifier.UniqueItemIdentifierService;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.springframework.beans.factory.annotation.Required;

/**
 * This populator will populate the {@link MediaData} from the {@link MediaModel}.
 */
public class BatelcoBasicMediaPopulator implements Populator<MediaModel, MediaData> {

  private UniqueItemIdentifierService uniqueItemIdentifierService;

  @Override
  public void populate(final MediaModel source, final MediaData target) throws ConversionException {
    target.setAltText(source.getAltText());
    target.setCode(source.getCode());
    target.setDescription(source.getDescription());
    target.setDownloadUrl(source.getDownloadURL());
    target.setMime(source.getMime());
    target.setUrl(source.getURL());

    final CatalogVersionModel catalogVersion = source.getCatalogVersion();
    if (catalogVersion != null) {
      target.setCatalogVersion(catalogVersion.getVersion());

      getUniqueItemIdentifierService().getItemData(source).ifPresent(itemData -> target.setUuid(itemData.getItemId()));

      final CatalogModel catalog = catalogVersion.getCatalog();
      if (catalog != null) {
        target.setCatalogId(catalog.getId());
      }
    }
  }

  @Required
  public void setUniqueItemIdentifierService(UniqueItemIdentifierService uniqueItemIdentifierService) {
    this.uniqueItemIdentifierService = uniqueItemIdentifierService;
  }

  protected UniqueItemIdentifierService getUniqueItemIdentifierService() {
    return uniqueItemIdentifierService;
  }

}
