package bt.batelco.facades.populators;

import de.hybris.platform.commercefacades.user.converters.populator.CustomerPopulator;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.springframework.beans.factory.annotation.Required;

/**
 * Batelco Customer populator
 */
public class BatelcoCustomerPopulator extends CustomerPopulator {

  private Converter<AddressModel, AddressData> addressConverter;

  @Override
  public void populate(final CustomerModel source, final CustomerData target) {
    super.populate(source, target);

    target.setCprId(source.getCprId());
    if (source.getDefaultShipmentAddress() != null) {
      target.setDefaultShippingAddress(addressConverter.convert(source.getDefaultShipmentAddress()));
    }
    target.setFirstName(source.getFirstName());
    target.setLastName(source.getLastName());
  }

  @Required
  public void setAddressConverter(Converter<AddressModel, AddressData> addressConverter) {
    this.addressConverter = addressConverter;
  }
}
