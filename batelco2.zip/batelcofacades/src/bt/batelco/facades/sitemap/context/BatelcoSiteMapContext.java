package bt.batelco.facades.sitemap.context;

import de.hybris.platform.acceleratorservices.enums.SiteMapPageEnum;
import de.hybris.platform.acceleratorservices.sitemap.renderer.SiteMapContext;
import de.hybris.platform.cms2.model.site.CMSSiteModel;

public class BatelcoSiteMapContext extends SiteMapContext {

  private static final String SECURE_BASE_URL = "secureBaseUrl";
  private static final String PATH = "";
  private static final boolean SECURE_CONNECTION = Boolean.TRUE;

  @Override
  public void init(CMSSiteModel site, SiteMapPageEnum siteMapPageEnum) {
    super.init(site, siteMapPageEnum);
    this.put(SECURE_BASE_URL, getSiteBaseUrlResolutionService()
        .getWebsiteUrlForSite(site, getUrlEncoderService().getCurrentUrlEncodingPattern(), SECURE_CONNECTION, PATH));
  }
}
