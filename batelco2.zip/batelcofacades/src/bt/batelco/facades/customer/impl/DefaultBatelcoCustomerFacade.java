package bt.batelco.facades.customer.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.b2ctelcofacades.user.impl.TmaDefaultCustomerFacade;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.commerceservices.enums.CustomerType;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.convert.converter.Converter;

import bt.batelco.core.customer.service.BatelcoCustomerAccountService;
import bt.batelco.core.enums.CustomerIdType;
import bt.batelco.facades.customer.BatelcoCustomerFacade;
import bt.batelco.facades.exception.InvalidCustomerFacadeException;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Implementation of customer facade. It implements specific operations around customers
 * Override due to new CPR/CR ID field and defaultShipmentAddress in register method;
 * added new methods for confirm registration
 */
public class DefaultBatelcoCustomerFacade extends TmaDefaultCustomerFacade implements BatelcoCustomerFacade {

  private static final String DEFAULT_COUNTRY_ISO_CODE = "default.country.isoCode";
  private static final String BAHRAIN_COUNTRY_CODE = "BH";

  private Converter<RegisterData, AddressModel> batelcoRegisterAddressReverseConverter;
  private BatelcoCustomerAccountService batelcoCustomerAccountService;
  private ConfigProviderService configProviderService;

  @Override
  public void register(final RegisterData registerData) throws DuplicateUidException {
    validateParameterNotNullStandardMessage("registerData", registerData);

    final CustomerModel newCustomer = getModelService().create(CustomerModel.class);
    newCustomer.setName(getCustomerNameStrategy().getName(registerData.getFirstName(), registerData.getLastName()));
    newCustomer.setLastName(registerData.getLastName());
    newCustomer.setFirstName(registerData.getFirstName());

    setUidForRegister(registerData, newCustomer);
    newCustomer.setDefaultShipmentAddress(createAddress(newCustomer, registerData));
    newCustomer.setCprId(registerData.getCprId());
    newCustomer.setSessionLanguage(getCommonI18NService().getCurrentLanguage());
    newCustomer.setSessionCurrency(getCommonI18NService().getCurrentCurrency());
    newCustomer.setType(CustomerType.UNREGISTERED);
    newCustomer.setLoginDisabled(Boolean.TRUE);
    batelcoCustomerAccountService.register(newCustomer, registerData.getPassword());
  }

  private AddressModel createAddress(CustomerModel newCustomer, RegisterData registerData) {
    AddressModel addressModel = batelcoRegisterAddressReverseConverter.convert(registerData);
    addressModel.setOwner(newCustomer);
    return addressModel;
  }

  @Required
  public void setBatelcoRegisterAddressReverseConverter(
      Converter<RegisterData, AddressModel> batelcoRegisterAddressReverseConverter) {
    this.batelcoRegisterAddressReverseConverter = batelcoRegisterAddressReverseConverter;
  }

  @Override
  public void updateCustomerRegistration(String customerId) {
    CustomerModel customerModel = batelcoCustomerAccountService.findCustomerModelByCustomerId(customerId);
    customerModel.setType(CustomerType.REGISTERED);
    customerModel.setLoginDisabled(Boolean.FALSE);

    getModelService().save(customerModel);
  }

  @Override
  public void updateProfile(final CustomerData customerData) throws DuplicateUidException {
    validateParameterNotNullStandardMessage("customerData", customerData);

    final String name = getCustomerNameStrategy().getName(customerData.getFirstName(), customerData.getLastName());
    final CustomerModel customer = getCurrentSessionCustomer();
    customer.setOriginalUid(customerData.getDisplayUid());
    customer.setUid(customerData.getUid().trim());
    customer.setName(name);
    customer.setFirstName(customerData.getFirstName());
    customer.setLastName(customerData.getLastName());
    customer.setCprId(customerData.getCprId());
    if (customer.getDefaultShipmentAddress() != null) {
      customer.getDefaultShipmentAddress().setPhone1(customerData.getDefaultShippingAddress().getPhone());
    } else {
      final AddressModel addressModel = createAddressModel(customerData);
      addressModel.setOwner(customer);
      customer.setDefaultShipmentAddress(addressModel);
    }

    batelcoCustomerAccountService.updateProfile(customer);
    getModelService().save(customer.getDefaultShipmentAddress());
  }

  /**
   * Create address when user updates his profile and does not have a default shipping address.
   * Default fields for address filled
   */
  private AddressModel createAddressModel(CustomerData customerData) {
    final AddressModel addressModel = getModelService().create(AddressModel.class);
    addressModel.setFirstname(customerData.getFirstName());
    addressModel.setLastname(customerData.getLastName());
    addressModel.setPhone1(customerData.getDefaultShippingAddress().getPhone());
    addressModel.setShippingAddress(Boolean.TRUE);
    addressModel.setVisibleInAddressBook(Boolean.TRUE);

    final String defaultCountry = configProviderService.<String>get(DEFAULT_COUNTRY_ISO_CODE)
        .conversion(source -> source).onMissing(useDefault(BAHRAIN_COUNTRY_CODE)).convert();

    addressModel.setCountry(getCommonI18NService().getCountry(defaultCountry));
    return addressModel;
  }

  @Override
  public boolean isRegistrationNotCompleted(String uid) {
    UserModel userModel;
    try {
      userModel = getUserService().getUserForUID(uid);
    } catch (UnknownIdentifierException ex) {
      throw new InvalidCustomerFacadeException(ex);
    }

    if (userModel instanceof CustomerModel) {
      CustomerModel customerModel = (CustomerModel) userModel;
      return customerModel.isLoginDisabled() && CustomerType.UNREGISTERED.equals(customerModel.getType());
    }

    return false;
  }
  
  @Override
  public String getIdType(String customerId) {
	  String idType = "";
	  CustomerModel customerModel = batelcoCustomerAccountService.findCustomerModelByCustomerId(customerId);
	  idType = customerModel.getIdType() == CustomerIdType.CPR ? "CPR" : "CR";
	  return idType;
  }

  @Required
  public void setBatelcoCustomerAccountService(BatelcoCustomerAccountService batelcoCustomerAccountService) {
    this.batelcoCustomerAccountService = batelcoCustomerAccountService;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }
}
