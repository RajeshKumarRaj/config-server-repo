package bt.batelco.facades.customer;

import de.hybris.platform.commercefacades.customer.CustomerFacade;

/**
 * Facade to perform various customer related operations
 */
public interface BatelcoCustomerFacade extends CustomerFacade {

  /**
   * Update customer when email confirmation is done.
   *
   * @param customerId customerId
   */
  void updateCustomerRegistration(final String customerId);

  /**
   * Check if user is unregistered
   *
   * @param uid customer uid
   * @return true when is unregistered
   * @throws bt.batelco.facades.exception.InvalidCustomerFacadeException - when user is not found
   */
  boolean isRegistrationNotCompleted(final String uid);
  
  public String getIdType(String customerId);
  
}
