package bt.batelco.facades.cart.populator;

import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.subscriptionfacades.data.OrderPriceData;

import java.math.BigDecimal;
import java.util.Optional;

import bt.batelco.facades.order.data.DocumentData;

/**
 * Batelco Cart Populator
 */
public class BatelcoCartPopulator implements Populator<CartModel, CartData> {
    private static final String PREORDER_PAYNOW_CODE = "preorderPaynow";

    @Override
    public void populate(CartModel source, CartData target) throws ConversionException {
        target.setPreorder(source.getPreorder());
        if (source.getPaymentEvidence() != null) {
            target.setPaymentEvidence(createDocumentData(source.getPaymentEvidence().getRealFileName(), source.getPaymentEvidence().getSize()));
        }

        populatePreorderFeeFlag(target);
    }


    private void populatePreorderFeeFlag(CartData target) {
        if (Boolean.TRUE != target.getPreorder()) {
            return;
        }
        getPreorderPrice(target).ifPresent(preorderPrice-> setPreorderFeeFlag(preorderPrice, target));
    }

    private Optional<OrderPriceData> getPreorderPrice(CartData cartData) {
        return cartData.getOrderPrices().stream().filter(price -> PREORDER_PAYNOW_CODE.equalsIgnoreCase(price.getBillingTime().getCode())).findFirst();
    }

    private void setPreorderFeeFlag(OrderPriceData preorderPrice, CartData target) {
        if (BigDecimal.ZERO.compareTo(preorderPrice.getTotalPrice().getValue())!= 0) {
            target.setPreorderFee(true);
        }
    }
    private DocumentData createDocumentData(String realFileName, Long size) {
        DocumentData documentData = new DocumentData();
        documentData.setFileName(realFileName);
        documentData.setFileSize(size);
        return documentData;
    }

}
