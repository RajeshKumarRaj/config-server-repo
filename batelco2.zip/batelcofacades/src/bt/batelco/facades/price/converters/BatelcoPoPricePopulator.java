package bt.batelco.facades.price.converters;

import de.hybris.platform.b2ctelcofacades.price.TmaPriceDataFactory;
import de.hybris.platform.b2ctelcofacades.price.converters.TmaPoPricePopulator;
import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.OneTimeChargeEntryData;
import de.hybris.platform.subscriptionfacades.data.RecurringChargeEntryData;
import de.hybris.platform.subscriptionfacades.data.SubscriptionPricePlanData;
import de.hybris.platform.subscriptionservices.model.OneTimeChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.RecurringChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;
import de.hybris.platform.util.TaxValue;

import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;

import bt.batelco.core.price.calculation.BatelcoPriceCalculationService;


/**
 * Custom product price populator
 *
 * @param <S> {@link ProductModel}
 * @param <T> {@link ProductData}
 */
public class BatelcoPoPricePopulator<S extends ProductModel, T extends ProductData> extends TmaPoPricePopulator<S, T> {

  private BatelcoPriceCalculationService priceCalculationService;
  private TmaPriceDataFactory tmaPriceDataFactory;
  private Converter<OneTimeChargeEntryModel, OneTimeChargeEntryData> oneTimeChargeEntryConverter;
  private Converter<RecurringChargeEntryModel, RecurringChargeEntryData> recurringChargeEntryConverter;

  @Override
  public void populate(final S source, final T target) {
    if (!(source instanceof TmaSimpleProductOfferingModel)) {
      return;
    }

    final TmaProductOfferingModel sourceProductOffering = (TmaProductOfferingModel) source;
    final TmaPriceContext priceContext = getPriceContextFactory().createPriceContext(sourceProductOffering, new HashSet<>(Collections.singleton(TmaProcessType.ACQUISITION)));

    if (getCommercePriceService().getMinimumPriceValue(priceContext) == null) {
      target.setPurchasable(false);
      return;
    }

    final BigDecimal minimumPriceValue = BigDecimal.valueOf(getCommercePriceService().getMinimumPriceValue(priceContext));
    final CurrencyModel currentCurrency = getI18NService().getCurrentCurrency();
    final SubscriptionPricePlanData priceData = tmaPriceDataFactory.create(PriceDataType.FROM, minimumPriceValue, currentCurrency.getIsocode());

    priceCalculationService.computeTaxValue(minimumPriceValue, currentCurrency, (TmaProductOfferingModel) source)
        .ifPresent(tax -> {
          populateTax(currentCurrency, priceData, tax);
          populateNetValue(minimumPriceValue, currentCurrency, priceData, tax);
        });

    populateCharges(priceContext, priceData);
    target.setPrice(priceData);
  }

  private void populateCharges(TmaPriceContext priceContext, SubscriptionPricePlanData priceData) {
    priceData.setOneTimeChargeEntries(oneTimeChargeEntryConverter.convertAll(((SubscriptionPricePlanModel) getCommercePriceService().getMinimumPrice(priceContext)).getOneTimeChargeEntries()));
    priceData.setRecurringChargeEntries(recurringChargeEntryConverter.convertAll(((SubscriptionPricePlanModel) getCommercePriceService().getMinimumPrice(priceContext)).getRecurringChargeEntries()));
  }

  private void populateTax(CurrencyModel currentCurrency, PriceData priceData, TaxValue taxValue) {
    Optional.of(BigDecimal.valueOf(taxValue.getAppliedValue()))
        .ifPresent(appliedTaxValue -> {
          priceData.setTaxValue(appliedTaxValue);
          priceData.setFormattedTaxValue(tmaPriceDataFactory.formatPriceValue(appliedTaxValue, currentCurrency));
        });
  }

  private void populateNetValue(BigDecimal minimumPriceValue, CurrencyModel currentCurrency, PriceData priceData, TaxValue taxValue) {
    priceCalculationService.computeNetPrice(minimumPriceValue, currentCurrency, Collections.singletonList(taxValue))
        .map(priceValue1 -> BigDecimal.valueOf(priceValue1.getValue()))
        .ifPresent(netPrice -> {
          priceData.setNetValue(netPrice);
          priceData.setFormattedNetValue(tmaPriceDataFactory.formatPriceValue(netPrice, currentCurrency));
        });
  }

  @Required
  public void setPriceCalculationService(BatelcoPriceCalculationService priceCalculationService) {
    this.priceCalculationService = priceCalculationService;
  }

  @Required
  public void setTmaPriceDataFactory(TmaPriceDataFactory priceDataFactory) {
    this.tmaPriceDataFactory = priceDataFactory;
  }

  @Required
  public void setOneTimeChargeEntryConverter(
      Converter<OneTimeChargeEntryModel, OneTimeChargeEntryData> oneTimeChargeEntryConverter) {
    this.oneTimeChargeEntryConverter = oneTimeChargeEntryConverter;
  }

  @Required
  public void setRecurringChargeEntryConverter(
      Converter<RecurringChargeEntryModel, RecurringChargeEntryData> recurringChargeEntryConverter) {
    this.recurringChargeEntryConverter = recurringChargeEntryConverter;
  }
}
