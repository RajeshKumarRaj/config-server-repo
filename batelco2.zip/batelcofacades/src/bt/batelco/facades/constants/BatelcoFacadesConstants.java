/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.facades.constants;

/**
 * Global class for all BatelcoFacades constants.
 */
public class BatelcoFacadesConstants extends GeneratedBatelcoFacadesConstants
{
	public static final String EXTENSIONNAME = "batelcofacades";

	public static final String CONTENT_CATALOG_ID = "batelcoContentCatalog";
	public static final String CATALOG_ONLINE= "Online";

	public static final String EMAIL_LOGO_IDENTIFIER = "/images/theme/batelco-email-logo.png";
	public static final String TERMS_AND_CONDITIONS_MEDIA_IDENTIFIER = "termsAndConditionsPdf";

	private BatelcoFacadesConstants()
	{
		//empty
	}
	
	public class BatelcoPaymentConstants {
	    private BatelcoPaymentConstants() {
	      //empty
	    }

	    public static final String PAYMENT_TYPE_CFG_KEY = "paymentType";
	    public static final String PAYMENT_CUSTOMER_IP_CFG_KEY = "customerIp";
	    public static final String DOWNPAYMENT_BILLING_CODE = "paynow";
	    public static final String VAT_BILLING_CODE = "vat";
	  }

	
}
