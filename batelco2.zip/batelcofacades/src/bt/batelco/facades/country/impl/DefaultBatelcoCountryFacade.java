package bt.batelco.facades.country.impl;

import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commerceservices.enums.CountryType;
import de.hybris.platform.core.model.c2l.CountryModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.List;

import bt.batelco.facades.country.BatelcoCountryFacade;

/**
 * Implementation of batelco country facade. It implements specific operations around countries
 */

public class DefaultBatelcoCountryFacade implements BatelcoCountryFacade {

  private CommonI18NService commonI18NService;
  private BaseStoreService baseStoreService;
  private Converter<CountryModel, CountryData> countryConverter;

  @Override
  public List<CountryData> getCountries(final CountryType countryType) {
    List<CountryModel> countries = new ArrayList<>();
    final BaseStoreModel store = baseStoreService.getCurrentBaseStore();
    if (store != null) {
      if (CountryType.SHIPPING.equals(countryType) && CollectionUtils.isNotEmpty(store.getDeliveryCountries())) {
        countries.addAll(store.getDeliveryCountries());
      } else if (CountryType.BILLING.equals(countryType) && CollectionUtils.isNotEmpty(store.getBillingCountries())) {
        countries.addAll(store.getBillingCountries());
      }
    }
    if (CollectionUtils.isEmpty(countries)) {
      countries.addAll(commonI18NService.getAllCountries());
    }
    return countryConverter.convertAll(countries);
  }

  @Required
  public void setCommonI18NService(CommonI18NService commonI18NService) {
    this.commonI18NService = commonI18NService;
  }

  @Required
  public void setBaseStoreService(BaseStoreService baseStoreService) {
    this.baseStoreService = baseStoreService;
  }

  @Required
  public void setCountryConverter(
      Converter<CountryModel, CountryData> countryConverter) {
    this.countryConverter = countryConverter;
  }
}
