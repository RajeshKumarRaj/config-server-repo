package bt.batelco.facades.country;

import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commerceservices.enums.CountryType;

import java.util.List;

/**
 * Facade for managing countries
 */
public interface BatelcoCountryFacade {

  /**
   * Get countries by CountryType; when country associated to countryType is not found, it will get all countries
   *
   * @param countryType country type
   * @return list of countryData</>
   */
  List<CountryData> getCountries(final CountryType countryType);
}
