package bt.batelco.facades.consens.populator;

import de.hybris.platform.acceleratorservices.urlresolver.SiteBaseUrlResolutionService;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commercefacades.consent.data.ConsentTemplateData;
import de.hybris.platform.commerceservices.model.consent.ConsentTemplateModel;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.site.BaseSiteService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.model.MediaVersionModel;
import bt.batelco.facades.mediaversion.data.MediaVersionData;

public class BatelcoConsentTemplatePopulator implements Populator<ConsentTemplateModel, ConsentTemplateData> {

  private static final Logger LOG = LoggerFactory.getLogger(BatelcoConsentTemplatePopulator.class);
  private Converter<MediaVersionModel, MediaVersionData> mediaVersionConverter;
  private SiteBaseUrlResolutionService siteBaseUrlResolutionService;
  private BaseSiteService baseSiteService;

  @Override
  public void populate(ConsentTemplateModel consentTemplateModel, ConsentTemplateData consentTemplateData)
      throws ConversionException {
    if (consentTemplateModel.getMediaVersion() != null) {
      consentTemplateData.setMediaVersion(mediaVersionConverter.convert(consentTemplateModel.getMediaVersion()));
      consentTemplateData.setMediaUrl(getConsentTemplateMediaUrl(consentTemplateModel.getMediaVersion().getMedia()));
    }
    consentTemplateData.setWithdrawable(consentTemplateModel.getWithdrawable());
  }

  private String getConsentTemplateMediaUrl(MediaModel mediaModel) {
    try {
      final BaseSiteModel currentBaseSite = baseSiteService.getCurrentBaseSite();
      return siteBaseUrlResolutionService.getMediaUrlForSite(currentBaseSite, true, mediaModel.getURL());
    } catch (RuntimeException ex) {
      LOG.warn(ex.getMessage(), ex);
    }
    return null;
  }

  @Required
  public void setMediaVersionConverter(Converter<MediaVersionModel, MediaVersionData> mediaVersionConverter) {
    this.mediaVersionConverter = mediaVersionConverter;
  }

  @Required
  public void setSiteBaseUrlResolutionService(SiteBaseUrlResolutionService siteBaseUrlResolutionService) {
    this.siteBaseUrlResolutionService = siteBaseUrlResolutionService;
  }

  @Required
  public void setBaseSiteService(BaseSiteService baseSiteService) {
    this.baseSiteService = baseSiteService;
  }
}
