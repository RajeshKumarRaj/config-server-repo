package bt.batelco.facades.order.impl;

import bt.batelco.facades.order.BatelcoOrderUpdateFacade;
import  bt.batelco.core.order.service.BatelcoOrderUpdateService;

public class DefaultBatelcoOrderUpdateFacade implements BatelcoOrderUpdateFacade {

	//private BatelcoOrderUpdateService batelcoOrderUpdateService;
	private BatelcoOrderUpdateService batelcoOrderUpdateService;
	public BatelcoOrderUpdateService getBatelcoOrderUpdateService() {
		return batelcoOrderUpdateService;
	}
	public void setBatelcoOrderUpdateService(BatelcoOrderUpdateService batelcoOrderUpdateService) {
		this.batelcoOrderUpdateService = batelcoOrderUpdateService;
	}
	@Override
	public String updateOrderStatus(String hybrisOrderId, String seibelOrderId, String orderStatus,
			String deliveryStatus, String deliveryPartnerName, String deliveryPartnerTrackingId, String deliveredDate,
			String remarks) {
		// TODO Auto-generated method stub
		
		String response=batelcoOrderUpdateService.updateOrderStatus(hybrisOrderId, seibelOrderId, orderStatus, deliveryStatus, deliveryPartnerName, deliveryPartnerTrackingId, deliveredDate, remarks);
		return response;
	}

}
