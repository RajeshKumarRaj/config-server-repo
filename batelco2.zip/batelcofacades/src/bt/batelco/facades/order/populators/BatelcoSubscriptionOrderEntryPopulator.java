package bt.batelco.facades.order.populators;

import de.hybris.platform.b2ctelcofacades.price.TmaPriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.subscriptionfacades.data.SubscriptionPricePlanData;
import de.hybris.platform.subscriptionfacades.order.converters.populator.SubscriptionOrderEntryPopulator;
import de.hybris.platform.util.TaxValue;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;

/**
 * Custom implementation of {@link SubscriptionPricePlanData}
 */
public class BatelcoSubscriptionOrderEntryPopulator extends SubscriptionOrderEntryPopulator {
  private TmaPriceDataFactory tmaPriceDataFactory;

  @Override
  protected PriceData createPrice(final AbstractOrderEntryModel orderEntry, final Double val) {
    CurrencyModel currency = orderEntry.getOrder().getCurrency();
    SubscriptionPricePlanData pricePlan = tmaPriceDataFactory.create(PriceDataType.BUY, BigDecimal.valueOf(val), currency);
    if (CollectionUtils.isEmpty(orderEntry.getTaxValues())) {
      return pricePlan;
    }

    orderEntry.getTaxValues().stream().map(TaxValue::getAppliedValue).findFirst()
        .ifPresent(tax -> {
          pricePlan.setFormattedTaxValue(tmaPriceDataFactory.formatPriceValue(BigDecimal.valueOf(tax), currency));
          pricePlan.setTaxValue(BigDecimal.valueOf(tax));
        });

    return pricePlan;
  }

  @Required
  public void setTmaPriceDataFactory(TmaPriceDataFactory tmaPriceDataFactory) {
    this.tmaPriceDataFactory = tmaPriceDataFactory;
  }
}
