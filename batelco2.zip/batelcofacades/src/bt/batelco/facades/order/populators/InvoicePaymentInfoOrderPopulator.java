package bt.batelco.facades.order.populators;

import de.hybris.platform.commercefacades.order.data.AbstractOrderData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.payment.InvoicePaymentInfoModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.order.data.InvoicePaymentInfoData;

public class InvoicePaymentInfoOrderPopulator implements Populator<AbstractOrderModel, AbstractOrderData> {

  private Converter<AddressModel, AddressData> addressConverter;
  private static final Logger LOG = LoggerFactory.getLogger(InvoicePaymentInfoOrderPopulator.class);

  @Override
  public void populate(AbstractOrderModel model, AbstractOrderData data) throws ConversionException {

    PaymentInfoModel paymentInfoModel = model.getPaymentInfo();
    if(paymentInfoModel == null){
      return;
    }
    if (!(paymentInfoModel instanceof InvoicePaymentInfoModel)) {
      LOG.warn("No instance of InvoicePaymentInfoModel found on order with code: "+model.getCode());
      return;
    }
    data.setBatelcoPaymentInfo(getInvoicePaymentInfoData((InvoicePaymentInfoModel) paymentInfoModel));
  }


  private InvoicePaymentInfoData getInvoicePaymentInfoData(InvoicePaymentInfoModel model) throws ConversionException {
    InvoicePaymentInfoData data = new InvoicePaymentInfoData();

    data.setCode(model.getCode());
    if (model.getBillingAddress() != null) {
      data.setBillingAddress(getAddressConverter().convert(model.getBillingAddress()));
    }
    return data;
  }

  public Converter<AddressModel, AddressData> getAddressConverter() {
    return addressConverter;
  }

  @Required
  public void setAddressConverter(
      Converter<AddressModel, AddressData> addressConverter) {
    this.addressConverter = addressConverter;
  }

}
