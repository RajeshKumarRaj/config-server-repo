package bt.batelco.facades.payment.dto;

import java.util.List;

import bt.batelco.core.enums.BillingAccountStatus;
import bt.batelco.core.enums.SubscriptionBaseStatus;
import bt.batelco.core.enums.SubscriptionBaseType;

/**
 * Holds information about order payment details.
 */
public class PaymentDetailsItemDTO {
  private SubscriptionBaseType type;
  private String accountNumber;
  private BillingAccountStatus accountStatus;
  private String accountSubNo;
  private String telNo;
  private SubscriptionBaseStatus telStatus;
  private String amount;
  private String orderId;
  private List<PaymentProductEntryDTO> products;

  public SubscriptionBaseType getType() {
    return type;
  }

  public void setType(SubscriptionBaseType type) {
    this.type = type;
  }

  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public BillingAccountStatus getAccountStatus() {
    return accountStatus;
  }

  public void setAccountStatus(BillingAccountStatus accountStatus) {
    this.accountStatus = accountStatus;
  }

  public String getAccountSubNo() {
    return accountSubNo;
  }

  public void setAccountSubNo(String accountSubNo) {
    this.accountSubNo = accountSubNo;
  }

  public String getTelNo() {
    return telNo;
  }

  public void setTelNo(String telNo) {
    this.telNo = telNo;
  }

  public SubscriptionBaseStatus getTelStatus() {
    return telStatus;
  }

  public void setTelStatus(SubscriptionBaseStatus telStatus) {
    this.telStatus = telStatus;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public List<PaymentProductEntryDTO> getProducts() {
    return products;
  }

  public void setProducts(List<PaymentProductEntryDTO> products) {
    this.products = products;
  }
}
