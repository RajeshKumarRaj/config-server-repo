package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitResponse {
	
	@JsonProperty("InitPaymentResponse")
	InitPaymentResponse InitPaymentResponseObject;

	public InitPaymentResponse getInitPaymentResponseObject() {
		return InitPaymentResponseObject;
	}

	public void setInitPaymentResponseObject(InitPaymentResponse initPaymentResponseObject) {
		InitPaymentResponseObject = initPaymentResponseObject;
	}

	
}
