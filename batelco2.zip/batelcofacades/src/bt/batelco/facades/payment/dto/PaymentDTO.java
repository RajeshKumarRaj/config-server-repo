package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Holds order payment information that are being sent to Payment Gateway.
 */
public class PaymentDTO {
  @JsonProperty("metadata")
  private PaymentMetadataDTO paymentMetadata;
  private PaymentDetailsDTO paymentDetails;

  public PaymentMetadataDTO getPaymentMetadata() {
    return paymentMetadata;
  }

  public void setPaymentMetadata(PaymentMetadataDTO paymentMetadata) {
    this.paymentMetadata = paymentMetadata;
  }

  public PaymentDetailsDTO getPaymentDetails() {
    return paymentDetails;
  }

  public void setPaymentDetails(PaymentDetailsDTO paymentDetails) {
    this.paymentDetails = paymentDetails;
  }
}