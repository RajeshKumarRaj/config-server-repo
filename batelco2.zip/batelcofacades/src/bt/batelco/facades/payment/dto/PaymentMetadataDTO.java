package bt.batelco.facades.payment.dto;

/**
 * Holds payment metadata info.
 */
public class PaymentMetadataDTO {
  private String channel;
  private int mode;

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public int getMode() {
    return mode;
  }

  public void setMode(int mode) {
    this.mode = mode;
  }
}
