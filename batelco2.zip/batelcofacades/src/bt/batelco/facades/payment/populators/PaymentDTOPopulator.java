package bt.batelco.facades.payment.populators;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.commercefacades.order.data.AbstractOrderData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.payment.dto.PaymentDTO;
import bt.batelco.facades.payment.dto.PaymentDetailsDTO;
import bt.batelco.facades.payment.dto.PaymentMetadataDTO;

import static com.iquest.config.provider.IncorrectConfigurationActions.throwInvalidConfigException;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwMissingConfigException;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates target {@link PaymentDTO} data from source {@link OrderData} data.
 */
public class PaymentDTOPopulator implements Populator<AbstractOrderData, PaymentDTO> {
  private Converter<AbstractOrderData, PaymentDetailsDTO> paymentDetailsConverter;
  private ConfigProviderService configProviderService;

  private static final String PAYMENT_CHANNEL_CFG_KEY = "payment.gateway.channel";
  private static final String PAYMENT_MODE_CFG_KEY = "payment.gateway.mode";

  @Override
  public void populate(AbstractOrderData source, PaymentDTO target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    populatePaymentMetadata(target);
    target.setPaymentDetails(paymentDetailsConverter.convert(source));
  }

  private void populatePaymentMetadata(final PaymentDTO target) {
    final PaymentMetadataDTO paymentMetadata = new PaymentMetadataDTO();
    paymentMetadata.setChannel(getChannel());
    paymentMetadata.setMode(getMode());

    target.setPaymentMetadata(paymentMetadata);
  }

  private String getChannel() {
    return configProviderService.<String>get(PAYMENT_CHANNEL_CFG_KEY)
        .conversion(value -> value)
        .validateThat(StringUtils::isNotEmpty)
        .onInvalid(throwInvalidConfigException())
        .onMissing(throwMissingConfigException())
        .convert();
  }

  private int getMode() {
    return Integer.valueOf(configProviderService.<String>get(PAYMENT_MODE_CFG_KEY)
                               .conversion(value -> value)
                               .validateThat(StringUtils::isNotEmpty)
                               .onInvalid(throwInvalidConfigException())
                               .onMissing(throwMissingConfigException())
                               .convert());
  }

  @Required
  public void setPaymentDetailsConverter(Converter<AbstractOrderData, PaymentDetailsDTO> paymentDetailsConverter) {
    this.paymentDetailsConverter = paymentDetailsConverter;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }
}
