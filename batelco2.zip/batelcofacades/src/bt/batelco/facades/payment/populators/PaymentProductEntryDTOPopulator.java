package bt.batelco.facades.payment.populators;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.subscriptionfacades.data.OrderEntryPriceData;

import java.util.List;
import java.util.Optional;

import bt.batelco.facades.constants.BatelcoFacadesConstants;
import bt.batelco.facades.payment.dto.PaymentProductEntryDTO;
import bt.batelco.facades.payment.dto.PaymentProductEntryPriceDTO;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates target {@link PaymentProductEntryDTO} data from {@link OrderEntryData} source.
 */
public class PaymentProductEntryDTOPopulator implements Populator<OrderEntryData, PaymentProductEntryDTO> {
  private static final String DEFAULT_AMOUNT_VALUE = "0.00";

  @Override
  public void populate(OrderEntryData source, PaymentProductEntryDTO target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    target.setEntryId(String.valueOf(source.getEntryNumber()));
    target.setName(source.getProduct().getName());
    populateProductEntryPrice(source, target);
  }

  private void populateProductEntryPrice(final OrderEntryData source, PaymentProductEntryDTO target) {
    final PaymentProductEntryPriceDTO priceDTO = new PaymentProductEntryPriceDTO();
    priceDTO.setDownpayment(getDownPaymentAmount(source));
    priceDTO.setAdvance(DEFAULT_AMOUNT_VALUE);
    priceDTO.setVat(getVatAmount(source));

    target.setEntryPrice(priceDTO);
  }

  private String getDownPaymentAmount(final OrderEntryData source) {
    final List<OrderEntryPriceData> orderEntryPrices = source.getOrderEntryPrices();
    final Optional<OrderEntryPriceData> entryPriceData = orderEntryPrices.stream()
        .filter(entryPrice -> entryPrice.getBillingTime() != null &&
                              BatelcoFacadesConstants.BatelcoPaymentConstants.DOWNPAYMENT_BILLING_CODE
                                  .equals(entryPrice.getBillingTime().getCode())).findFirst();

    return entryPriceData
        .map(orderEntryPriceData -> String.valueOf(orderEntryPriceData.getBasePrice().getValue().doubleValue()))
        .orElseGet(() -> DEFAULT_AMOUNT_VALUE);
  }

  private String getVatAmount(final OrderEntryData source) {
    final List<OrderEntryPriceData> orderEntryPrices = source.getOrderEntryPrices();
    final Optional<OrderEntryPriceData> entryPriceData = orderEntryPrices.stream()
        .filter(entryPrice -> entryPrice.getBillingTime() != null &&
                              BatelcoFacadesConstants.BatelcoPaymentConstants.VAT_BILLING_CODE
                                  .equals(entryPrice.getBillingTime().getCode())).findFirst();

    return entryPriceData
        .map(orderEntryPriceData -> String.valueOf(orderEntryPriceData.getBasePrice().getValue().doubleValue()))
        .orElseGet(() -> DEFAULT_AMOUNT_VALUE);
  }
}
