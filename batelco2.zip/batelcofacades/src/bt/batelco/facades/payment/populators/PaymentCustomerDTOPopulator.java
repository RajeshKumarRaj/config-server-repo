package bt.batelco.facades.payment.populators;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commercefacades.user.data.PrincipalData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.payment.dto.PaymentCustomerDTO;

import static com.iquest.config.provider.IncorrectConfigurationActions.throwInvalidConfigException;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwMissingConfigException;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates target {@link PaymentCustomerDTO} data from source {@link PrincipalData}.
 */
public class PaymentCustomerDTOPopulator implements Populator<CustomerData, PaymentCustomerDTO> {
  private ConfigProviderService configProviderService;

  private static final String PAYMENT_DEFAULT_CUSTOMER_ID_TYPE_CFG = "payment.gateway.default.customer.idType";

  @Override
  public void populate(CustomerData source, PaymentCustomerDTO target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    target.setId(source.getUid());
    target.setName(source.getName());
    target.setEmail(source.getEmail());
    populateCustomerIdType(source, target);
  }

  private void populateCustomerIdType(final CustomerData source, final PaymentCustomerDTO target) {
    final String customerIdType = source.getIdType();
    if (StringUtils.isEmpty(customerIdType)) {
      // get default customer id type stored as config item in DB
      final String defaultIdType = configProviderService.<String>get(PAYMENT_DEFAULT_CUSTOMER_ID_TYPE_CFG)
          .conversion(value -> value)
          .validateThat(StringUtils::isNotEmpty)
          .onInvalid(throwInvalidConfigException())
          .onMissing(throwMissingConfigException())
          .convert();
      target.setIdType(defaultIdType);
    } else {
      target.setIdType(source.getIdType());
    }
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }
}
