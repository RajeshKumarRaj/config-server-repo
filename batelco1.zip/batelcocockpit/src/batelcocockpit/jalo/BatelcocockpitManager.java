package batelcocockpit.jalo;

import batelcocockpit.constants.BatelcocockpitConstants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.extension.ExtensionManager;
import org.apache.log4j.Logger;

@SuppressWarnings("PMD")
public class BatelcocockpitManager extends GeneratedBatelcocockpitManager
{
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger( BatelcocockpitManager.class.getName() );
	
	public static final BatelcocockpitManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (BatelcocockpitManager) em.getExtension(BatelcocockpitConstants.EXTENSIONNAME);
	}
	
}
