/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package batelcocockpit.components.navigationarea;

import de.hybris.platform.cockpit.components.navigationarea.DefaultNavigationAreaModel;
import de.hybris.platform.cockpit.session.impl.AbstractUINavigationArea;

import batelcocockpit.session.impl.BatelcocockpitNavigationArea;


/**
 * Batelcocockpit navigation area model.
 */
public class BatelcocockpitNavigationAreaModel extends DefaultNavigationAreaModel
{
	public BatelcocockpitNavigationAreaModel()
	{
		super();
	}

	public BatelcocockpitNavigationAreaModel(final AbstractUINavigationArea area)
	{
		super(area);
	}

	@Override
	public BatelcocockpitNavigationArea getNavigationArea()
	{
		return (BatelcocockpitNavigationArea) super.getNavigationArea();
	}
}
