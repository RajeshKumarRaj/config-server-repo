/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package com.batelco.core.jobs.jalo;

import bt.batelco.core.constants.BatelcoCoreConstants;
import de.hybris.platform.catalog.jalo.CatalogVersion;
import de.hybris.platform.cronjob.jalo.CronJob;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.media.Media;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.batelco.core.jobs.jalo.ExportProductCronJob ExportProductCronJob}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedExportProductCronJob extends CronJob
{
	/** Qualifier of the <code>ExportProductCronJob.facebookFeed</code> attribute **/
	public static final String FACEBOOKFEED = "facebookFeed";
	/** Qualifier of the <code>ExportProductCronJob.catalogVersion</code> attribute **/
	public static final String CATALOGVERSION = "catalogVersion";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(CronJob.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(FACEBOOKFEED, AttributeMode.INITIAL);
		tmp.put(CATALOGVERSION, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ExportProductCronJob.catalogVersion</code> attribute.
	 * @return the catalogVersion - CatalogVersion
	 */
	public CatalogVersion getCatalogVersion(final SessionContext ctx)
	{
		return (CatalogVersion)getProperty( ctx, CATALOGVERSION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ExportProductCronJob.catalogVersion</code> attribute.
	 * @return the catalogVersion - CatalogVersion
	 */
	public CatalogVersion getCatalogVersion()
	{
		return getCatalogVersion( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ExportProductCronJob.catalogVersion</code> attribute. 
	 * @param value the catalogVersion - CatalogVersion
	 */
	public void setCatalogVersion(final SessionContext ctx, final CatalogVersion value)
	{
		setProperty(ctx, CATALOGVERSION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ExportProductCronJob.catalogVersion</code> attribute. 
	 * @param value the catalogVersion - CatalogVersion
	 */
	public void setCatalogVersion(final CatalogVersion value)
	{
		setCatalogVersion( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ExportProductCronJob.facebookFeed</code> attribute.
	 * @return the facebookFeed
	 */
	public Media getFacebookFeed(final SessionContext ctx)
	{
		return (Media)getProperty( ctx, FACEBOOKFEED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ExportProductCronJob.facebookFeed</code> attribute.
	 * @return the facebookFeed
	 */
	public Media getFacebookFeed()
	{
		return getFacebookFeed( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ExportProductCronJob.facebookFeed</code> attribute. 
	 * @param value the facebookFeed
	 */
	public void setFacebookFeed(final SessionContext ctx, final Media value)
	{
		setProperty(ctx, FACEBOOKFEED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ExportProductCronJob.facebookFeed</code> attribute. 
	 * @param value the facebookFeed
	 */
	public void setFacebookFeed(final Media value)
	{
		setFacebookFeed( getSession().getSessionContext(), value );
	}
	
}
