/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.core.jalo;

import bt.batelco.core.constants.BatelcoCoreConstants;
import de.hybris.platform.b2ctelcoservices.constants.B2ctelcoservicesConstants;
import de.hybris.platform.b2ctelcoservices.jalo.TmaBillingAccount;
import de.hybris.platform.b2ctelcoservices.jalo.TmaSubscriptionBase;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.util.BidirectionalOneToManyHandler;
import de.hybris.platform.util.OneToManyHandler;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Generated class for type {@link de.hybris.platform.jalo.GenericItem BatelcoBillingProfile}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBatelcoBillingProfile extends GenericItem
{
	/** Qualifier of the <code>BatelcoBillingProfile.billingProfileId</code> attribute **/
	public static final String BILLINGPROFILEID = "billingProfileId";
	/** Qualifier of the <code>BatelcoBillingProfile.billingProfileName</code> attribute **/
	public static final String BILLINGPROFILENAME = "billingProfileName";
	/** Qualifier of the <code>BatelcoBillingProfile.billingAccount</code> attribute **/
	public static final String BILLINGACCOUNT = "billingAccount";
	/** Qualifier of the <code>BatelcoBillingProfile.subscriptionBases</code> attribute **/
	public static final String SUBSCRIPTIONBASES = "subscriptionBases";
	/**
	* {@link BidirectionalOneToManyHandler} for handling 1:n BILLINGACCOUNT's relation attributes from 'one' side.
	**/
	protected static final BidirectionalOneToManyHandler<GeneratedBatelcoBillingProfile> BILLINGACCOUNTHANDLER = new BidirectionalOneToManyHandler<GeneratedBatelcoBillingProfile>(
	BatelcoCoreConstants.TC.BATELCOBILLINGPROFILE,
	false,
	"billingAccount",
	null,
	false,
	true,
	CollectionType.SET
	);
	/**
	* {@link OneToManyHandler} for handling 1:n SUBSCRIPTIONBASES's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<TmaSubscriptionBase> SUBSCRIPTIONBASESHANDLER = new OneToManyHandler<TmaSubscriptionBase>(
	B2ctelcoservicesConstants.TC.TMASUBSCRIPTIONBASE,
	false,
	"billingProfile",
	null,
	false,
	true,
	CollectionType.SET
	);
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(BILLINGPROFILEID, AttributeMode.INITIAL);
		tmp.put(BILLINGPROFILENAME, AttributeMode.INITIAL);
		tmp.put(BILLINGACCOUNT, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingAccount</code> attribute.
	 * @return the billingAccount
	 */
	public TmaBillingAccount getBillingAccount(final SessionContext ctx)
	{
		return (TmaBillingAccount)getProperty( ctx, BILLINGACCOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingAccount</code> attribute.
	 * @return the billingAccount
	 */
	public TmaBillingAccount getBillingAccount()
	{
		return getBillingAccount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingAccount</code> attribute. 
	 * @param value the billingAccount
	 */
	public void setBillingAccount(final SessionContext ctx, final TmaBillingAccount value)
	{
		BILLINGACCOUNTHANDLER.addValue( ctx, value, this  );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingAccount</code> attribute. 
	 * @param value the billingAccount
	 */
	public void setBillingAccount(final TmaBillingAccount value)
	{
		setBillingAccount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingProfileId</code> attribute.
	 * @return the billingProfileId
	 */
	public String getBillingProfileId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, BILLINGPROFILEID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingProfileId</code> attribute.
	 * @return the billingProfileId
	 */
	public String getBillingProfileId()
	{
		return getBillingProfileId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingProfileId</code> attribute. 
	 * @param value the billingProfileId
	 */
	public void setBillingProfileId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, BILLINGPROFILEID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingProfileId</code> attribute. 
	 * @param value the billingProfileId
	 */
	public void setBillingProfileId(final String value)
	{
		setBillingProfileId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingProfileName</code> attribute.
	 * @return the billingProfileName
	 */
	public String getBillingProfileName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, BILLINGPROFILENAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.billingProfileName</code> attribute.
	 * @return the billingProfileName
	 */
	public String getBillingProfileName()
	{
		return getBillingProfileName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingProfileName</code> attribute. 
	 * @param value the billingProfileName
	 */
	public void setBillingProfileName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, BILLINGPROFILENAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.billingProfileName</code> attribute. 
	 * @param value the billingProfileName
	 */
	public void setBillingProfileName(final String value)
	{
		setBillingProfileName( getSession().getSessionContext(), value );
	}
	
	@Override
	protected Item createItem(final SessionContext ctx, final ComposedType type, final ItemAttributeMap allAttributes) throws JaloBusinessException
	{
		BILLINGACCOUNTHANDLER.newInstance(ctx, allAttributes);
		return super.createItem( ctx, type, allAttributes );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.subscriptionBases</code> attribute.
	 * @return the subscriptionBases
	 */
	public Set<TmaSubscriptionBase> getSubscriptionBases(final SessionContext ctx)
	{
		return (Set<TmaSubscriptionBase>)SUBSCRIPTIONBASESHANDLER.getValues( ctx, this );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoBillingProfile.subscriptionBases</code> attribute.
	 * @return the subscriptionBases
	 */
	public Set<TmaSubscriptionBase> getSubscriptionBases()
	{
		return getSubscriptionBases( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.subscriptionBases</code> attribute. 
	 * @param value the subscriptionBases
	 */
	public void setSubscriptionBases(final SessionContext ctx, final Set<TmaSubscriptionBase> value)
	{
		SUBSCRIPTIONBASESHANDLER.setValues( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoBillingProfile.subscriptionBases</code> attribute. 
	 * @param value the subscriptionBases
	 */
	public void setSubscriptionBases(final Set<TmaSubscriptionBase> value)
	{
		setSubscriptionBases( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to subscriptionBases. 
	 * @param value the item to add to subscriptionBases
	 */
	public void addToSubscriptionBases(final SessionContext ctx, final TmaSubscriptionBase value)
	{
		SUBSCRIPTIONBASESHANDLER.addValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to subscriptionBases. 
	 * @param value the item to add to subscriptionBases
	 */
	public void addToSubscriptionBases(final TmaSubscriptionBase value)
	{
		addToSubscriptionBases( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from subscriptionBases. 
	 * @param value the item to remove from subscriptionBases
	 */
	public void removeFromSubscriptionBases(final SessionContext ctx, final TmaSubscriptionBase value)
	{
		SUBSCRIPTIONBASESHANDLER.removeValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from subscriptionBases. 
	 * @param value the item to remove from subscriptionBases
	 */
	public void removeFromSubscriptionBases(final TmaSubscriptionBase value)
	{
		removeFromSubscriptionBases( getSession().getSessionContext(), value );
	}
	
}
