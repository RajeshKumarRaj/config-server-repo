/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.core.jalo.processes;

import bt.batelco.core.constants.BatelcoCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.orderprocessing.jalo.OrderProcess;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link bt.batelco.core.jalo.processes.OrderStatusChangedProcess OrderStatusChangedProcess}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedOrderStatusChangedProcess extends OrderProcess
{
	/** Qualifier of the <code>OrderStatusChangedProcess.messageToCustomer</code> attribute **/
	public static final String MESSAGETOCUSTOMER = "messageToCustomer";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(OrderProcess.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(MESSAGETOCUSTOMER, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>OrderStatusChangedProcess.messageToCustomer</code> attribute.
	 * @return the messageToCustomer - The message that will be send to the customer via email.
	 */
	public String getMessageToCustomer(final SessionContext ctx)
	{
		return (String)getProperty( ctx, MESSAGETOCUSTOMER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>OrderStatusChangedProcess.messageToCustomer</code> attribute.
	 * @return the messageToCustomer - The message that will be send to the customer via email.
	 */
	public String getMessageToCustomer()
	{
		return getMessageToCustomer( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>OrderStatusChangedProcess.messageToCustomer</code> attribute. 
	 * @param value the messageToCustomer - The message that will be send to the customer via email.
	 */
	public void setMessageToCustomer(final SessionContext ctx, final String value)
	{
		setProperty(ctx, MESSAGETOCUSTOMER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>OrderStatusChangedProcess.messageToCustomer</code> attribute. 
	 * @param value the messageToCustomer - The message that will be send to the customer via email.
	 */
	public void setMessageToCustomer(final String value)
	{
		setMessageToCustomer( getSession().getSessionContext(), value );
	}
	
}
