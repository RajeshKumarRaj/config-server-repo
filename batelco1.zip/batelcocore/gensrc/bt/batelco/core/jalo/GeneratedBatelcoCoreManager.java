/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.core.jalo;

import bt.batelco.core.constants.BatelcoCoreConstants;
import bt.batelco.core.jalo.BatelcoBillingProfile;
import bt.batelco.core.jalo.BatelcoPaymentInfo;
import bt.batelco.core.jalo.CMSMediaLinkComponent;
import bt.batelco.core.jalo.MediaVersion;
import bt.batelco.core.jalo.processes.OrderStatusChangedProcess;
import com.batelco.core.jobs.jalo.ExportProductCronJob;
import de.hybris.platform.b2ctelcoservices.constants.B2ctelcoservicesConstants;
import de.hybris.platform.b2ctelcoservices.jalo.TmaBillingAccount;
import de.hybris.platform.b2ctelcoservices.jalo.TmaPoVariant;
import de.hybris.platform.b2ctelcoservices.jalo.TmaProductOffering;
import de.hybris.platform.b2ctelcoservices.jalo.TmaSimpleProductOffering;
import de.hybris.platform.b2ctelcoservices.jalo.TmaSubscriptionBase;
import de.hybris.platform.category.jalo.Category;
import de.hybris.platform.commerceservices.jalo.consent.ConsentTemplate;
import de.hybris.platform.europe1.jalo.PriceRow;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.media.Media;
import de.hybris.platform.jalo.media.MediaContainer;
import de.hybris.platform.jalo.order.AbstractOrder;
import de.hybris.platform.jalo.order.AbstractOrderEntry;
import de.hybris.platform.jalo.order.Cart;
import de.hybris.platform.jalo.order.payment.PaymentMode;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.jalo.user.Customer;
import de.hybris.platform.jalo.user.User;
import de.hybris.platform.paymentstandard.constants.StandardPaymentModeConstants;
import de.hybris.platform.paymentstandard.jalo.StandardPaymentMode;
import de.hybris.platform.util.OneToManyHandler;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Generated class for type <code>BatelcoCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBatelcoCoreManager extends Extension
{
	/**
	* {@link OneToManyHandler} for handling 1:n CHILDREN's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<StandardPaymentMode> STANDARDPAYMENTMODECHILDRENCHILDRENHANDLER = new OneToManyHandler<StandardPaymentMode>(
	StandardPaymentModeConstants.TC.STANDARDPAYMENTMODE,
	false,
	"parent",
	"parentPOS",
	true,
	true,
	CollectionType.LIST
	);
	/**
	* {@link OneToManyHandler} for handling 1:n BILLINGACCOUNTS's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<TmaBillingAccount> CUSTOMER2TMABILLINGACCOUNTBILLINGACCOUNTSHANDLER = new OneToManyHandler<TmaBillingAccount>(
	B2ctelcoservicesConstants.TC.TMABILLINGACCOUNT,
	false,
	"customer",
	null,
	false,
	true,
	CollectionType.SET
	);
	/**
	* {@link OneToManyHandler} for handling 1:n BILLINGPROFILES's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<BatelcoBillingProfile> TMABILLINGACCOUNT2BILLINGPROFILEBILLINGPROFILESHANDLER = new OneToManyHandler<BatelcoBillingProfile>(
	BatelcoCoreConstants.TC.BATELCOBILLINGPROFILE,
	false,
	"billingAccount",
	null,
	false,
	true,
	CollectionType.SET
	);
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("online", AttributeMode.INITIAL);
		tmp.put("paymentTypeId", AttributeMode.INITIAL);
		tmp.put("parentPOS", AttributeMode.INITIAL);
		tmp.put("parent", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.paymentstandard.jalo.StandardPaymentMode", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("documents", AttributeMode.INITIAL);
		tmp.put("defaultTmaPoVariant", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.b2ctelcoservices.jalo.TmaSimpleProductOffering", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("firstName", AttributeMode.INITIAL);
		tmp.put("lastName", AttributeMode.INITIAL);
		tmp.put("cprId", AttributeMode.INITIAL);
		tmp.put("idType", AttributeMode.INITIAL);
		tmp.put("accountNumber", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.user.Customer", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("vatDescription", AttributeMode.INITIAL);
		tmp.put("slang", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("cprFront", AttributeMode.INITIAL);
		tmp.put("cprBack", AttributeMode.INITIAL);
		tmp.put("cprId", AttributeMode.INITIAL);
		tmp.put("paymentEvidence", AttributeMode.INITIAL);
		tmp.put("seibelOrderId", AttributeMode.INITIAL);
		tmp.put("deliveryPartnerName", AttributeMode.INITIAL);
		tmp.put("deliveryPartnerTrackingId", AttributeMode.INITIAL);
		tmp.put("deliveredDate", AttributeMode.INITIAL);
		tmp.put("remarks", AttributeMode.INITIAL);
		tmp.put("awaitingPaymentStartDate", AttributeMode.INITIAL);
		tmp.put("outstandingAmount", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.AbstractOrder", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("billingAccountStatus", AttributeMode.INITIAL);
		tmp.put("customer", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.b2ctelcoservices.jalo.TmaBillingAccount", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("subscriptionBaseStatus", AttributeMode.INITIAL);
		tmp.put("subscriptionBaseType", AttributeMode.INITIAL);
		tmp.put("billingProfile", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.b2ctelcoservices.jalo.TmaSubscriptionBase", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("acquisitionForm", AttributeMode.INITIAL);
		tmp.put("paymentInfo", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.AbstractOrderEntry", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("batelcoPaymentInfo", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.Cart", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("mediaVersion", AttributeMode.INITIAL);
		tmp.put("withdrawable", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.commerceservices.jalo.consent.ConsentTemplate", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("visible", AttributeMode.INITIAL);
		tmp.put("title", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.category.jalo.Category", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.accountNumber</code> attribute.
	 * @return the accountNumber - Customer account number.
	 */
	public String getAccountNumber(final SessionContext ctx, final Customer item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Customer.ACCOUNTNUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.accountNumber</code> attribute.
	 * @return the accountNumber - Customer account number.
	 */
	public String getAccountNumber(final Customer item)
	{
		return getAccountNumber( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.accountNumber</code> attribute. 
	 * @param value the accountNumber - Customer account number.
	 */
	public void setAccountNumber(final SessionContext ctx, final Customer item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Customer.ACCOUNTNUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.accountNumber</code> attribute. 
	 * @param value the accountNumber - Customer account number.
	 */
	public void setAccountNumber(final Customer item, final String value)
	{
		setAccountNumber( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.acquisitionForm</code> attribute.
	 * @return the acquisitionForm
	 */
	public Media getAcquisitionForm(final SessionContext ctx, final AbstractOrderEntry item)
	{
		return (Media)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrderEntry.ACQUISITIONFORM);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.acquisitionForm</code> attribute.
	 * @return the acquisitionForm
	 */
	public Media getAcquisitionForm(final AbstractOrderEntry item)
	{
		return getAcquisitionForm( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.acquisitionForm</code> attribute. 
	 * @param value the acquisitionForm
	 */
	public void setAcquisitionForm(final SessionContext ctx, final AbstractOrderEntry item, final Media value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrderEntry.ACQUISITIONFORM,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.acquisitionForm</code> attribute. 
	 * @param value the acquisitionForm
	 */
	public void setAcquisitionForm(final AbstractOrderEntry item, final Media value)
	{
		setAcquisitionForm( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.awaitingPaymentStartDate</code> attribute.
	 * @return the awaitingPaymentStartDate - Contains the date when order status was changed to awaiting payment.
	 */
	public Date getAwaitingPaymentStartDate(final SessionContext ctx, final AbstractOrder item)
	{
		return (Date)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.AWAITINGPAYMENTSTARTDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.awaitingPaymentStartDate</code> attribute.
	 * @return the awaitingPaymentStartDate - Contains the date when order status was changed to awaiting payment.
	 */
	public Date getAwaitingPaymentStartDate(final AbstractOrder item)
	{
		return getAwaitingPaymentStartDate( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.awaitingPaymentStartDate</code> attribute. 
	 * @param value the awaitingPaymentStartDate - Contains the date when order status was changed to awaiting payment.
	 */
	public void setAwaitingPaymentStartDate(final SessionContext ctx, final AbstractOrder item, final Date value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.AWAITINGPAYMENTSTARTDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.awaitingPaymentStartDate</code> attribute. 
	 * @param value the awaitingPaymentStartDate - Contains the date when order status was changed to awaiting payment.
	 */
	public void setAwaitingPaymentStartDate(final AbstractOrder item, final Date value)
	{
		setAwaitingPaymentStartDate( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.batelcoPaymentInfo</code> attribute.
	 * @return the batelcoPaymentInfo - Represents the batelco payment transactionNo.
	 */
	public BatelcoPaymentInfo getBatelcoPaymentInfo(final SessionContext ctx, final Cart item)
	{
		return (BatelcoPaymentInfo)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Cart.BATELCOPAYMENTINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.batelcoPaymentInfo</code> attribute.
	 * @return the batelcoPaymentInfo - Represents the batelco payment transactionNo.
	 */
	public BatelcoPaymentInfo getBatelcoPaymentInfo(final Cart item)
	{
		return getBatelcoPaymentInfo( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.batelcoPaymentInfo</code> attribute. 
	 * @param value the batelcoPaymentInfo - Represents the batelco payment transactionNo.
	 */
	public void setBatelcoPaymentInfo(final SessionContext ctx, final Cart item, final BatelcoPaymentInfo value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Cart.BATELCOPAYMENTINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.batelcoPaymentInfo</code> attribute. 
	 * @param value the batelcoPaymentInfo - Represents the batelco payment transactionNo.
	 */
	public void setBatelcoPaymentInfo(final Cart item, final BatelcoPaymentInfo value)
	{
		setBatelcoPaymentInfo( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.billingAccounts</code> attribute.
	 * @return the billingAccounts
	 */
	public Set<TmaBillingAccount> getBillingAccounts(final SessionContext ctx, final Customer item)
	{
		return (Set<TmaBillingAccount>)CUSTOMER2TMABILLINGACCOUNTBILLINGACCOUNTSHANDLER.getValues( ctx, item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.billingAccounts</code> attribute.
	 * @return the billingAccounts
	 */
	public Set<TmaBillingAccount> getBillingAccounts(final Customer item)
	{
		return getBillingAccounts( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.billingAccounts</code> attribute. 
	 * @param value the billingAccounts
	 */
	public void setBillingAccounts(final SessionContext ctx, final Customer item, final Set<TmaBillingAccount> value)
	{
		CUSTOMER2TMABILLINGACCOUNTBILLINGACCOUNTSHANDLER.setValues( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.billingAccounts</code> attribute. 
	 * @param value the billingAccounts
	 */
	public void setBillingAccounts(final Customer item, final Set<TmaBillingAccount> value)
	{
		setBillingAccounts( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to billingAccounts. 
	 * @param value the item to add to billingAccounts
	 */
	public void addToBillingAccounts(final SessionContext ctx, final Customer item, final TmaBillingAccount value)
	{
		CUSTOMER2TMABILLINGACCOUNTBILLINGACCOUNTSHANDLER.addValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to billingAccounts. 
	 * @param value the item to add to billingAccounts
	 */
	public void addToBillingAccounts(final Customer item, final TmaBillingAccount value)
	{
		addToBillingAccounts( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from billingAccounts. 
	 * @param value the item to remove from billingAccounts
	 */
	public void removeFromBillingAccounts(final SessionContext ctx, final Customer item, final TmaBillingAccount value)
	{
		CUSTOMER2TMABILLINGACCOUNTBILLINGACCOUNTSHANDLER.removeValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from billingAccounts. 
	 * @param value the item to remove from billingAccounts
	 */
	public void removeFromBillingAccounts(final Customer item, final TmaBillingAccount value)
	{
		removeFromBillingAccounts( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.billingAccountStatus</code> attribute.
	 * @return the billingAccountStatus
	 */
	public EnumerationValue getBillingAccountStatus(final SessionContext ctx, final GenericItem item)
	{
		return (EnumerationValue)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaBillingAccount.BILLINGACCOUNTSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.billingAccountStatus</code> attribute.
	 * @return the billingAccountStatus
	 */
	public EnumerationValue getBillingAccountStatus(final TmaBillingAccount item)
	{
		return getBillingAccountStatus( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.billingAccountStatus</code> attribute. 
	 * @param value the billingAccountStatus
	 */
	public void setBillingAccountStatus(final SessionContext ctx, final GenericItem item, final EnumerationValue value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaBillingAccount.BILLINGACCOUNTSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.billingAccountStatus</code> attribute. 
	 * @param value the billingAccountStatus
	 */
	public void setBillingAccountStatus(final TmaBillingAccount item, final EnumerationValue value)
	{
		setBillingAccountStatus( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.billingProfile</code> attribute.
	 * @return the billingProfile
	 */
	public BatelcoBillingProfile getBillingProfile(final SessionContext ctx, final GenericItem item)
	{
		return (BatelcoBillingProfile)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.BILLINGPROFILE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.billingProfile</code> attribute.
	 * @return the billingProfile
	 */
	public BatelcoBillingProfile getBillingProfile(final TmaSubscriptionBase item)
	{
		return getBillingProfile( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.billingProfile</code> attribute. 
	 * @param value the billingProfile
	 */
	public void setBillingProfile(final SessionContext ctx, final GenericItem item, final BatelcoBillingProfile value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.BILLINGPROFILE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.billingProfile</code> attribute. 
	 * @param value the billingProfile
	 */
	public void setBillingProfile(final TmaSubscriptionBase item, final BatelcoBillingProfile value)
	{
		setBillingProfile( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.billingProfiles</code> attribute.
	 * @return the billingProfiles
	 */
	public Set<BatelcoBillingProfile> getBillingProfiles(final SessionContext ctx, final GenericItem item)
	{
		return (Set<BatelcoBillingProfile>)TMABILLINGACCOUNT2BILLINGPROFILEBILLINGPROFILESHANDLER.getValues( ctx, item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.billingProfiles</code> attribute.
	 * @return the billingProfiles
	 */
	public Set<BatelcoBillingProfile> getBillingProfiles(final TmaBillingAccount item)
	{
		return getBillingProfiles( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.billingProfiles</code> attribute. 
	 * @param value the billingProfiles
	 */
	public void setBillingProfiles(final SessionContext ctx, final GenericItem item, final Set<BatelcoBillingProfile> value)
	{
		TMABILLINGACCOUNT2BILLINGPROFILEBILLINGPROFILESHANDLER.setValues( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.billingProfiles</code> attribute. 
	 * @param value the billingProfiles
	 */
	public void setBillingProfiles(final TmaBillingAccount item, final Set<BatelcoBillingProfile> value)
	{
		setBillingProfiles( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to billingProfiles. 
	 * @param value the item to add to billingProfiles
	 */
	public void addToBillingProfiles(final SessionContext ctx, final GenericItem item, final BatelcoBillingProfile value)
	{
		TMABILLINGACCOUNT2BILLINGPROFILEBILLINGPROFILESHANDLER.addValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to billingProfiles. 
	 * @param value the item to add to billingProfiles
	 */
	public void addToBillingProfiles(final TmaBillingAccount item, final BatelcoBillingProfile value)
	{
		addToBillingProfiles( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from billingProfiles. 
	 * @param value the item to remove from billingProfiles
	 */
	public void removeFromBillingProfiles(final SessionContext ctx, final GenericItem item, final BatelcoBillingProfile value)
	{
		TMABILLINGACCOUNT2BILLINGPROFILEBILLINGPROFILESHANDLER.removeValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from billingProfiles. 
	 * @param value the item to remove from billingProfiles
	 */
	public void removeFromBillingProfiles(final TmaBillingAccount item, final BatelcoBillingProfile value)
	{
		removeFromBillingProfiles( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.children</code> attribute.
	 * @return the children
	 */
	public List<StandardPaymentMode> getChildren(final SessionContext ctx, final StandardPaymentMode item)
	{
		return (List<StandardPaymentMode>)STANDARDPAYMENTMODECHILDRENCHILDRENHANDLER.getValues( ctx, item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.children</code> attribute.
	 * @return the children
	 */
	public List<StandardPaymentMode> getChildren(final StandardPaymentMode item)
	{
		return getChildren( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.children</code> attribute. 
	 * @param value the children
	 */
	public void setChildren(final SessionContext ctx, final StandardPaymentMode item, final List<StandardPaymentMode> value)
	{
		STANDARDPAYMENTMODECHILDRENCHILDRENHANDLER.setValues( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.children</code> attribute. 
	 * @param value the children
	 */
	public void setChildren(final StandardPaymentMode item, final List<StandardPaymentMode> value)
	{
		setChildren( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to children. 
	 * @param value the item to add to children
	 */
	public void addToChildren(final SessionContext ctx, final StandardPaymentMode item, final StandardPaymentMode value)
	{
		STANDARDPAYMENTMODECHILDRENCHILDRENHANDLER.addValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to children. 
	 * @param value the item to add to children
	 */
	public void addToChildren(final StandardPaymentMode item, final StandardPaymentMode value)
	{
		addToChildren( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from children. 
	 * @param value the item to remove from children
	 */
	public void removeFromChildren(final SessionContext ctx, final StandardPaymentMode item, final StandardPaymentMode value)
	{
		STANDARDPAYMENTMODECHILDRENCHILDRENHANDLER.removeValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from children. 
	 * @param value the item to remove from children
	 */
	public void removeFromChildren(final StandardPaymentMode item, final StandardPaymentMode value)
	{
		removeFromChildren( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprBack</code> attribute.
	 * @return the cprBack
	 */
	public Media getCprBack(final SessionContext ctx, final AbstractOrder item)
	{
		return (Media)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRBACK);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprBack</code> attribute.
	 * @return the cprBack
	 */
	public Media getCprBack(final AbstractOrder item)
	{
		return getCprBack( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprBack</code> attribute. 
	 * @param value the cprBack
	 */
	public void setCprBack(final SessionContext ctx, final AbstractOrder item, final Media value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRBACK,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprBack</code> attribute. 
	 * @param value the cprBack
	 */
	public void setCprBack(final AbstractOrder item, final Media value)
	{
		setCprBack( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprFront</code> attribute.
	 * @return the cprFront
	 */
	public Media getCprFront(final SessionContext ctx, final AbstractOrder item)
	{
		return (Media)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRFRONT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprFront</code> attribute.
	 * @return the cprFront
	 */
	public Media getCprFront(final AbstractOrder item)
	{
		return getCprFront( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprFront</code> attribute. 
	 * @param value the cprFront
	 */
	public void setCprFront(final SessionContext ctx, final AbstractOrder item, final Media value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRFRONT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprFront</code> attribute. 
	 * @param value the cprFront
	 */
	public void setCprFront(final AbstractOrder item, final Media value)
	{
		setCprFront( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.cprId</code> attribute.
	 * @return the cprId
	 */
	public String getCprId(final SessionContext ctx, final Customer item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Customer.CPRID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.cprId</code> attribute.
	 * @return the cprId
	 */
	public String getCprId(final Customer item)
	{
		return getCprId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.cprId</code> attribute. 
	 * @param value the cprId
	 */
	public void setCprId(final SessionContext ctx, final Customer item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Customer.CPRID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.cprId</code> attribute. 
	 * @param value the cprId
	 */
	public void setCprId(final Customer item, final String value)
	{
		setCprId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprId</code> attribute.
	 * @return the cprId
	 */
	public String getCprId(final SessionContext ctx, final AbstractOrder item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.cprId</code> attribute.
	 * @return the cprId
	 */
	public String getCprId(final AbstractOrder item)
	{
		return getCprId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprId</code> attribute. 
	 * @param value the cprId
	 */
	public void setCprId(final SessionContext ctx, final AbstractOrder item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.CPRID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.cprId</code> attribute. 
	 * @param value the cprId
	 */
	public void setCprId(final AbstractOrder item, final String value)
	{
		setCprId( getSession().getSessionContext(), item, value );
	}
	
	public BatelcoBillingProfile createBatelcoBillingProfile(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.BATELCOBILLINGPROFILE );
			return (BatelcoBillingProfile)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating BatelcoBillingProfile : "+e.getMessage(), 0 );
		}
	}
	
	public BatelcoBillingProfile createBatelcoBillingProfile(final Map attributeValues)
	{
		return createBatelcoBillingProfile( getSession().getSessionContext(), attributeValues );
	}
	
	public BatelcoPaymentInfo createBatelcoPaymentInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.BATELCOPAYMENTINFO );
			return (BatelcoPaymentInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating BatelcoPaymentInfo : "+e.getMessage(), 0 );
		}
	}
	
	public BatelcoPaymentInfo createBatelcoPaymentInfo(final Map attributeValues)
	{
		return createBatelcoPaymentInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public CMSMediaLinkComponent createCMSMediaLinkComponent(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.CMSMEDIALINKCOMPONENT );
			return (CMSMediaLinkComponent)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating CMSMediaLinkComponent : "+e.getMessage(), 0 );
		}
	}
	
	public CMSMediaLinkComponent createCMSMediaLinkComponent(final Map attributeValues)
	{
		return createCMSMediaLinkComponent( getSession().getSessionContext(), attributeValues );
	}
	
	public ExportProductCronJob createExportProductCronJob(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.EXPORTPRODUCTCRONJOB );
			return (ExportProductCronJob)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ExportProductCronJob : "+e.getMessage(), 0 );
		}
	}
	
	public ExportProductCronJob createExportProductCronJob(final Map attributeValues)
	{
		return createExportProductCronJob( getSession().getSessionContext(), attributeValues );
	}
	
	public MediaVersion createMediaVersion(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.MEDIAVERSION );
			return (MediaVersion)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating MediaVersion : "+e.getMessage(), 0 );
		}
	}
	
	public MediaVersion createMediaVersion(final Map attributeValues)
	{
		return createMediaVersion( getSession().getSessionContext(), attributeValues );
	}
	
	public OrderStatusChangedProcess createOrderStatusChangedProcess(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BatelcoCoreConstants.TC.ORDERSTATUSCHANGEDPROCESS );
			return (OrderStatusChangedProcess)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating OrderStatusChangedProcess : "+e.getMessage(), 0 );
		}
	}
	
	public OrderStatusChangedProcess createOrderStatusChangedProcess(final Map attributeValues)
	{
		return createOrderStatusChangedProcess( getSession().getSessionContext(), attributeValues );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.customer</code> attribute.
	 * @return the customer
	 */
	public Customer getCustomer(final SessionContext ctx, final GenericItem item)
	{
		return (Customer)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaBillingAccount.CUSTOMER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaBillingAccount.customer</code> attribute.
	 * @return the customer
	 */
	public Customer getCustomer(final TmaBillingAccount item)
	{
		return getCustomer( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.customer</code> attribute. 
	 * @param value the customer
	 */
	public void setCustomer(final SessionContext ctx, final GenericItem item, final Customer value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaBillingAccount.CUSTOMER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaBillingAccount.customer</code> attribute. 
	 * @param value the customer
	 */
	public void setCustomer(final TmaBillingAccount item, final Customer value)
	{
		setCustomer( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.defaultTmaPoVariant</code> attribute.
	 * @return the defaultTmaPoVariant
	 */
	public TmaPoVariant getDefaultTmaPoVariant(final SessionContext ctx, final Product item)
	{
		return (TmaPoVariant)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DEFAULTTMAPOVARIANT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.defaultTmaPoVariant</code> attribute.
	 * @return the defaultTmaPoVariant
	 */
	public TmaPoVariant getDefaultTmaPoVariant(final TmaSimpleProductOffering item)
	{
		return getDefaultTmaPoVariant( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.defaultTmaPoVariant</code> attribute. 
	 * @param value the defaultTmaPoVariant
	 */
	public void setDefaultTmaPoVariant(final SessionContext ctx, final Product item, final TmaPoVariant value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DEFAULTTMAPOVARIANT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.defaultTmaPoVariant</code> attribute. 
	 * @param value the defaultTmaPoVariant
	 */
	public void setDefaultTmaPoVariant(final TmaSimpleProductOffering item, final TmaPoVariant value)
	{
		setDefaultTmaPoVariant( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveredDate</code> attribute.
	 * @return the deliveredDate
	 */
	public Date getDeliveredDate(final SessionContext ctx, final AbstractOrder item)
	{
		return (Date)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVEREDDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveredDate</code> attribute.
	 * @return the deliveredDate
	 */
	public Date getDeliveredDate(final AbstractOrder item)
	{
		return getDeliveredDate( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveredDate</code> attribute. 
	 * @param value the deliveredDate
	 */
	public void setDeliveredDate(final SessionContext ctx, final AbstractOrder item, final Date value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVEREDDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveredDate</code> attribute. 
	 * @param value the deliveredDate
	 */
	public void setDeliveredDate(final AbstractOrder item, final Date value)
	{
		setDeliveredDate( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveryPartnerName</code> attribute.
	 * @return the deliveryPartnerName
	 */
	public String getDeliveryPartnerName(final SessionContext ctx, final AbstractOrder item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVERYPARTNERNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveryPartnerName</code> attribute.
	 * @return the deliveryPartnerName
	 */
	public String getDeliveryPartnerName(final AbstractOrder item)
	{
		return getDeliveryPartnerName( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveryPartnerName</code> attribute. 
	 * @param value the deliveryPartnerName
	 */
	public void setDeliveryPartnerName(final SessionContext ctx, final AbstractOrder item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVERYPARTNERNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveryPartnerName</code> attribute. 
	 * @param value the deliveryPartnerName
	 */
	public void setDeliveryPartnerName(final AbstractOrder item, final String value)
	{
		setDeliveryPartnerName( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveryPartnerTrackingId</code> attribute.
	 * @return the deliveryPartnerTrackingId
	 */
	public String getDeliveryPartnerTrackingId(final SessionContext ctx, final AbstractOrder item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVERYPARTNERTRACKINGID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.deliveryPartnerTrackingId</code> attribute.
	 * @return the deliveryPartnerTrackingId
	 */
	public String getDeliveryPartnerTrackingId(final AbstractOrder item)
	{
		return getDeliveryPartnerTrackingId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveryPartnerTrackingId</code> attribute. 
	 * @param value the deliveryPartnerTrackingId
	 */
	public void setDeliveryPartnerTrackingId(final SessionContext ctx, final AbstractOrder item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.DELIVERYPARTNERTRACKINGID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.deliveryPartnerTrackingId</code> attribute. 
	 * @param value the deliveryPartnerTrackingId
	 */
	public void setDeliveryPartnerTrackingId(final AbstractOrder item, final String value)
	{
		setDeliveryPartnerTrackingId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.documents</code> attribute.
	 * @return the documents - Contains the localized documents.
	 */
	public MediaContainer getDocuments(final SessionContext ctx, final Product item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedTmaSimpleProductOffering.getDocuments requires a session language", 0 );
		}
		return (MediaContainer)item.getLocalizedProperty( ctx, BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DOCUMENTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.documents</code> attribute.
	 * @return the documents - Contains the localized documents.
	 */
	public MediaContainer getDocuments(final TmaSimpleProductOffering item)
	{
		return getDocuments( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @return the localized documents - Contains the localized documents.
	 */
	public Map<Language,MediaContainer> getAllDocuments(final SessionContext ctx, final Product item)
	{
		return (Map<Language,MediaContainer>)item.getAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DOCUMENTS,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @return the localized documents - Contains the localized documents.
	 */
	public Map<Language,MediaContainer> getAllDocuments(final TmaSimpleProductOffering item)
	{
		return getAllDocuments( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @param value the documents - Contains the localized documents.
	 */
	public void setDocuments(final SessionContext ctx, final Product item, final MediaContainer value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		if( ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedTmaSimpleProductOffering.setDocuments requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DOCUMENTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @param value the documents - Contains the localized documents.
	 */
	public void setDocuments(final TmaSimpleProductOffering item, final MediaContainer value)
	{
		setDocuments( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @param value the documents - Contains the localized documents.
	 */
	public void setAllDocuments(final SessionContext ctx, final Product item, final Map<Language,MediaContainer> value)
	{
		item.setAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.TmaSimpleProductOffering.DOCUMENTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSimpleProductOffering.documents</code> attribute. 
	 * @param value the documents - Contains the localized documents.
	 */
	public void setAllDocuments(final TmaSimpleProductOffering item, final Map<Language,MediaContainer> value)
	{
		setAllDocuments( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.firstName</code> attribute.
	 * @return the firstName
	 */
	public String getFirstName(final SessionContext ctx, final Customer item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Customer.FIRSTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.firstName</code> attribute.
	 * @return the firstName
	 */
	public String getFirstName(final Customer item)
	{
		return getFirstName( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.firstName</code> attribute. 
	 * @param value the firstName
	 */
	public void setFirstName(final SessionContext ctx, final Customer item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Customer.FIRSTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.firstName</code> attribute. 
	 * @param value the firstName
	 */
	public void setFirstName(final Customer item, final String value)
	{
		setFirstName( getSession().getSessionContext(), item, value );
	}
	
	@Override
	public String getName()
	{
		return BatelcoCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.idType</code> attribute.
	 * @return the idType - Customer id type chosen by the customer during registration.
	 */
	public EnumerationValue getIdType(final SessionContext ctx, final Customer item)
	{
		return (EnumerationValue)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Customer.IDTYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.idType</code> attribute.
	 * @return the idType - Customer id type chosen by the customer during registration.
	 */
	public EnumerationValue getIdType(final Customer item)
	{
		return getIdType( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.idType</code> attribute. 
	 * @param value the idType - Customer id type chosen by the customer during registration.
	 */
	public void setIdType(final SessionContext ctx, final Customer item, final EnumerationValue value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Customer.IDTYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.idType</code> attribute. 
	 * @param value the idType - Customer id type chosen by the customer during registration.
	 */
	public void setIdType(final Customer item, final EnumerationValue value)
	{
		setIdType( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.lastName</code> attribute.
	 * @return the lastName
	 */
	public String getLastName(final SessionContext ctx, final Customer item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Customer.LASTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.lastName</code> attribute.
	 * @return the lastName
	 */
	public String getLastName(final Customer item)
	{
		return getLastName( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.lastName</code> attribute. 
	 * @param value the lastName
	 */
	public void setLastName(final SessionContext ctx, final Customer item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Customer.LASTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.lastName</code> attribute. 
	 * @param value the lastName
	 */
	public void setLastName(final Customer item, final String value)
	{
		setLastName( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.mediaVersion</code> attribute.
	 * @return the mediaVersion - media version
	 */
	public MediaVersion getMediaVersion(final SessionContext ctx, final ConsentTemplate item)
	{
		return (MediaVersion)item.getProperty( ctx, BatelcoCoreConstants.Attributes.ConsentTemplate.MEDIAVERSION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.mediaVersion</code> attribute.
	 * @return the mediaVersion - media version
	 */
	public MediaVersion getMediaVersion(final ConsentTemplate item)
	{
		return getMediaVersion( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.mediaVersion</code> attribute. 
	 * @param value the mediaVersion - media version
	 */
	public void setMediaVersion(final SessionContext ctx, final ConsentTemplate item, final MediaVersion value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.ConsentTemplate.MEDIAVERSION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.mediaVersion</code> attribute. 
	 * @param value the mediaVersion - media version
	 */
	public void setMediaVersion(final ConsentTemplate item, final MediaVersion value)
	{
		setMediaVersion( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.online</code> attribute.
	 * @return the online
	 */
	public Boolean isOnline(final SessionContext ctx, final StandardPaymentMode item)
	{
		return (Boolean)item.getProperty( ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.ONLINE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.online</code> attribute.
	 * @return the online
	 */
	public Boolean isOnline(final StandardPaymentMode item)
	{
		return isOnline( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @return the online
	 */
	public boolean isOnlineAsPrimitive(final SessionContext ctx, final StandardPaymentMode item)
	{
		Boolean value = isOnline( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @return the online
	 */
	public boolean isOnlineAsPrimitive(final StandardPaymentMode item)
	{
		return isOnlineAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @param value the online
	 */
	public void setOnline(final SessionContext ctx, final StandardPaymentMode item, final Boolean value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.ONLINE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @param value the online
	 */
	public void setOnline(final StandardPaymentMode item, final Boolean value)
	{
		setOnline( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @param value the online
	 */
	public void setOnline(final SessionContext ctx, final StandardPaymentMode item, final boolean value)
	{
		setOnline( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.online</code> attribute. 
	 * @param value the online
	 */
	public void setOnline(final StandardPaymentMode item, final boolean value)
	{
		setOnline( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.outstandingAmount</code> attribute.
	 * @return the outstandingAmount
	 */
	public Double getOutstandingAmount(final SessionContext ctx, final AbstractOrder item)
	{
		return (Double)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.OUTSTANDINGAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.outstandingAmount</code> attribute.
	 * @return the outstandingAmount
	 */
	public Double getOutstandingAmount(final AbstractOrder item)
	{
		return getOutstandingAmount( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @return the outstandingAmount
	 */
	public double getOutstandingAmountAsPrimitive(final SessionContext ctx, final AbstractOrder item)
	{
		Double value = getOutstandingAmount( ctx,item );
		return value != null ? value.doubleValue() : 0.0d;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @return the outstandingAmount
	 */
	public double getOutstandingAmountAsPrimitive(final AbstractOrder item)
	{
		return getOutstandingAmountAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @param value the outstandingAmount
	 */
	public void setOutstandingAmount(final SessionContext ctx, final AbstractOrder item, final Double value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.OUTSTANDINGAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @param value the outstandingAmount
	 */
	public void setOutstandingAmount(final AbstractOrder item, final Double value)
	{
		setOutstandingAmount( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @param value the outstandingAmount
	 */
	public void setOutstandingAmount(final SessionContext ctx, final AbstractOrder item, final double value)
	{
		setOutstandingAmount( ctx, item, Double.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.outstandingAmount</code> attribute. 
	 * @param value the outstandingAmount
	 */
	public void setOutstandingAmount(final AbstractOrder item, final double value)
	{
		setOutstandingAmount( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parent</code> attribute.
	 * @return the parent
	 */
	public StandardPaymentMode getParent(final SessionContext ctx, final StandardPaymentMode item)
	{
		return (StandardPaymentMode)item.getProperty( ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PARENT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parent</code> attribute.
	 * @return the parent
	 */
	public StandardPaymentMode getParent(final StandardPaymentMode item)
	{
		return getParent( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parent</code> attribute. 
	 * @param value the parent
	 */
	public void setParent(final SessionContext ctx, final StandardPaymentMode item, final StandardPaymentMode value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PARENT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parent</code> attribute. 
	 * @param value the parent
	 */
	public void setParent(final StandardPaymentMode item, final StandardPaymentMode value)
	{
		setParent( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parentPOS</code> attribute.
	 * @return the parentPOS
	 */
	 Integer getParentPOS(final SessionContext ctx, final StandardPaymentMode item)
	{
		return (Integer)item.getProperty( ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PARENTPOS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parentPOS</code> attribute.
	 * @return the parentPOS
	 */
	 Integer getParentPOS(final StandardPaymentMode item)
	{
		return getParentPOS( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @return the parentPOS
	 */
	 int getParentPOSAsPrimitive(final SessionContext ctx, final StandardPaymentMode item)
	{
		Integer value = getParentPOS( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @return the parentPOS
	 */
	 int getParentPOSAsPrimitive(final StandardPaymentMode item)
	{
		return getParentPOSAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @param value the parentPOS
	 */
	 void setParentPOS(final SessionContext ctx, final StandardPaymentMode item, final Integer value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PARENTPOS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @param value the parentPOS
	 */
	 void setParentPOS(final StandardPaymentMode item, final Integer value)
	{
		setParentPOS( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @param value the parentPOS
	 */
	 void setParentPOS(final SessionContext ctx, final StandardPaymentMode item, final int value)
	{
		setParentPOS( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.parentPOS</code> attribute. 
	 * @param value the parentPOS
	 */
	 void setParentPOS(final StandardPaymentMode item, final int value)
	{
		setParentPOS( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.paymentEvidence</code> attribute.
	 * @return the paymentEvidence
	 */
	public Media getPaymentEvidence(final SessionContext ctx, final AbstractOrder item)
	{
		return (Media)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.PAYMENTEVIDENCE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.paymentEvidence</code> attribute.
	 * @return the paymentEvidence
	 */
	public Media getPaymentEvidence(final AbstractOrder item)
	{
		return getPaymentEvidence( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.paymentEvidence</code> attribute. 
	 * @param value the paymentEvidence
	 */
	public void setPaymentEvidence(final SessionContext ctx, final AbstractOrder item, final Media value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.PAYMENTEVIDENCE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.paymentEvidence</code> attribute. 
	 * @param value the paymentEvidence
	 */
	public void setPaymentEvidence(final AbstractOrder item, final Media value)
	{
		setPaymentEvidence( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.paymentInfo</code> attribute.
	 * @return the paymentInfo
	 */
	public BatelcoPaymentInfo getPaymentInfo(final SessionContext ctx, final AbstractOrderEntry item)
	{
		return (BatelcoPaymentInfo)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrderEntry.PAYMENTINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.paymentInfo</code> attribute.
	 * @return the paymentInfo
	 */
	public BatelcoPaymentInfo getPaymentInfo(final AbstractOrderEntry item)
	{
		return getPaymentInfo( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.paymentInfo</code> attribute. 
	 * @param value the paymentInfo
	 */
	public void setPaymentInfo(final SessionContext ctx, final AbstractOrderEntry item, final BatelcoPaymentInfo value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrderEntry.PAYMENTINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.paymentInfo</code> attribute. 
	 * @param value the paymentInfo
	 */
	public void setPaymentInfo(final AbstractOrderEntry item, final BatelcoPaymentInfo value)
	{
		setPaymentInfo( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.paymentTypeId</code> attribute.
	 * @return the paymentTypeId - Stores the payment type identifier sent to payment gateway.
	 */
	public String getPaymentTypeId(final SessionContext ctx, final StandardPaymentMode item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PAYMENTTYPEID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>StandardPaymentMode.paymentTypeId</code> attribute.
	 * @return the paymentTypeId - Stores the payment type identifier sent to payment gateway.
	 */
	public String getPaymentTypeId(final StandardPaymentMode item)
	{
		return getPaymentTypeId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.paymentTypeId</code> attribute. 
	 * @param value the paymentTypeId - Stores the payment type identifier sent to payment gateway.
	 */
	public void setPaymentTypeId(final SessionContext ctx, final StandardPaymentMode item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.StandardPaymentMode.PAYMENTTYPEID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>StandardPaymentMode.paymentTypeId</code> attribute. 
	 * @param value the paymentTypeId - Stores the payment type identifier sent to payment gateway.
	 */
	public void setPaymentTypeId(final StandardPaymentMode item, final String value)
	{
		setPaymentTypeId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.remarks</code> attribute.
	 * @return the remarks
	 */
	public String getRemarks(final SessionContext ctx, final AbstractOrder item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.REMARKS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.remarks</code> attribute.
	 * @return the remarks
	 */
	public String getRemarks(final AbstractOrder item)
	{
		return getRemarks( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.remarks</code> attribute. 
	 * @param value the remarks
	 */
	public void setRemarks(final SessionContext ctx, final AbstractOrder item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.REMARKS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.remarks</code> attribute. 
	 * @param value the remarks
	 */
	public void setRemarks(final AbstractOrder item, final String value)
	{
		setRemarks( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.seibelOrderId</code> attribute.
	 * @return the seibelOrderId
	 */
	public String getSeibelOrderId(final SessionContext ctx, final AbstractOrder item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.AbstractOrder.SEIBELORDERID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrder.seibelOrderId</code> attribute.
	 * @return the seibelOrderId
	 */
	public String getSeibelOrderId(final AbstractOrder item)
	{
		return getSeibelOrderId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.seibelOrderId</code> attribute. 
	 * @param value the seibelOrderId
	 */
	public void setSeibelOrderId(final SessionContext ctx, final AbstractOrder item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.AbstractOrder.SEIBELORDERID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrder.seibelOrderId</code> attribute. 
	 * @param value the seibelOrderId
	 */
	public void setSeibelOrderId(final AbstractOrder item, final String value)
	{
		setSeibelOrderId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.slang</code> attribute.
	 * @return the slang - product code
	 */
	public String getSlang(final SessionContext ctx, final Product item)
	{
		return (String)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Product.SLANG);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.slang</code> attribute.
	 * @return the slang - product code
	 */
	public String getSlang(final Product item)
	{
		return getSlang( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.slang</code> attribute. 
	 * @param value the slang - product code
	 */
	public void setSlang(final SessionContext ctx, final Product item, final String value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Product.SLANG,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.slang</code> attribute. 
	 * @param value the slang - product code
	 */
	public void setSlang(final Product item, final String value)
	{
		setSlang( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.subscriptionBaseStatus</code> attribute.
	 * @return the subscriptionBaseStatus
	 */
	public EnumerationValue getSubscriptionBaseStatus(final SessionContext ctx, final GenericItem item)
	{
		return (EnumerationValue)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.SUBSCRIPTIONBASESTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.subscriptionBaseStatus</code> attribute.
	 * @return the subscriptionBaseStatus
	 */
	public EnumerationValue getSubscriptionBaseStatus(final TmaSubscriptionBase item)
	{
		return getSubscriptionBaseStatus( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.subscriptionBaseStatus</code> attribute. 
	 * @param value the subscriptionBaseStatus
	 */
	public void setSubscriptionBaseStatus(final SessionContext ctx, final GenericItem item, final EnumerationValue value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.SUBSCRIPTIONBASESTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.subscriptionBaseStatus</code> attribute. 
	 * @param value the subscriptionBaseStatus
	 */
	public void setSubscriptionBaseStatus(final TmaSubscriptionBase item, final EnumerationValue value)
	{
		setSubscriptionBaseStatus( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.subscriptionBaseType</code> attribute.
	 * @return the subscriptionBaseType
	 */
	public EnumerationValue getSubscriptionBaseType(final SessionContext ctx, final GenericItem item)
	{
		return (EnumerationValue)item.getProperty( ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.SUBSCRIPTIONBASETYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmaSubscriptionBase.subscriptionBaseType</code> attribute.
	 * @return the subscriptionBaseType
	 */
	public EnumerationValue getSubscriptionBaseType(final TmaSubscriptionBase item)
	{
		return getSubscriptionBaseType( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.subscriptionBaseType</code> attribute. 
	 * @param value the subscriptionBaseType
	 */
	public void setSubscriptionBaseType(final SessionContext ctx, final GenericItem item, final EnumerationValue value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.TmaSubscriptionBase.SUBSCRIPTIONBASETYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmaSubscriptionBase.subscriptionBaseType</code> attribute. 
	 * @param value the subscriptionBaseType
	 */
	public void setSubscriptionBaseType(final TmaSubscriptionBase item, final EnumerationValue value)
	{
		setSubscriptionBaseType( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.title</code> attribute.
	 * @return the title - Attribute use for displaying the title of a category page
	 */
	public String getTitle(final SessionContext ctx, final Category item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCategory.getTitle requires a session language", 0 );
		}
		return (String)item.getLocalizedProperty( ctx, BatelcoCoreConstants.Attributes.Category.TITLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.title</code> attribute.
	 * @return the title - Attribute use for displaying the title of a category page
	 */
	public String getTitle(final Category item)
	{
		return getTitle( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.title</code> attribute. 
	 * @return the localized title - Attribute use for displaying the title of a category page
	 */
	public Map<Language,String> getAllTitle(final SessionContext ctx, final Category item)
	{
		return (Map<Language,String>)item.getAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.Category.TITLE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.title</code> attribute. 
	 * @return the localized title - Attribute use for displaying the title of a category page
	 */
	public Map<Language,String> getAllTitle(final Category item)
	{
		return getAllTitle( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.title</code> attribute. 
	 * @param value the title - Attribute use for displaying the title of a category page
	 */
	public void setTitle(final SessionContext ctx, final Category item, final String value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		if( ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCategory.setTitle requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, BatelcoCoreConstants.Attributes.Category.TITLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.title</code> attribute. 
	 * @param value the title - Attribute use for displaying the title of a category page
	 */
	public void setTitle(final Category item, final String value)
	{
		setTitle( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.title</code> attribute. 
	 * @param value the title - Attribute use for displaying the title of a category page
	 */
	public void setAllTitle(final SessionContext ctx, final Category item, final Map<Language,String> value)
	{
		item.setAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.Category.TITLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.title</code> attribute. 
	 * @param value the title - Attribute use for displaying the title of a category page
	 */
	public void setAllTitle(final Category item, final Map<Language,String> value)
	{
		setAllTitle( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.vatDescription</code> attribute.
	 * @return the vatDescription - Localized VAT Description
	 */
	public String getVatDescription(final SessionContext ctx, final Product item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedProduct.getVatDescription requires a session language", 0 );
		}
		return (String)item.getLocalizedProperty( ctx, BatelcoCoreConstants.Attributes.Product.VATDESCRIPTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.vatDescription</code> attribute.
	 * @return the vatDescription - Localized VAT Description
	 */
	public String getVatDescription(final Product item)
	{
		return getVatDescription( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.vatDescription</code> attribute. 
	 * @return the localized vatDescription - Localized VAT Description
	 */
	public Map<Language,String> getAllVatDescription(final SessionContext ctx, final Product item)
	{
		return (Map<Language,String>)item.getAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.Product.VATDESCRIPTION,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.vatDescription</code> attribute. 
	 * @return the localized vatDescription - Localized VAT Description
	 */
	public Map<Language,String> getAllVatDescription(final Product item)
	{
		return getAllVatDescription( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.vatDescription</code> attribute. 
	 * @param value the vatDescription - Localized VAT Description
	 */
	public void setVatDescription(final SessionContext ctx, final Product item, final String value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		if( ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedProduct.setVatDescription requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, BatelcoCoreConstants.Attributes.Product.VATDESCRIPTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.vatDescription</code> attribute. 
	 * @param value the vatDescription - Localized VAT Description
	 */
	public void setVatDescription(final Product item, final String value)
	{
		setVatDescription( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.vatDescription</code> attribute. 
	 * @param value the vatDescription - Localized VAT Description
	 */
	public void setAllVatDescription(final SessionContext ctx, final Product item, final Map<Language,String> value)
	{
		item.setAllLocalizedProperties(ctx,BatelcoCoreConstants.Attributes.Product.VATDESCRIPTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.vatDescription</code> attribute. 
	 * @param value the vatDescription - Localized VAT Description
	 */
	public void setAllVatDescription(final Product item, final Map<Language,String> value)
	{
		setAllVatDescription( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.visible</code> attribute.
	 * @return the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public Boolean isVisible(final SessionContext ctx, final Category item)
	{
		return (Boolean)item.getProperty( ctx, BatelcoCoreConstants.Attributes.Category.VISIBLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.visible</code> attribute.
	 * @return the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public Boolean isVisible(final Category item)
	{
		return isVisible( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.visible</code> attribute. 
	 * @return the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public boolean isVisibleAsPrimitive(final SessionContext ctx, final Category item)
	{
		Boolean value = isVisible( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Category.visible</code> attribute. 
	 * @return the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public boolean isVisibleAsPrimitive(final Category item)
	{
		return isVisibleAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.visible</code> attribute. 
	 * @param value the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public void setVisible(final SessionContext ctx, final Category item, final Boolean value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.Category.VISIBLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.visible</code> attribute. 
	 * @param value the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public void setVisible(final Category item, final Boolean value)
	{
		setVisible( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.visible</code> attribute. 
	 * @param value the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public void setVisible(final SessionContext ctx, final Category item, final boolean value)
	{
		setVisible( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Category.visible</code> attribute. 
	 * @param value the visible - Flag to show or hide the category from the breadcrumb section
	 */
	public void setVisible(final Category item, final boolean value)
	{
		setVisible( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.withdrawable</code> attribute.
	 * @return the withdrawable - Set to true, when consent can be withdrawn
	 */
	public Boolean isWithdrawable(final SessionContext ctx, final ConsentTemplate item)
	{
		return (Boolean)item.getProperty( ctx, BatelcoCoreConstants.Attributes.ConsentTemplate.WITHDRAWABLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.withdrawable</code> attribute.
	 * @return the withdrawable - Set to true, when consent can be withdrawn
	 */
	public Boolean isWithdrawable(final ConsentTemplate item)
	{
		return isWithdrawable( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @return the withdrawable - Set to true, when consent can be withdrawn
	 */
	public boolean isWithdrawableAsPrimitive(final SessionContext ctx, final ConsentTemplate item)
	{
		Boolean value = isWithdrawable( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @return the withdrawable - Set to true, when consent can be withdrawn
	 */
	public boolean isWithdrawableAsPrimitive(final ConsentTemplate item)
	{
		return isWithdrawableAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @param value the withdrawable - Set to true, when consent can be withdrawn
	 */
	public void setWithdrawable(final SessionContext ctx, final ConsentTemplate item, final Boolean value)
	{
		item.setProperty(ctx, BatelcoCoreConstants.Attributes.ConsentTemplate.WITHDRAWABLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @param value the withdrawable - Set to true, when consent can be withdrawn
	 */
	public void setWithdrawable(final ConsentTemplate item, final Boolean value)
	{
		setWithdrawable( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @param value the withdrawable - Set to true, when consent can be withdrawn
	 */
	public void setWithdrawable(final SessionContext ctx, final ConsentTemplate item, final boolean value)
	{
		setWithdrawable( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>ConsentTemplate.withdrawable</code> attribute. 
	 * @param value the withdrawable - Set to true, when consent can be withdrawn
	 */
	public void setWithdrawable(final ConsentTemplate item, final boolean value)
	{
		setWithdrawable( getSession().getSessionContext(), item, value );
	}
	
}
