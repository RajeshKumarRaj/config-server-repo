/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.core.jalo;

import bt.batelco.core.constants.BatelcoCoreConstants;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.jalo.GenericItem BatelcoPaymentInfo}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBatelcoPaymentInfo extends GenericItem
{
	/** Qualifier of the <code>BatelcoPaymentInfo.serviceNumber</code> attribute **/
	public static final String SERVICENUMBER = "serviceNumber";
	/** Qualifier of the <code>BatelcoPaymentInfo.serviceType</code> attribute **/
	public static final String SERVICETYPE = "serviceType";
	/** Qualifier of the <code>BatelcoPaymentInfo.serviceStatus</code> attribute **/
	public static final String SERVICESTATUS = "serviceStatus";
	/** Qualifier of the <code>BatelcoPaymentInfo.billProfile</code> attribute **/
	public static final String BILLPROFILE = "billProfile";
	/** Qualifier of the <code>BatelcoPaymentInfo.accountNumber</code> attribute **/
	public static final String ACCOUNTNUMBER = "accountNumber";
	/** Qualifier of the <code>BatelcoPaymentInfo.accountStatus</code> attribute **/
	public static final String ACCOUNTSTATUS = "accountStatus";
	/** Qualifier of the <code>BatelcoPaymentInfo.authcode</code> attribute **/
	public static final String AUTHCODE = "authcode";
	/** Qualifier of the <code>BatelcoPaymentInfo.paymentRefNo</code> attribute **/
	public static final String PAYMENTREFNO = "paymentRefNo";
	/** Qualifier of the <code>BatelcoPaymentInfo.status</code> attribute **/
	public static final String STATUS = "status";
	/** Qualifier of the <code>BatelcoPaymentInfo.transactionNo</code> attribute **/
	public static final String TRANSACTIONNO = "transactionNo";
	/** Qualifier of the <code>BatelcoPaymentInfo.transactionDateTime</code> attribute **/
	public static final String TRANSACTIONDATETIME = "transactionDateTime";
	/** Qualifier of the <code>BatelcoPaymentInfo.totalAmount</code> attribute **/
	public static final String TOTALAMOUNT = "totalAmount";
	/** Qualifier of the <code>BatelcoPaymentInfo.failMsg</code> attribute **/
	public static final String FAILMSG = "failMsg";
	/** Qualifier of the <code>BatelcoPaymentInfo.paymentID</code> attribute **/
	public static final String PAYMENTID = "paymentID";
	/** Qualifier of the <code>BatelcoPaymentInfo.paymentResponse</code> attribute **/
	public static final String PAYMENTRESPONSE = "paymentResponse";
	/** Qualifier of the <code>BatelcoPaymentInfo.paymentStatus</code> attribute **/
	public static final String PAYMENTSTATUS = "paymentStatus";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(SERVICENUMBER, AttributeMode.INITIAL);
		tmp.put(SERVICETYPE, AttributeMode.INITIAL);
		tmp.put(SERVICESTATUS, AttributeMode.INITIAL);
		tmp.put(BILLPROFILE, AttributeMode.INITIAL);
		tmp.put(ACCOUNTNUMBER, AttributeMode.INITIAL);
		tmp.put(ACCOUNTSTATUS, AttributeMode.INITIAL);
		tmp.put(AUTHCODE, AttributeMode.INITIAL);
		tmp.put(PAYMENTREFNO, AttributeMode.INITIAL);
		tmp.put(STATUS, AttributeMode.INITIAL);
		tmp.put(TRANSACTIONNO, AttributeMode.INITIAL);
		tmp.put(TRANSACTIONDATETIME, AttributeMode.INITIAL);
		tmp.put(TOTALAMOUNT, AttributeMode.INITIAL);
		tmp.put(FAILMSG, AttributeMode.INITIAL);
		tmp.put(PAYMENTID, AttributeMode.INITIAL);
		tmp.put(PAYMENTRESPONSE, AttributeMode.INITIAL);
		tmp.put(PAYMENTSTATUS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.accountNumber</code> attribute.
	 * @return the accountNumber - Represents the account number.
	 */
	public String getAccountNumber(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ACCOUNTNUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.accountNumber</code> attribute.
	 * @return the accountNumber - Represents the account number.
	 */
	public String getAccountNumber()
	{
		return getAccountNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.accountNumber</code> attribute. 
	 * @param value the accountNumber - Represents the account number.
	 */
	public void setAccountNumber(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ACCOUNTNUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.accountNumber</code> attribute. 
	 * @param value the accountNumber - Represents the account number.
	 */
	public void setAccountNumber(final String value)
	{
		setAccountNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.accountStatus</code> attribute.
	 * @return the accountStatus - Represents the account status.
	 */
	public EnumerationValue getAccountStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, ACCOUNTSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.accountStatus</code> attribute.
	 * @return the accountStatus - Represents the account status.
	 */
	public EnumerationValue getAccountStatus()
	{
		return getAccountStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.accountStatus</code> attribute. 
	 * @param value the accountStatus - Represents the account status.
	 */
	public void setAccountStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, ACCOUNTSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.accountStatus</code> attribute. 
	 * @param value the accountStatus - Represents the account status.
	 */
	public void setAccountStatus(final EnumerationValue value)
	{
		setAccountStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.authcode</code> attribute.
	 * @return the authcode - Represents the payment authentication code.
	 */
	public String getAuthcode(final SessionContext ctx)
	{
		return (String)getProperty( ctx, AUTHCODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.authcode</code> attribute.
	 * @return the authcode - Represents the payment authentication code.
	 */
	public String getAuthcode()
	{
		return getAuthcode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.authcode</code> attribute. 
	 * @param value the authcode - Represents the payment authentication code.
	 */
	public void setAuthcode(final SessionContext ctx, final String value)
	{
		setProperty(ctx, AUTHCODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.authcode</code> attribute. 
	 * @param value the authcode - Represents the payment authentication code.
	 */
	public void setAuthcode(final String value)
	{
		setAuthcode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.billProfile</code> attribute.
	 * @return the billProfile - Represents the bill profile.
	 */
	public String getBillProfile(final SessionContext ctx)
	{
		return (String)getProperty( ctx, BILLPROFILE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.billProfile</code> attribute.
	 * @return the billProfile - Represents the bill profile.
	 */
	public String getBillProfile()
	{
		return getBillProfile( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.billProfile</code> attribute. 
	 * @param value the billProfile - Represents the bill profile.
	 */
	public void setBillProfile(final SessionContext ctx, final String value)
	{
		setProperty(ctx, BILLPROFILE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.billProfile</code> attribute. 
	 * @param value the billProfile - Represents the bill profile.
	 */
	public void setBillProfile(final String value)
	{
		setBillProfile( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.failMsg</code> attribute.
	 * @return the failMsg - Represents the payment transactionNo.
	 */
	public String getFailMsg(final SessionContext ctx)
	{
		return (String)getProperty( ctx, FAILMSG);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.failMsg</code> attribute.
	 * @return the failMsg - Represents the payment transactionNo.
	 */
	public String getFailMsg()
	{
		return getFailMsg( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.failMsg</code> attribute. 
	 * @param value the failMsg - Represents the payment transactionNo.
	 */
	public void setFailMsg(final SessionContext ctx, final String value)
	{
		setProperty(ctx, FAILMSG,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.failMsg</code> attribute. 
	 * @param value the failMsg - Represents the payment transactionNo.
	 */
	public void setFailMsg(final String value)
	{
		setFailMsg( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentID</code> attribute.
	 * @return the paymentID - Represents the payment transactionNo.
	 */
	public String getPaymentID(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentID</code> attribute.
	 * @return the paymentID - Represents the payment transactionNo.
	 */
	public String getPaymentID()
	{
		return getPaymentID( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentID</code> attribute. 
	 * @param value the paymentID - Represents the payment transactionNo.
	 */
	public void setPaymentID(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentID</code> attribute. 
	 * @param value the paymentID - Represents the payment transactionNo.
	 */
	public void setPaymentID(final String value)
	{
		setPaymentID( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentRefNo</code> attribute.
	 * @return the paymentRefNo - Represents the payment reference no.
	 */
	public String getPaymentRefNo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTREFNO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentRefNo</code> attribute.
	 * @return the paymentRefNo - Represents the payment reference no.
	 */
	public String getPaymentRefNo()
	{
		return getPaymentRefNo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentRefNo</code> attribute. 
	 * @param value the paymentRefNo - Represents the payment reference no.
	 */
	public void setPaymentRefNo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTREFNO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentRefNo</code> attribute. 
	 * @param value the paymentRefNo - Represents the payment reference no.
	 */
	public void setPaymentRefNo(final String value)
	{
		setPaymentRefNo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentResponse</code> attribute.
	 * @return the paymentResponse - Represents the payment transactionNo.
	 */
	public String getPaymentResponse(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTRESPONSE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentResponse</code> attribute.
	 * @return the paymentResponse - Represents the payment transactionNo.
	 */
	public String getPaymentResponse()
	{
		return getPaymentResponse( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentResponse</code> attribute. 
	 * @param value the paymentResponse - Represents the payment transactionNo.
	 */
	public void setPaymentResponse(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTRESPONSE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentResponse</code> attribute. 
	 * @param value the paymentResponse - Represents the payment transactionNo.
	 */
	public void setPaymentResponse(final String value)
	{
		setPaymentResponse( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentStatus</code> attribute.
	 * @return the paymentStatus - Represents the payment status - Enum.
	 */
	public EnumerationValue getPaymentStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, PAYMENTSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.paymentStatus</code> attribute.
	 * @return the paymentStatus - Represents the payment status - Enum.
	 */
	public EnumerationValue getPaymentStatus()
	{
		return getPaymentStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentStatus</code> attribute. 
	 * @param value the paymentStatus - Represents the payment status - Enum.
	 */
	public void setPaymentStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, PAYMENTSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.paymentStatus</code> attribute. 
	 * @param value the paymentStatus - Represents the payment status - Enum.
	 */
	public void setPaymentStatus(final EnumerationValue value)
	{
		setPaymentStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceNumber</code> attribute.
	 * @return the serviceNumber - Represents the service number.
	 */
	public String getServiceNumber(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SERVICENUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceNumber</code> attribute.
	 * @return the serviceNumber - Represents the service number.
	 */
	public String getServiceNumber()
	{
		return getServiceNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceNumber</code> attribute. 
	 * @param value the serviceNumber - Represents the service number.
	 */
	public void setServiceNumber(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SERVICENUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceNumber</code> attribute. 
	 * @param value the serviceNumber - Represents the service number.
	 */
	public void setServiceNumber(final String value)
	{
		setServiceNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceStatus</code> attribute.
	 * @return the serviceStatus - Represents the service status.
	 */
	public EnumerationValue getServiceStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, SERVICESTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceStatus</code> attribute.
	 * @return the serviceStatus - Represents the service status.
	 */
	public EnumerationValue getServiceStatus()
	{
		return getServiceStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceStatus</code> attribute. 
	 * @param value the serviceStatus - Represents the service status.
	 */
	public void setServiceStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, SERVICESTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceStatus</code> attribute. 
	 * @param value the serviceStatus - Represents the service status.
	 */
	public void setServiceStatus(final EnumerationValue value)
	{
		setServiceStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceType</code> attribute.
	 * @return the serviceType - Represents the service type.
	 */
	public EnumerationValue getServiceType(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, SERVICETYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.serviceType</code> attribute.
	 * @return the serviceType - Represents the service type.
	 */
	public EnumerationValue getServiceType()
	{
		return getServiceType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceType</code> attribute. 
	 * @param value the serviceType - Represents the service type.
	 */
	public void setServiceType(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, SERVICETYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.serviceType</code> attribute. 
	 * @param value the serviceType - Represents the service type.
	 */
	public void setServiceType(final EnumerationValue value)
	{
		setServiceType( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.status</code> attribute.
	 * @return the status - Represents the payment status.
	 */
	public String getStatus(final SessionContext ctx)
	{
		return (String)getProperty( ctx, STATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.status</code> attribute.
	 * @return the status - Represents the payment status.
	 */
	public String getStatus()
	{
		return getStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.status</code> attribute. 
	 * @param value the status - Represents the payment status.
	 */
	public void setStatus(final SessionContext ctx, final String value)
	{
		setProperty(ctx, STATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.status</code> attribute. 
	 * @param value the status - Represents the payment status.
	 */
	public void setStatus(final String value)
	{
		setStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute.
	 * @return the totalAmount
	 */
	public Double getTotalAmount(final SessionContext ctx)
	{
		return (Double)getProperty( ctx, TOTALAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute.
	 * @return the totalAmount
	 */
	public Double getTotalAmount()
	{
		return getTotalAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @return the totalAmount
	 */
	public double getTotalAmountAsPrimitive(final SessionContext ctx)
	{
		Double value = getTotalAmount( ctx );
		return value != null ? value.doubleValue() : 0.0d;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @return the totalAmount
	 */
	public double getTotalAmountAsPrimitive()
	{
		return getTotalAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @param value the totalAmount
	 */
	public void setTotalAmount(final SessionContext ctx, final Double value)
	{
		setProperty(ctx, TOTALAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @param value the totalAmount
	 */
	public void setTotalAmount(final Double value)
	{
		setTotalAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @param value the totalAmount
	 */
	public void setTotalAmount(final SessionContext ctx, final double value)
	{
		setTotalAmount( ctx,Double.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.totalAmount</code> attribute. 
	 * @param value the totalAmount
	 */
	public void setTotalAmount(final double value)
	{
		setTotalAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.transactionDateTime</code> attribute.
	 * @return the transactionDateTime - Represents the payment transaction Date and Time.
	 */
	public Date getTransactionDateTime(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, TRANSACTIONDATETIME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.transactionDateTime</code> attribute.
	 * @return the transactionDateTime - Represents the payment transaction Date and Time.
	 */
	public Date getTransactionDateTime()
	{
		return getTransactionDateTime( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.transactionDateTime</code> attribute. 
	 * @param value the transactionDateTime - Represents the payment transaction Date and Time.
	 */
	public void setTransactionDateTime(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, TRANSACTIONDATETIME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.transactionDateTime</code> attribute. 
	 * @param value the transactionDateTime - Represents the payment transaction Date and Time.
	 */
	public void setTransactionDateTime(final Date value)
	{
		setTransactionDateTime( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.transactionNo</code> attribute.
	 * @return the transactionNo - Represents the payment transactionNo.
	 */
	public String getTransactionNo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, TRANSACTIONNO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BatelcoPaymentInfo.transactionNo</code> attribute.
	 * @return the transactionNo - Represents the payment transactionNo.
	 */
	public String getTransactionNo()
	{
		return getTransactionNo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.transactionNo</code> attribute. 
	 * @param value the transactionNo - Represents the payment transactionNo.
	 */
	public void setTransactionNo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, TRANSACTIONNO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BatelcoPaymentInfo.transactionNo</code> attribute. 
	 * @param value the transactionNo - Represents the payment transactionNo.
	 */
	public void setTransactionNo(final String value)
	{
		setTransactionNo( getSession().getSessionContext(), value );
	}
	
}
