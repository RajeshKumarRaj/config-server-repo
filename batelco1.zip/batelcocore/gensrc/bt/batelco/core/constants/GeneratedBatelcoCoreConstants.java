/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.core.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBatelcoCoreConstants
{
	public static final String EXTENSIONNAME = "batelcocore";
	public static class TC
	{
		public static final String BATELCOBILLINGPROFILE = "BatelcoBillingProfile".intern();
		public static final String BATELCOPAYMENTINFO = "BatelcoPaymentInfo".intern();
		public static final String BILLINGACCOUNTSTATUS = "BillingAccountStatus".intern();
		public static final String CMSMEDIALINKCOMPONENT = "CMSMediaLinkComponent".intern();
		public static final String CUSTOMERIDTYPE = "CustomerIdType".intern();
		public static final String EXPORTPRODUCTCRONJOB = "ExportProductCronJob".intern();
		public static final String MEDIAVERSION = "MediaVersion".intern();
		public static final String ORDERSTATUSCHANGEDPROCESS = "OrderStatusChangedProcess".intern();
		public static final String SUBSCRIPTIONBASESTATUS = "SubscriptionBaseStatus".intern();
		public static final String SUBSCRIPTIONBASETYPE = "SubscriptionBaseType".intern();
		public static final String SWATCHCOLORENUM = "SwatchColorEnum".intern();
	}
	public static class Attributes
	{
		public static class AbstractOrder
		{
			public static final String AWAITINGPAYMENTSTARTDATE = "awaitingPaymentStartDate".intern();
			public static final String CPRBACK = "cprBack".intern();
			public static final String CPRFRONT = "cprFront".intern();
			public static final String CPRID = "cprId".intern();
			public static final String DELIVEREDDATE = "deliveredDate".intern();
			public static final String DELIVERYPARTNERNAME = "deliveryPartnerName".intern();
			public static final String DELIVERYPARTNERTRACKINGID = "deliveryPartnerTrackingId".intern();
			public static final String OUTSTANDINGAMOUNT = "outstandingAmount".intern();
			public static final String PAYMENTEVIDENCE = "paymentEvidence".intern();
			public static final String PREORDER = "preorder".intern();
			public static final String REMARKS = "remarks".intern();
			public static final String SEIBELORDERID = "seibelOrderId".intern();
		}
		public static class AbstractOrderEntry
		{
			public static final String ACQUISITIONFORM = "acquisitionForm".intern();
			public static final String PAYMENTINFO = "paymentInfo".intern();
		}
		public static class Cart
		{
			public static final String BATELCOPAYMENTINFO = "batelcoPaymentInfo".intern();
		}
		public static class Category
		{
			public static final String TITLE = "title".intern();
			public static final String VISIBLE = "visible".intern();
		}
		public static class ConsentTemplate
		{
			public static final String MEDIAVERSION = "mediaVersion".intern();
			public static final String WITHDRAWABLE = "withdrawable".intern();
		}
		public static class Customer
		{
			public static final String ACCOUNTNUMBER = "accountNumber".intern();
			public static final String BILLINGACCOUNTS = "billingAccounts".intern();
			public static final String CPRID = "cprId".intern();
			public static final String FIRSTNAME = "firstName".intern();
			public static final String IDTYPE = "idType".intern();
			public static final String LASTNAME = "lastName".intern();
		}
		public static class Product
		{
			public static final String PREORDERPRODUCT = "preorderProduct".intern();
			public static final String SLANG = "slang".intern();
			public static final String VATDESCRIPTION = "vatDescription".intern();
		}
		public static class StandardPaymentMode
		{
			public static final String CHILDREN = "children".intern();
			public static final String ONLINE = "online".intern();
			public static final String PARENT = "parent".intern();
			public static final String PARENTPOS = "parentPOS".intern();
			public static final String PAYMENTTYPEID = "paymentTypeId".intern();
		}
		public static class SubscriptionPricePlan
		{
			public static final String MAINAFFECTEDPRODUCTOFFERING = "mainAffectedProductOffering".intern();
			public static final String MAINPRODUCT = "mainProduct".intern();
		}
		public static class TmaBillingAccount
		{
			public static final String BILLINGACCOUNTSTATUS = "billingAccountStatus".intern();
			public static final String BILLINGPROFILES = "billingProfiles".intern();
			public static final String CUSTOMER = "customer".intern();
		}
		public static class TmaSimpleProductOffering
		{
			public static final String DEFAULTTMAPOVARIANT = "defaultTmaPoVariant".intern();
			public static final String DOCUMENTS = "documents".intern();
		}
		public static class TmaSubscriptionBase
		{
			public static final String BILLINGPROFILE = "billingProfile".intern();
			public static final String SUBSCRIPTIONBASESTATUS = "subscriptionBaseStatus".intern();
			public static final String SUBSCRIPTIONBASETYPE = "subscriptionBaseType".intern();
		}
	}
	public static class Enumerations
	{
		public static class BillingAccountStatus
		{
			public static final String ACTIVE = "ACTIVE".intern();
			public static final String INACTIVE = "INACTIVE".intern();
			public static final String PROSPECT = "PROSPECT".intern();
		}
		public static class CustomerIdType
		{
			public static final String CPR = "CPR".intern();
			public static final String CR_ID = "CR_ID".intern();
		}
		public static class CustomerType
		{
			public static final String UNREGISTERED = "UNREGISTERED".intern();
		}
		public static class DeliveryStatus
		{
			public static final String PAID = "PAID".intern();
			public static final String READY_FOR_PICKUP = "READY_FOR_PICKUP".intern();
			public static final String OUT_OF_DELIVERY = "OUT_OF_DELIVERY".intern();
			public static final String DELIVERY_CANCELLED = "DELIVERY_CANCELLED".intern();
			public static final String RETURN_AWAITING_APPROVAL = "RETURN_AWAITING_APPROVAL".intern();
			public static final String RETURN_APPROVED = "RETURN_APPROVED".intern();
			public static final String RETURN_INITIATED = "RETURN_INITIATED".intern();
			public static final String RETURNED = "RETURNED".intern();
			public static final String RETURNED_REJECTED_BATELCO = "RETURNED_REJECTED_BATELCO".intern();
			public static final String RETURNED_REJECTED_COURIER = "RETURNED_REJECTED_COURIER".intern();
			public static final String DELIVERED = "DELIVERED".intern();
		}
		public static class OrderStatus
		{
			public static final String PROCESSING = "PROCESSING".intern();
			public static final String PAID = "PAID".intern();
			public static final String PAID_OFFLINE = "PAID_OFFLINE".intern();
			public static final String WAITING_ONLINE_PAYMENT = "WAITING_ONLINE_PAYMENT".intern();
			public static final String ONLINE_PAYMENT_EXPIRED = "ONLINE_PAYMENT_EXPIRED".intern();
			public static final String ONLINE_PAYMENT_SUCCESS = "ONLINE_PAYMENT_SUCCESS".intern();
			public static final String ONLINE_PAYMENT_FAILED = "ONLINE_PAYMENT_FAILED".intern();
			public static final String DELIVERED = "DELIVERED".intern();
			public static final String RETURNED = "RETURNED".intern();
			public static final String PARTIALLY_RETURNED = "PARTIALLY_RETURNED".intern();
			public static final String PREORDER_COMPLETED = "PREORDER_COMPLETED".intern();
			public static final String AWAITING_PAYMENT = "AWAITING_PAYMENT".intern();
			public static final String PENDING = "PENDING".intern();
		}
		public static class PaymentStatus
		{
			public static final String PAYMENT_NOT_INITIATED = "PAYMENT_NOT_INITIATED".intern();
			public static final String PAYMENT_INITIATED = "PAYMENT_INITIATED".intern();
			public static final String PAYMENT_CAPTURED = "PAYMENT_CAPTURED".intern();
		}
		public static class SubscriptionBaseStatus
		{
			public static final String ACTIVE = "ACTIVE".intern();
			public static final String INACTIVE = "INACTIVE".intern();
			public static final String SUSPENDED = "SUSPENDED".intern();
		}
		public static class SubscriptionBaseType
		{
			public static final String PREPAID = "PREPAID".intern();
			public static final String POSTPAID = "POSTPAID".intern();
			public static final String FIX = "FIX".intern();
			public static final String HYBRID = "HYBRID".intern();
		}
		public static class SwatchColorEnum
		{
			public static final String BLACK = "BLACK".intern();
			public static final String BLUE = "BLUE".intern();
			public static final String BROWN = "BROWN".intern();
			public static final String GREEN = "GREEN".intern();
			public static final String GREY = "GREY".intern();
			public static final String ORANGE = "ORANGE".intern();
			public static final String PINK = "PINK".intern();
			public static final String PURPLE = "PURPLE".intern();
			public static final String RED = "RED".intern();
			public static final String SILVER = "SILVER".intern();
			public static final String WHITE = "WHITE".intern();
			public static final String YELLOW = "YELLOW".intern();
		}
	}
	public static class Relations
	{
		public static final String CUSTOMER2TMABILLINGACCOUNT = "Customer2TmaBillingAccount".intern();
		public static final String STANDARDPAYMENTMODECHILDREN = "StandardPaymentModeChildren".intern();
		public static final String TMABILLINGACCOUNT2BILLINGPROFILE = "TmaBillingAccount2BillingProfile".intern();
		public static final String TMASUBSCRIPTIONBASE2BILLINGPROFILE = "TmaSubscriptionBase2BillingProfile".intern();
	}
	
	protected GeneratedBatelcoCoreConstants()
	{
		// private constructor
	}
	
	
}
