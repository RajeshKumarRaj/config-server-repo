package bt.batelco.core.cart.hook;

import de.hybris.platform.commerceservices.order.hook.CommerceCartCalculationMethodHook;
import de.hybris.platform.commerceservices.service.data.CommerceCartParameter;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.order.CalculationService;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.servicelayer.exceptions.SystemException;
import de.hybris.platform.servicelayer.model.ModelService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

public class BatelcoRecalculateCartChildrenHook implements CommerceCartCalculationMethodHook {
    private static final Logger LOG = Logger.getLogger(BatelcoRecalculateCartChildrenHook.class);

    private CalculationService calculationService;
    private ModelService modelService;

    @Override
    public void afterCalculate(final CommerceCartParameter parameter)
    {
        validateParameterNotNullStandardMessage("CommerceCartParameter", parameter);
        final CartModel cartModel = parameter.getCart();
        if (cartModel == null)
        {
            throw new IllegalArgumentException("The cart model is null.");
        }

        if (cartModel.getChildren() != null)
        {
            cartModel.getChildren().forEach(child ->
            {
                try {
                    getCalculationService().recalculate(child);
                } catch (CalculationException e) {
                    LOG.error("Failed to calculate cart totals [" + cartModel.getCode() + "]", e);
                    throw new SystemException("Could not calculate cart [" + cartModel.getCode() + "] due to : " + e.getMessage(), e);
                }
            });
        }

    }


    @Override
    public void beforeCalculate(final CommerceCartParameter parameter)
    {
        // No need to do anything here
    }


    protected CalculationService getCalculationService()
    {
        return calculationService;
    }

    @Required
    public void setCalculationService(final CalculationService calculationService)
    {
        this.calculationService = calculationService;
    }

    protected ModelService getModelService()
    {
        return modelService;
    }

    @Required
    public void setModelService(final ModelService modelService)
    {
        this.modelService = modelService;
    }
}
