package bt.batelco.core.cart.hook;

import com.iquest.config.service.ConfigProviderService;
import de.hybris.platform.category.CategoryService;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.commerceservices.order.CommerceCartModification;
import de.hybris.platform.commerceservices.service.data.CommerceCartParameter;
import de.hybris.platform.commerceservices.strategies.hooks.CartValidationHook;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.variants.model.VariantCategoryModel;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import bt.batelco.core.cart.BatelcoCommerceCartModificationStatus;
import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;

/**
 * Cart validation hook used to check the number of products in the cart
 */
public class BatelcoCartValidationMethodHook implements CartValidationHook {

  private static final String CATEGORY_PLANS_CODE = "plans";
  private static final String CATEGORY_DEVICE_CODE = "devices";
  private static final String CATEGORY_PREORDER_CODE = "preorder";
  private static final String CART_VALIDATION_MAX_QUANTITY_PLANS = "cart.validation.max.quantity.plans";
  private static final String CART_VALIDATION_MAX_QUANTITY_DEVICES = "cart.validation.max.quantity.devices";
  private static final String CART_VALIDATION_MAX_QUANTITY_PREORDER_DEVICES =
      "cart.validation.max.quantity.preorder.devices";
  private static final String DEVICES_DEFAULT_PREORDER_VALUE = "1";
  private static final String DEVICES_DEFAULT_VALUE = "3";
  private static final String PLANS_DEFAULT_VALUE = "5";

  private CategoryService categoryService;
  private ConfigProviderService configProviderService;

  @Override
  public void beforeValidateCart(CommerceCartParameter parameter, List<CommerceCartModification> modifications) {
    //do nothing
  }

  @Override
  public void afterValidateCart(CommerceCartParameter parameter, List<CommerceCartModification> modifications) {
    if (modifications == null || parameter == null) {
      return;
    }
    CartModel cart = parameter.getCart();
    if (cart == null) {
      return;
    }
    if (CollectionUtils.isEmpty(cart.getEntries())) {
      return;
    }
    if (hasPreorderProducts(cart)) {
      validatePreorderDevices(modifications, cart);
      return;
    }

    validatePlansAndDevices(modifications, cart);

  }

  private void validatePreorderDevices(List<CommerceCartModification> modifications, CartModel cart) {

    long preOrderDeviceCounter = 0;
    boolean otherProductsFound = false;

    for (AbstractOrderEntryModel entry : cart.getEntries()) {
      List<CategoryModel> productCategories = entry.getProduct().getSupercategories().stream()
          .filter(category -> !(category instanceof VariantCategoryModel)).collect(Collectors.toList());

      preOrderDeviceCounter += countElements(productCategories, CATEGORY_PREORDER_CODE) * entry.getQuantity();

      if (!otherProductsFound && !isPreorderProduct(entry)) {
        otherProductsFound = true;
      }
    }

    long preOrderDeviceCounterConfigValue =
        configProviderService.<Long>get(CART_VALIDATION_MAX_QUANTITY_PREORDER_DEVICES)
            .conversion(Long::valueOf).onMissing(useDefault(DEVICES_DEFAULT_PREORDER_VALUE)).convert();

    if (preOrderDeviceCounter > preOrderDeviceCounterConfigValue) {
      final CommerceCartModification modification = new CommerceCartModification();
      modification.setStatusCode(BatelcoCommerceCartModificationStatus.DEVICES_MAX_PREORDER_QUANTITY_EXCEEDED);
      modifications.add(modification);
    }

    if (preOrderDeviceCounter > 0 && otherProductsFound) {
      final CommerceCartModification modification = new CommerceCartModification();
      modification.setStatusCode(BatelcoCommerceCartModificationStatus.PREORDER_AND_OTHER_PRODUCTS_IN_CART);
      modifications.add(modification);
    }
  }

  private boolean hasPreorderProducts(CartModel cartModel) {
    return cartModel.getEntries().stream().anyMatch(this::isPreorderProduct);
  }

  private boolean isPreorderProduct(AbstractOrderEntryModel entry) {
    return entry.getProduct().getSupercategories().stream()
        .anyMatch(category -> !(category instanceof VariantCategoryModel) && CATEGORY_PREORDER_CODE
            .equalsIgnoreCase(category.getCode()));
  }

  private void validatePlansAndDevices(List<CommerceCartModification> modifications, CartModel cart) {
    long plansCounterConfigValue =
        configProviderService.<Long>get(CART_VALIDATION_MAX_QUANTITY_PLANS).conversion(Long::valueOf)
            .onMissing(useDefault(PLANS_DEFAULT_VALUE)).convert();

    long devicesCounterConfigValue = configProviderService.<Long>get(CART_VALIDATION_MAX_QUANTITY_DEVICES)
        .conversion(Long::valueOf).onMissing(useDefault(DEVICES_DEFAULT_VALUE)).convert();

    validateNumberOfPlansAndDevices(modifications, cart, plansCounterConfigValue, devicesCounterConfigValue);
  }

  private void validateNumberOfPlansAndDevices(List<CommerceCartModification> modifications, CartModel cart,
                                               Long plansCounterConfigValue, Long devicesCounterConfigValue) {
    long plansCounter = 0;
    long deviceCounter = 0;

    for (AbstractOrderEntryModel entry : cart.getEntries()) {
      List<CategoryModel> productCategories = entry.getProduct().getSupercategories().stream()
          .filter(category -> !(category instanceof VariantCategoryModel)).collect(Collectors.toList());

      List<CategoryModel> allSuperCategoriesForProduct = getSuperCategoryModels(productCategories);

      plansCounter += countElements(allSuperCategoriesForProduct, CATEGORY_PLANS_CODE) * entry.getQuantity();
      deviceCounter += countElements(allSuperCategoriesForProduct, CATEGORY_DEVICE_CODE) * entry.getQuantity();
    }

    if (plansCounter > plansCounterConfigValue) {
      final CommerceCartModification modification = new CommerceCartModification();
      modification.setStatusCode(BatelcoCommerceCartModificationStatus.PLANS_MAX_ORDER_QUANTITY_EXCEEDED);
      modifications.add(modification);
    }

    if (deviceCounter > devicesCounterConfigValue) {
      final CommerceCartModification modification = new CommerceCartModification();
      modification.setStatusCode(BatelcoCommerceCartModificationStatus.DEVICES_MAX_ORDER_QUANTITY_EXCEEDED);
      modifications.add(modification);
    }
  }

  private List<CategoryModel> getSuperCategoryModels(List<CategoryModel> superCategories) {
    List<CategoryModel> allSuperCategoriesForCategory = new ArrayList<>();
    superCategories.forEach(
        superCat -> allSuperCategoriesForCategory.addAll(categoryService.getAllSupercategoriesForCategory(superCat)));
    return allSuperCategoriesForCategory;
  }

  private long countElements(List<CategoryModel> superCategories, String categoryCode) {
    return superCategories.stream()
        .filter(superCategory -> categoryCode.equalsIgnoreCase(superCategory.getCode())).count();
  }

  @Required
  public void setCategoryService(CategoryService categoryService) {
    this.categoryService = categoryService;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }
}
