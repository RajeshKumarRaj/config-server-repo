package bt.batelco.core.cart.impl;

import com.iquest.config.service.ConfigProviderService;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.cart.BatelcoCartConfigService;

import static com.iquest.config.provider.IncorrectConfigurationActions.throwInvalidConfigException;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwMissingConfigException;

/**
 *
 */
public class DefaultBatelcoCartConfigService implements BatelcoCartConfigService {

  private static final String CPR_ALL_MIME_TYPES_KEY = "cpr.mimeTypes";
  private static final String CPR_MAX_SIZE_KEY = "cpr.maxSize";
  private static final String ACQUISITION_FORM_ALL_MIME_TYPES_KEY = "acquisitionForm.mimeTypes";
  private static final String ACQUISITION_FORM_MAX_SIZE_KEY = "acquisitionForm.maxSize";
  private static final String PAYMENT_EVIDENCE_ALL_MIME_TYPES_KEY = "paymentEvidence.mimeTypes";
  private static final String PAYMENT_EVIDENCE_MAX_SIZE_KEY = "paymentEvidence.maxSize";

  private ConfigProviderService configProviderService;
  private String catalogName;
  private String catalogVersion;
  private String cprFolderName;
  private String paymentEvidenceFolderName;
  private String acquisitionFolderName;
  private String acquisitionFormatName;

  @Override
  public String getAllCprMimeTypes() {
    return getConfigValue(CPR_ALL_MIME_TYPES_KEY);
  }

  @Override
  public double getCprMaxSize() {
    return getConfigValueDouble(CPR_MAX_SIZE_KEY);
  }


  @Override
  public String getAllAcquisitionFormMimeTypes() {
    return getConfigValue(ACQUISITION_FORM_ALL_MIME_TYPES_KEY);
  }

  @Override
  public double getAcquisitionFormMaxSize() {
    return getConfigValueDouble(ACQUISITION_FORM_MAX_SIZE_KEY);
  }

  @Override
  public String getAllPaymentEvidenceMimeTypes() {
    return getConfigValue(PAYMENT_EVIDENCE_ALL_MIME_TYPES_KEY);
  }

  @Override
  public double getPaymentEvidenceMaxSize() {
    return getConfigValueDouble(PAYMENT_EVIDENCE_MAX_SIZE_KEY);
  }

  private String getConfigValue(String key) {
    return getConfigProviderService().<String>get(key)
        .conversion(c -> c)
        .validateThat(StringUtils::isNotEmpty)
        .onMissing(throwMissingConfigException())
        .onInvalid(throwInvalidConfigException())
        .convert();
  }


  private double getConfigValueDouble(String key) {
    return getConfigProviderService().<Double>get(key)
        .conversion(Double::valueOf)
        .validateThat(c -> c > 0)
        .onMissing(throwMissingConfigException())
        .onInvalid(throwInvalidConfigException())
        .convert();
  }

  @Override
  public String getCatalogName() {
    return catalogName;
  }

  @Required
  public void setCatalogName(String catalogName) {
    this.catalogName = catalogName;
  }

  @Override
  public String getCatalogVersion() {
    return catalogVersion;
  }

  @Required
  public void setCatalogVersion(String catalogVersion) {
    this.catalogVersion = catalogVersion;
  }

  @Override
  public String getCprFolderName() {
    return cprFolderName;
  }

  @Required
  public void setCprFolderName(String cprFolderName) {
    this.cprFolderName = cprFolderName;
  }

  @Override
  public String getAcquisitionFormFolderName() {
    return acquisitionFolderName;
  }

  @Override
  public String getAcquisitionFormFormatName() {
    return acquisitionFormatName;
  }

  @Override
  public String getPaymentEvidenceFolderName() {
    return paymentEvidenceFolderName;
  }

  @Required
  public void setPaymentEvidenceFolderName(String paymentEvidenceFolderName) {
    this.paymentEvidenceFolderName = paymentEvidenceFolderName;
  }

  protected ConfigProviderService getConfigProviderService() {
    return configProviderService;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }

  @Required
  public void setAcquisitionFolderName(String acquisitionFolderName) {
    this.acquisitionFolderName = acquisitionFolderName;
  }

  @Required
  public void setAcquisitionFormatName(String acquisitionFormatName) {
    this.acquisitionFormatName = acquisitionFormatName;
  }
}
