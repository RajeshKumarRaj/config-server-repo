package bt.batelco.core.cart.impl;

import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.order.CalculationService;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.order.impl.DefaultCartService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DefaultBatelcoCartService extends DefaultCartService {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoCartService.class);

  private CalculationService calculationService;

  @Override
  public void updateQuantities(CartModel cart, Map<Integer, Long> quantities) {
    if (cart == null) {
      throw new IllegalArgumentException("cart cannot be null");
    }
    if (!MapUtils.isEmpty(quantities)) {
      final Collection<CartEntryModel> toRemove = new LinkedList<CartEntryModel>();
      final Collection<CartEntryModel> toSave = new LinkedList<CartEntryModel>();
      for (final Map.Entry<CartEntryModel, Long> e : getEntryQuantityMap(cart, quantities).entrySet()) {
        final CartEntryModel cartEntry = e.getKey();
        final Long quantity = e.getValue();
        if (quantity == null || quantity.longValue() < 1) {
          toRemove.add(cartEntry);
        } else {
          cartEntry.setQuantity(quantity);
          recalculatePrice(cartEntry);

          if (CollectionUtils.isNotEmpty(cartEntry.getChildEntries())) {
            cartEntry.getChildEntries()
                .forEach(childEntry -> {
                  childEntry.setQuantity(quantity);
                  recalculatePrice(childEntry);
                });
          }
          toSave.add(cartEntry);

        }
      }
      getModelService().removeAll(toRemove);
      getModelService().saveAll(toSave);
      getModelService().refresh(cart);
    }
  }

  private void recalculatePrice(AbstractOrderEntryModel entry) {
    try {
      calculationService.recalculate(entry);
    } catch (CalculationException ex) {
      LOG.error("Price recalculation failed for " + AbstractOrderEntryModel._TYPECODE + " = " + entry.getPk());
    }
  }

  private Map<CartEntryModel, Long> getEntryQuantityMap(final CartModel cart, final Map<Integer, Long> quantities) {
    final List<CartEntryModel> entries = (List) cart.getEntries();

    final Map<CartEntryModel, Long> ret = new LinkedHashMap<CartEntryModel, Long>();

    for (final Map.Entry<Integer, Long> q : quantities.entrySet()) {
      final Integer entryNumber = q.getKey();
      final Long quantity = q.getValue();
      ret.put(getEntry(entries, entryNumber), quantity);
    }

    return ret;
  }

  private CartEntryModel getEntry(final List<CartEntryModel> entries, final Integer entryNumber) {
    for (final CartEntryModel e : entries) {
      if (entryNumber.equals(e.getEntryNumber())) {
        return e;
      }
    }
    throw new IllegalArgumentException(
        "no cart entry found with entry number " + entryNumber + " (got " + entries + ")");
  }

  @Required
  public void setCalculationService(CalculationService calculationService) {
    this.calculationService = calculationService;
  }
}
