package bt.batelco.core.cart;

import de.hybris.platform.commerceservices.order.CommerceCartModificationStatus;

public interface BatelcoCommerceCartModificationStatus extends CommerceCartModificationStatus {//NOSONAR

  /**
   * Indicates a failure due to max order quantity exceeded in cart for plans.
   */
  String PLANS_MAX_ORDER_QUANTITY_EXCEEDED = "plansMaxOrderQuantityExceeded";

  /**
   * Indicates a failure due to max order quantity exceeded in cart for plans.
   */
  String DEVICES_MAX_ORDER_QUANTITY_EXCEEDED = "deviceMaxOrderQuantityExceeded";
  /**
   * Indicates a failure due to max order quantity exceeded in cart for preorder products.
   */
  String DEVICES_MAX_PREORDER_QUANTITY_EXCEEDED = "deviceMaxPreOrderQuantityExceeded";
  /**
   * Indicates a failure due to mixed products in cart. Pre-order products must be alone in cart.
   */
  String PREORDER_AND_OTHER_PRODUCTS_IN_CART = "preorderAndOtherProductsInCart";
}
