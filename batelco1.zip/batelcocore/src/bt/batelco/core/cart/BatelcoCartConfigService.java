package bt.batelco.core.cart;

/**
 *
 */
public interface BatelcoCartConfigService {

  String getAllCprMimeTypes();

  double getCprMaxSize();

  String getAllAcquisitionFormMimeTypes();

  double getAcquisitionFormMaxSize();

  String getAllPaymentEvidenceMimeTypes();

  double getPaymentEvidenceMaxSize();

  String getCatalogName();

  String getCatalogVersion();

  String getCprFolderName();

  String getAcquisitionFormFolderName();

  String getAcquisitionFormFormatName();

  String getPaymentEvidenceFolderName();
}
