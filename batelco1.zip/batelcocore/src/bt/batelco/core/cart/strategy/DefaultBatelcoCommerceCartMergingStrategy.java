package bt.batelco.core.cart.strategy;

import de.hybris.platform.commerceservices.order.CommerceCartMergingException;
import de.hybris.platform.commerceservices.order.CommerceCartModification;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.order.CommerceCartModificationStatus;
import de.hybris.platform.commerceservices.order.impl.DefaultCommerceCartMergingStrategy;
import de.hybris.platform.commerceservices.service.data.CommerceCartParameter;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.subscriptionservices.subscription.SubscriptionCommerceCartService;

import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class DefaultBatelcoCommerceCartMergingStrategy extends DefaultCommerceCartMergingStrategy {

    private SubscriptionCommerceCartService subscriptionCommerceCartService;

    @Override
    protected CommerceCartModification mergeEntryWithCart(AbstractOrderEntryModel entry, CartModel toCart) throws CommerceCartMergingException {

        final AbstractOrderEntryModel entryToMerge = getEntryMergeStrategy().getEntryToMerge(toCart.getEntries(), entry);

        if (entryToMerge == null) {
            final AbstractOrderEntryModel clonedEntry = getModelService().clone(entry, entry.getClass());
            getModelService().detach(clonedEntry);
            clonedEntry.setOrder(toCart);
            updateEntryNumber(clonedEntry, toCart);

            if (toCart.getEntries() == null) {
                toCart.setEntries(Collections.singletonList(clonedEntry));
            } else {
                final List<AbstractOrderEntryModel> entries = new ArrayList<>(toCart.getEntries());
                entries.add(clonedEntry);
                toCart.setEntries(entries);
            }
            getModelService().save(clonedEntry);
            getModelService().save(toCart);

            addChildrenToCloneEntry(entry, clonedEntry, toCart);


            final CommerceCartModification commerceCartModification = new CommerceCartModification();
            commerceCartModification.setEntry(clonedEntry);
            commerceCartModification.setQuantity(clonedEntry.getQuantity());
            commerceCartModification.setQuantityAdded(clonedEntry.getQuantity());
            commerceCartModification.setStatusCode(CommerceCartModificationStatus.SUCCESS);
            return commerceCartModification;
        } else {
            final CommerceCartParameter updateQuantityParameter = new CommerceCartParameter();
            updateQuantityParameter.setCart(toCart);
            updateQuantityParameter.setQuantity(entryToMerge.getQuantity() + entry.getQuantity());
            updateQuantityParameter.setEntryNumber(entryToMerge.getEntryNumber().longValue());
            updateQuantityParameter.setEnableHooks(true);
            try {
                return getCommerceCartService().updateQuantityForCartEntry(updateQuantityParameter);
            } catch (final CommerceCartModificationException e) {
                throw new CommerceCartMergingException("Exception during cart merge", e);
            }
        }
    }

    private void addChildrenToCloneEntry(AbstractOrderEntryModel entry, AbstractOrderEntryModel clonedEntry, CartModel toCart) {
        Collection<AbstractOrderEntryModel> childEntries = entry.getChildEntries();

        for (AbstractOrderEntryModel childEntry : childEntries) {

            AbstractOrderEntryModel clonedChildEntry = getModelService().clone(childEntry, childEntry.getClass());
            getModelService().detach(clonedChildEntry);

            CartModel orderForCloneEntry = getCartForCloneEntry(toCart, childEntry);

            clonedChildEntry.setOrder(orderForCloneEntry);
            updateEntryNumber(clonedChildEntry, orderForCloneEntry);
            clonedChildEntry.setMasterEntry(clonedEntry);

            getModelService().save(clonedChildEntry);
            getModelService().save(orderForCloneEntry);

        }
        getModelService().refresh(clonedEntry);
    }

    private CartModel getCartForCloneEntry(CartModel toCart, AbstractOrderEntryModel childEntry) {
        String orderType = childEntry.getOrder().getBillingTime().getCode();
        Optional<AbstractOrderModel> exitingCart = toCart.getChildren().stream()
                .filter(order -> orderType.equals(order.getBillingTime().getCode())).findFirst();
        return exitingCart.map(abstractOrderModel -> (CartModel) abstractOrderModel)
                .orElseGet(() -> getSubscriptionCommerceCartService().createChildCartForBillingTime(toCart, childEntry.getOrder().getBillingTime()));

    }


    public SubscriptionCommerceCartService getSubscriptionCommerceCartService() {
        return subscriptionCommerceCartService;
    }

    @Required
    public void setSubscriptionCommerceCartService(SubscriptionCommerceCartService subscriptionCommerceCartService) {
        this.subscriptionCommerceCartService = subscriptionCommerceCartService;
    }
}
