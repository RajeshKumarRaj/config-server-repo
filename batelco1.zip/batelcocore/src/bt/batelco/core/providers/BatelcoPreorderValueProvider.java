package bt.batelco.core.providers;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.provider.TmaAbstractSppProvider;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.provider.FieldValue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

public class BatelcoPreorderValueProvider extends TmaAbstractSppProvider {


  @Override
  protected Collection<FieldValue> getValues(IndexedProperty indexedProperty, Object model) {
    validateParameterNotNullStandardMessage("model", model);
    final List<FieldValue> fieldValues = new ArrayList<>();

    if (model instanceof TmaProductOfferingModel) {
      TmaProductOfferingModel productOfferingModel = (TmaProductOfferingModel) model;

      addFieldValues(fieldValues, indexedProperty, null, productOfferingModel.getPreorderProduct());
    }

    return fieldValues;
  }
}
