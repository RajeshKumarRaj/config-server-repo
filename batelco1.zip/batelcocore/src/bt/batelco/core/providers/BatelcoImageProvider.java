package bt.batelco.core.providers;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.provider.TmaSppImageProvider;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.core.model.media.MediaFormatModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.solrfacetsearch.config.IndexConfig;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.provider.FieldValue;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.apache.log4j.Logger;

import java.util.Collection;
import java.util.Collections;

public class BatelcoImageProvider extends TmaSppImageProvider {

  private static final Logger LOG = Logger.getLogger(BatelcoImageProvider.class);

  @Override
  public Collection<FieldValue> getFieldValues(IndexConfig cfg, IndexedProperty prop, Object model)
      throws FieldValueProviderException {
    if (!(model instanceof SubscriptionPricePlanModel)) {
      return Collections.emptyList();
    }

    if (isBundlePrice((SubscriptionPricePlanModel) model)) {
      ProductModel mainProduct = ((SubscriptionPricePlanModel) model).getMainAffectedProductOffering();
      if (!(mainProduct instanceof TmaSimpleProductOfferingModel)) {
        return Collections.emptyList();
      }

      TmaPoVariantModel defaultPOVariant = ((TmaSimpleProductOfferingModel) mainProduct).getDefaultTmaPoVariant();
      if (defaultPOVariant != null) {
        return getFieldValuesForDefaultVariant(defaultPOVariant, prop);
      }
    } else if (productExists((SubscriptionPricePlanModel) model)) {
      ProductModel product = ((SubscriptionPricePlanModel) model).getProduct();
      if (product instanceof TmaPoVariantModel) {
        TmaPoVariantModel defaultPOVariant = ((TmaPoVariantModel) product).getTmaBasePo().getDefaultTmaPoVariant();
        if (defaultPOVariant != null) {
          return getFieldValuesForDefaultVariant(defaultPOVariant, prop);
        }
      }
    }

    return super.getFieldValues(cfg, prop, model);
  }

  private boolean productExists(SubscriptionPricePlanModel model) {
    return model.getProduct() != null;
  }

  private boolean isBundlePrice(SubscriptionPricePlanModel model) {
    return model.getMainAffectedProductOffering() != null;
  }

  private Collection<FieldValue> getFieldValuesForDefaultVariant(TmaPoVariantModel defaultPOVariant,
                                                                 IndexedProperty indexedProperty) {

    final MediaFormatModel mediaFormatModel = getMediaService().getFormat(getMediaFormat());
    if (mediaFormatModel != null) {
      final MediaModel media = findMedia(defaultPOVariant, mediaFormatModel);
      if (media != null) {
        return createFieldValues(indexedProperty, media);
      }
      if (LOG.isDebugEnabled()) {
        LOG.debug("No [" + mediaFormatModel.getQualifier() + "] image found for product ["
                  + (defaultPOVariant).getCode() + "]");
      }
    }

    return Collections.emptyList();
  }

}
