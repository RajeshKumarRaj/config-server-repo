package bt.batelco.core.url.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commerceservices.url.impl.DefaultProductModelUrlResolver;
import de.hybris.platform.core.model.product.ProductModel;

public class BatelcoProductModelUrlResolver extends DefaultProductModelUrlResolver {

  @Override
  protected ProductModel getBaseProduct(final ProductModel product) {
    if (product instanceof TmaPoVariantModel) {
      return ((TmaPoVariantModel) product).getTmaBasePo();
    }

    return product;
  }

  @Override
  protected String resolveInternal(final ProductModel source)
  {
    final ProductModel baseProduct = getBaseProduct(source);

    final BaseSiteModel currentBaseSite = getBaseSiteService().getCurrentBaseSite();

    String url = getPattern();

    if (currentBaseSite != null && url.contains("{baseSite-uid}"))
    {
      url = url.replace("{baseSite-uid}", urlEncode(currentBaseSite.getUid()));
    }
    if (url.contains("{category-path}"))
    {
      url = url.replace("{category-path}", buildPathString(getCategoryPath(baseProduct)));
    }

    if (url.contains("{product-name}"))
    {
      url = url.replace("{product-name}", urlSafe(baseProduct.getName()));
    }
    if (url.contains("{product-code}"))
    {
      url = url.replace("{product-code}", urlEncode(source.getSlang()));
    }

    return url;
  }

}

