package bt.batelco.core.search.solrfacetsearch.resolver.impl;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.TmaSpoSource;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.category.CategoryService;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.indexer.IndexerBatchContext;
import de.hybris.platform.solrfacetsearch.indexer.spi.InputDocument;
import de.hybris.platform.solrfacetsearch.provider.ValueResolver;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Custom {@link CategoryModel} code resolver which would prioritise the products which match the given category as
 * provided as a parameter.
 */
public class CustomCategoryCodeValueResolver implements ValueResolver<PriceRowModel> {


  private TmaSpoSource spoSource;
  private CategoryService categoryService;

  @Override
  public void resolve(InputDocument inputDocument, IndexerBatchContext indexerBatchContext,
                      Collection<IndexedProperty> collection, PriceRowModel priceRowModel)
      throws FieldValueProviderException {
    for (IndexedProperty indexedProperty : collection) {
      String parameter = indexedProperty.getValueProviderParameter();
      if (StringUtils.isNotEmpty(parameter)) {
        ProductModel product = spoSource.getProduct(priceRowModel);

        Set<CategoryModel> allCategories = new LinkedHashSet<>();
        addProductCategories(product, allCategories);
        if(product instanceof TmaPoVariantModel){
          addCategoriesFromBaseProduct(allCategories,(TmaPoVariantModel)product);
        }

        Optional<CategoryModel>
            matchingCategory =
            allCategories.stream().filter(categoryModel -> categoryModel.getCode().equals(parameter))
                .findAny();
        inputDocument.addField(indexedProperty, matchingCategory.isPresent() ? 1 : 0);
      }
    }
  }

  private void addProductCategories(ProductModel product, Set<CategoryModel> allCategories) {
    Collection<CategoryModel> categories = product.getSupercategories();
    allCategories.addAll(categories);
    categories.stream()
            .map(category -> categoryService.getAllSupercategoriesForCategory(category))
            .forEach(allCategories::addAll);
  }

  private void addCategoriesFromBaseProduct(Set<CategoryModel> allCategories, TmaPoVariantModel variant) {
    ProductModel baseProduct=variant.getTmaBasePo();
    if(baseProduct == null){
      return;
    }
    addProductCategories(baseProduct, allCategories);
  }


  @Required
  public void setSpoSource(TmaSpoSource spoSource) {
    this.spoSource = spoSource;
  }

  @Required
  public void setCategoryService(CategoryService categoryService) {
    this.categoryService = categoryService;
  }
}
