package bt.batelco.core.search.solrfacetsearch.resolver.impl;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.resolver.TmaChargeValueSource;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;

import bt.batelco.core.price.service.BatelcoCommercePriceService;

public class TmaMinimumChargeSource implements TmaChargeValueSource {

  private static final Logger LOG = LoggerFactory.getLogger(TmaMinimumChargeSource.class);
  private BatelcoCommercePriceService commercePriceService;

  @Override
  public Double getPrice(PriceRowModel price, String param) {
    if (price instanceof SubscriptionPricePlanModel) {
      TmaSimpleProductOfferingModel baseProduct = getCommercePriceService().getBaseProduct(price);
      if (baseProduct == null) {
        return null;
      }
      return getMinimumPriceForBaseProduct(baseProduct);
    } else {
      return null;
    }
  }

  private Double getMinimumPriceForBaseProduct(TmaSimpleProductOfferingModel baseProduct) {
    Double minimumPrice = Double.MAX_VALUE;
    Collection<TmaPoVariantModel> variants = baseProduct.getTmaPoVariants();
    if (variants.isEmpty()) {
      return getCommercePriceService().getMinimumPrice(baseProduct);
    }
    for (TmaPoVariantModel variant : variants) {
      Double variantMinPrice = getCommercePriceService().getMinimumPrice(variant);

      if (variantMinPrice == null) {
        LOG.debug("Couldn't find a minimum price for variant with code {}", variant.getCode());
        continue;
      }

      if (variantMinPrice < minimumPrice) {
        minimumPrice = variantMinPrice;
      }
    }
    return minimumPrice;
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }
}
