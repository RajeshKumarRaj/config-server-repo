package bt.batelco.core.search.solrfacetsearch.provider.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.indexer.IndexerBatchContext;
import de.hybris.platform.solrfacetsearch.indexer.spi.InputDocument;
import de.hybris.platform.solrfacetsearch.provider.impl.AbstractValueResolver;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.springframework.beans.factory.annotation.Required;

import java.util.Locale;

import bt.batelco.core.price.service.BatelcoCommercePriceService;

public class SubscriptionPricePlanBaseNameResolver
    extends AbstractValueResolver<SubscriptionPricePlanModel, Object, Object> {

  private CommonI18NService commonI18NService;
  private BatelcoCommercePriceService commercePriceService;

  @Override
  protected void addFieldValues(InputDocument doc,
                                IndexerBatchContext batchContext,
                                IndexedProperty prop,
                                SubscriptionPricePlanModel subscriptionPricePlan,
                                ValueResolverContext<Object, Object> resolverContext)
      throws FieldValueProviderException {
    if (!prop.isLocalized()) {
      return;
    }
    for (LanguageModel language : batchContext.getFacetSearchConfig().getIndexConfig().getLanguages()) {
      Locale loc = getCommonI18NService().getLocaleForLanguage(language);
      TmaSimpleProductOfferingModel baseProduct = getCommercePriceService()
          .getBaseProduct(subscriptionPricePlan);
      if (baseProduct == null) {
        return;
      }
      String fieldValue = baseProduct.getName(loc);
      if (fieldValue != null) {
        String fieldName = String.format("%s_%s_%s", prop.getName(), prop.getType(), loc.getLanguage());
        doc.addField(fieldName, fieldValue);
      }
    }
  }

  protected CommonI18NService getCommonI18NService() {
    return commonI18NService;
  }

  @Required
  public void setCommonI18NService(CommonI18NService commonI18NService) {
    this.commonI18NService = commonI18NService;
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }
}
