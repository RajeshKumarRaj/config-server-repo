package bt.batelco.core.search.solrfacetsearch.provider.impl;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.provider.TmaSppUrlProvider;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.solrfacetsearch.config.IndexConfig;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.provider.FieldValue;

import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;

import bt.batelco.core.price.service.BatelcoCommercePriceService;

public class SubscriptionPricePlanUrlProvider extends TmaSppUrlProvider {

  private BatelcoCommercePriceService commercePriceService;

  @Override
  public Collection<FieldValue> getFieldValues(IndexConfig cfg, IndexedProperty prop, Object model)
      throws FieldValueProviderException {
    if (model instanceof PriceRowModel
        && getCommercePriceService().getBaseProduct((PriceRowModel) model).getDefaultTmaPoVariant() != null) {
      return super.getFieldValues(cfg, prop, getCommercePriceService().getBaseProduct((PriceRowModel) model)
          .getDefaultTmaPoVariant());
    } else {
      return super.getFieldValues(cfg, prop, model);
    }
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }
}
