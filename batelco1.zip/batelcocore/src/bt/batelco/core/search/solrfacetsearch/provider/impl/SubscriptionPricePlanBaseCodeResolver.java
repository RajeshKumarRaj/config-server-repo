package bt.batelco.core.search.solrfacetsearch.provider.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.indexer.IndexerBatchContext;
import de.hybris.platform.solrfacetsearch.indexer.spi.InputDocument;
import de.hybris.platform.solrfacetsearch.provider.impl.AbstractValueResolver;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.price.service.BatelcoCommercePriceService;

public class SubscriptionPricePlanBaseCodeResolver
    extends AbstractValueResolver<SubscriptionPricePlanModel, Object, Object> {

  private BatelcoCommercePriceService commercePriceService;

  @Override
  protected void addFieldValues(InputDocument doc, IndexerBatchContext batchContext,
                                IndexedProperty indexedProperty, SubscriptionPricePlanModel subscriptionPricePlan,
                                ValueResolverContext<Object, Object> resolverContext)
      throws FieldValueProviderException {
    TmaSimpleProductOfferingModel baseProduct = getCommercePriceService().getBaseProduct(subscriptionPricePlan);
    if (baseProduct == null) {
      return;
    }
    String code = baseProduct.getCode();
    if (code != null) {
      doc.addField(indexedProperty, code, resolverContext.getFieldQualifier());
    }
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }
}
