package bt.batelco.core.search.solrfacetsearch.provider.impl;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.provider.TmaSppReviewAvgProvider;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.provider.FieldValue;

import org.apache.commons.lang3.Range;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.IntStream;

/**
 * Custom {@link TmaSppReviewAvgProvider} which would merge rating values starting with the upper values down to the
 * lower ones.
 */
public class CustomProductReviewAverageRatingValueProvider extends TmaSppReviewAvgProvider {

  private static final Range<Double> range1 = Range.between(0.5, 1.49);
  private static final Range<Double> range2 = Range.between(1.5, 2.49);
  private static final Range<Double> range3 = Range.between(2.5, 3.49);
  private static final Range<Double> range4 = Range.between(3.5, 4.49);
  private static final Range<Double> range5 = Range.between(4.5, 5.0);
  private static Map<Integer, Range<Double>> ranges = new LinkedHashMap<>();

  static {
    ranges.put(1, range1);
    ranges.put(2, range2);
    ranges.put(3, range3);
    ranges.put(4, range4);
    ranges.put(5, range5);
  }

  @Override
  protected void addFieldValues(final List<FieldValue> fieldValues, final IndexedProperty indexedProperty,
                                final LanguageModel language, final Object value) {

    final Collection<String> fieldNames = getFieldNameProvider().getFieldNames(indexedProperty,
                                                                               language == null ? null : language
                                                                                   .getIsocode());

    Double rating = (Double) value;
    Optional<Integer>
        range =
        ranges.entrySet().stream().filter(entry -> entry.getValue().contains(rating)).findAny().map(Map.Entry::getKey);

    if (range.isPresent()) {
      fieldNames.stream().forEach(fieldName -> IntStream.rangeClosed(1, range.get())
          .forEach(entry -> fieldValues.add(new FieldValue(fieldName, entry))));
      return;
    }

    fieldNames.stream().forEach(fieldName -> fieldValues.add(new FieldValue(fieldName, 0)));
  }
}
