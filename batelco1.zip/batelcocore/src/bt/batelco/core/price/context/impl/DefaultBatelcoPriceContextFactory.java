package bt.batelco.core.price.context.impl;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.b2ctelcoservices.pricing.context.impl.DefaultTmaPriceContextFactory;

import java.util.Set;

import bt.batelco.core.price.context.BatelcoPriceContextFactory;

/**
 * Default implementation of {@link BatelcoPriceContextFactory}
 */
public class DefaultBatelcoPriceContextFactory extends DefaultTmaPriceContextFactory implements BatelcoPriceContextFactory {

  @Override
  public TmaPriceContext createPriceContext(Set<TmaBundledProductOfferingModel> parents, TmaProductOfferingModel affectedProductOffering, Set<TmaProcessType> processTypes) {
    TmaPriceContext tmaPriceContextFactory = createEmptyPriceContext();
    tmaPriceContextFactory.setProcessTypes(processTypes);
    tmaPriceContextFactory.setAffectedProduct(affectedProductOffering);
    tmaPriceContextFactory.setParents(parents);

    return tmaPriceContextFactory;
  }
}
