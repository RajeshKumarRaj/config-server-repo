package bt.batelco.core.price.context;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContextFactory;

import java.util.Set;

/**
 * Custom implementation of {@link TmaPriceContextFactory}
 */
public interface BatelcoPriceContextFactory extends TmaPriceContextFactory {

  /**
   * Creates a {@link TmaPriceContext} with the provided parameters.
   *
   * @param parents                 the parents with overridden prices for the affected product
   * @param affectedProductOffering product for which the price applies
   * @param processTypes            process type applicable for the price to be identified by the price context
   * @return newly created {@link TmaPriceContext} with the configured parameters
   */
  TmaPriceContext createPriceContext(Set<TmaBundledProductOfferingModel> parents, TmaProductOfferingModel affectedProductOffering, Set<TmaProcessType> processTypes);
}
