package bt.batelco.core.price.service.impl;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.b2ctelcoservices.pricing.services.impl.DefaultTmaCommercePriceService;
import de.hybris.platform.catalog.enums.ArticleApprovalStatus;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.europe1.enums.PriceRowChannel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.servicelayer.internal.i18n.I18NConstants;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.servicelayer.util.ServicesUtil;
import de.hybris.platform.store.services.BaseStoreService;
import de.hybris.platform.subscriptionservices.model.OneTimeChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.RecurringChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import bt.batelco.core.price.context.BatelcoPriceContextFactory;
import bt.batelco.core.price.service.BatelcoCommercePriceService;

/**
 * Custom implementation of {@link DefaultTmaCommercePriceService}
 */
public class DefaultBatelcoCommercePriceService extends DefaultTmaCommercePriceService
    implements BatelcoCommercePriceService {

  private static final String DETECTED_CHANNEL = "UiExperienceService-Detected-Level";
  private static final String BATELCO_STORE = "batelco";
  private BatelcoCommercePriceService commercePriceService;
  private BatelcoPriceContextFactory priceContextFactory;
  private BaseStoreService baseStoreService;
  private SessionService sessionService;

  @Override
  public PriceRowModel getMinimumPrice(final TmaPriceContext priceContext) {
    ServicesUtil.validateParameterNotNullStandardMessage("priceContext cannot be null", priceContext);
    ServicesUtil.validateParameterNotNullStandardMessage("product cannot be null", priceContext.getProduct());

    final Set<PriceRowModel> applicablePrices = new HashSet<>();

    if (priceContext.getProduct() instanceof TmaBundledProductOfferingModel) {
      applicablePrices.addAll(getPriceOverrides(priceContext));
      if (CollectionUtils.isEmpty(applicablePrices)) {
        final TmaPriceContext standalonePriceContext = getPriceContextFactory()
            .createPriceContext(getProduct(priceContext), priceContext.getProcessTypes(),
                                priceContext.getSubscriptionTerms());
        applicablePrices.addAll(getStandalonePrices(standalonePriceContext));
      }
    } else {
      applicablePrices.addAll(getStandalonePrices(priceContext));
      if (CollectionUtils.isEmpty(applicablePrices) && CollectionUtils
          .isNotEmpty(priceContext.getProduct().getParents())) {
        TmaPriceContext
            tmaPriceContext =
            getPriceContextFactory()
                .createPriceContext(priceContext.getProduct().getParents(), priceContext.getProduct(),
                                    priceContext.getProcessTypes());
        applicablePrices.addAll(findPricesAtParentLevel(tmaPriceContext));
      }
    }

    return getMinimumPriceRowFromCollection(applicablePrices);
  }

  @Override
  public Double getMinimumPriceValue(final TmaPriceContext priceContext) {
    ServicesUtil.validateParameterNotNullStandardMessage("priceContext cannot be null", priceContext);

    final PriceRowModel minimumPrice = getMinimumPrice(priceContext);
    if (minimumPrice == null) {
      return null;
    }

    if (!(minimumPrice instanceof SubscriptionPricePlanModel)) {
      return minimumPrice.getPrice();
    }

    final SubscriptionPricePlanModel subscriptionPricePlan = (SubscriptionPricePlanModel) minimumPrice;
    final Collection<RecurringChargeEntryModel> recurringCharges = subscriptionPricePlan.getRecurringChargeEntries();
    if (CollectionUtils.isNotEmpty(recurringCharges)) {
      return recurringCharges.iterator().next().getPrice();
    }

    final Collection<OneTimeChargeEntryModel> oneTimeCharges = subscriptionPricePlan.getOneTimeChargeEntries();
    if (CollectionUtils.isNotEmpty(oneTimeCharges)) {
      return oneTimeCharges.iterator().next().getPrice();
    }

    return subscriptionPricePlan.getPrice();
  }

  @Override
  public TmaSimpleProductOfferingModel getBaseProduct(PriceRowModel priceRow) {
    TmaSimpleProductOfferingModel baseProduct = getBaseProduct(priceRow.getProduct());
    if (baseProduct == null && priceRow instanceof SubscriptionPricePlanModel) {
      baseProduct = getBaseProduct(((SubscriptionPricePlanModel) priceRow).getAffectedProductOffering());
    }
    return baseProduct;
  }

  @Override
  public Double getMinimumPrice(TmaSimpleProductOfferingModel product) {
    final Set<TmaProcessType> processTypes = new HashSet<>(Collections.singleton(TmaProcessType.ACQUISITION));
    final TmaPriceContext priceContext = getPriceContextFactory().createPriceContext(product, processTypes);
    priceContext.setCurrency(getBaseStoreService().getBaseStoreForUid(BATELCO_STORE).getDefaultCurrency());
    String detectedChannel = getSessionService().getAttribute(DETECTED_CHANNEL);
    getSessionService().setAttribute(DETECTED_CHANNEL, PriceRowChannel.DESKTOP);
    LanguageModel language = getSessionService().getAttribute(I18NConstants.LANGUAGE_SESSION_ATTR_KEY);
    getSessionService().setAttribute(I18NConstants.LANGUAGE_SESSION_ATTR_KEY,
                                     getBaseStoreService().getBaseStoreForUid(BATELCO_STORE).getDefaultLanguage());
    Double minimumPrice = getMinimumPriceValue(priceContext);
    getSessionService().setAttribute(DETECTED_CHANNEL, detectedChannel);
    getSessionService().setAttribute(I18NConstants.LANGUAGE_SESSION_ATTR_KEY, language);
    return minimumPrice;
  }

  @Override
  public void resetDefaultVariant(final SubscriptionPricePlanModel price, final Double newPrice) {
    Double variantPrice = newPrice != null ? newPrice : getCurrentPrice(price);
    Double minimumPrice = variantPrice;
    TmaSimpleProductOfferingModel baseProduct = getCommercePriceService().getBaseProduct(price);
    TmaPoVariantModel productVariant = (TmaPoVariantModel) price.getProduct();
    Collection<TmaPoVariantModel> variants = baseProduct.getTmaPoVariants().stream()
        .filter(tmaPoVariantModel -> !tmaPoVariantModel.getCode().equals(productVariant.getCode()) && ArticleApprovalStatus.APPROVED.equals(tmaPoVariantModel.getApprovalStatus()))
        .collect(Collectors.toList());

    if (CollectionUtils.isEmpty(variants)) {
      setDefaultVariant(baseProduct, productVariant);
      return;
    }

    for (TmaPoVariantModel variant : variants) {
      Double variantMinPrice = getMinimumPrice(variant);
      if (variantMinPrice != null && Double.compare(variantMinPrice, minimumPrice) < 0) {
        minimumPrice = variantMinPrice;
        setDefaultVariant(baseProduct, variant);
      }
    }

    if (minimumPrice.equals(variantPrice)) {
      setDefaultVariant(baseProduct, productVariant);
    }
  }

  private void setDefaultVariant(TmaSimpleProductOfferingModel baseProduct, TmaPoVariantModel variant) {
    baseProduct.setDefaultTmaPoVariant(variant);
    getModelService().save(baseProduct);
  }

  private Double getCurrentPrice(SubscriptionPricePlanModel price) {
    if (CollectionUtils.isNotEmpty(price.getRecurringChargeEntries())) {
      return price.getRecurringChargeEntries().iterator().next().getPrice();
    }

    if (CollectionUtils.isNotEmpty(price.getOneTimeChargeEntries())) {
      return price.getOneTimeChargeEntries().iterator().next().getPrice();
    }

    return Double.MAX_VALUE;
  }

  private TmaSimpleProductOfferingModel getBaseProduct(ProductModel product) {
    if (product instanceof TmaSimpleProductOfferingModel) {
      if (product instanceof TmaPoVariantModel) {
        return ((TmaPoVariantModel) product).getTmaBasePo();
      } else {
        return (TmaSimpleProductOfferingModel) product;
      }
    }
    return null;
  }

  private PriceRowModel getMinimumPriceRowFromCollection(final Set<PriceRowModel> prices) {
    return CollectionUtils.isNotEmpty(prices) ? Collections.min(prices, getPriceRowComparator()) : null;
  }

  private Set<SubscriptionPricePlanModel> findPricesAtParentLevel(TmaPriceContext tmaPriceContext) {
    if (tmaPriceContext.getAffectedProduct() == null || CollectionUtils.isEmpty(tmaPriceContext.getParents())) {
      return Collections.emptySet();
    }

    return getSubscriptionPricePlanDao().findApplicableSubscriptionPricePlans(tmaPriceContext);
  }

  @Override
  protected BatelcoPriceContextFactory getPriceContextFactory() {
    return priceContextFactory;
  }

  @Required
  public void setPriceContextFactory(BatelcoPriceContextFactory priceContextFactory) {
    this.priceContextFactory = priceContextFactory;
  }

  protected BaseStoreService getBaseStoreService() {
    return baseStoreService;
  }

  @Required
  public void setBaseStoreService(BaseStoreService baseStoreService) {
    this.baseStoreService = baseStoreService;
  }

  protected SessionService getSessionService() {
    return sessionService;
  }

  @Required
  public void setSessionService(SessionService sessionService) {
    this.sessionService = sessionService;
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }
}
