package bt.batelco.core.price.service;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.model.attribute.AbstractDynamicAttributeHandler;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

/**
 * Dynamic attribute that gets the base product it the affected product offering is a variant.
 */
public class MainAffectedProductOfferingSubscriptionPricePlanAttribute extends
                                                                       AbstractDynamicAttributeHandler<ProductModel, SubscriptionPricePlanModel> {
  @Override
  public ProductModel get(SubscriptionPricePlanModel model) {
    if (model.getAffectedProductOffering() instanceof TmaPoVariantModel) {
      return ((TmaPoVariantModel) model.getAffectedProductOffering()).getTmaBasePo();
    }
    return model.getAffectedProductOffering();
  }
}
