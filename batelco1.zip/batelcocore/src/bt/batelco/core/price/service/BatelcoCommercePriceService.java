package bt.batelco.core.price.service;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.services.TmaCommercePriceService;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.subscriptionservices.model.OneTimeChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.RecurringChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

/**
 *
 */
public interface BatelcoCommercePriceService extends TmaCommercePriceService {

  /**
   * Retrieves the base product from a subscription price plan
   *
   * @param priceRow the price row
   * @return the base product
   */
  TmaSimpleProductOfferingModel getBaseProduct(PriceRowModel priceRow);

  /**
   * Retrieves the minimum price for the given product
   *
   * @param product the product
   * @return the minimum price
   */
  Double getMinimumPrice(TmaSimpleProductOfferingModel product);

  /**
   * Resets the default variant for the given base product based on minimum price.
   * When the {@code newPrice} is null the new price is calculated from the current {@link RecurringChargeEntryModel} or
   * {@link OneTimeChargeEntryModel} of the {@link  SubscriptionPricePlanModel}
   *
   * @param priceRow the product {@link SubscriptionPricePlanModel}
   * @param newPrice the product new price (can be null)
   */
  void resetDefaultVariant(final SubscriptionPricePlanModel priceRow, final Double newPrice);
}
