package bt.batelco.core.price.service;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.TmaSpoSource;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commerceservices.search.solrfacetsearch.provider.impl.CommerceClassificationPropertyValueProvider;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.solrfacetsearch.config.IndexConfig;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;
import de.hybris.platform.solrfacetsearch.config.exceptions.FieldValueProviderException;
import de.hybris.platform.solrfacetsearch.provider.FieldValue;

import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * A provider that gets the classification value from all the variants
 */
public class AllVariantsClassificationProvider extends CommerceClassificationPropertyValueProvider {

  private TmaSpoSource spoSource;

  @Override
  public Collection<FieldValue> getFieldValues(IndexConfig cfg, IndexedProperty prop, Object model)
      throws FieldValueProviderException {
    if (!(model instanceof PriceRowModel)) {
      return Collections.emptyList();
    }
    Set<FieldValue> fieldValues = new HashSet<>();
    ProductModel productModel = spoSource.getProduct((PriceRowModel) model);
    if (productModel instanceof TmaPoVariantModel) {
      TmaSimpleProductOfferingModel baseProduct = ((TmaPoVariantModel) productModel).getTmaBasePo();
      fieldValues.addAll(super.getFieldValues(cfg, prop, baseProduct));
      for (TmaPoVariantModel variant : baseProduct.getTmaPoVariants()) {
        fieldValues.addAll(super.getFieldValues(cfg, prop, variant));
      }
    } else {
      fieldValues.addAll(super.getFieldValues(cfg, prop, productModel));
    }
    return fieldValues;
  }

  @Required
  public void setSpoSource(TmaSpoSource spoSource) {
    this.spoSource = spoSource;
  }
}
