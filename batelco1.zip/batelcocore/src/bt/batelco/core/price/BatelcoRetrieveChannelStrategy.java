package bt.batelco.core.price;

import de.hybris.platform.enumeration.EnumerationService;
import de.hybris.platform.europe1.channel.strategies.RetrieveChannelStrategy;
import de.hybris.platform.europe1.enums.PriceRowChannel;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;

public class BatelcoRetrieveChannelStrategy implements RetrieveChannelStrategy {
  private static final String UI_EXPERIENCE_SERVICE_DETECTED_LEVEL = "UiExperienceService-Detected-Level";
  private static final String CHANNEL = "channel";
  private static final String PRICE_ROW_CHANNEL = "PriceRowChannel";
  private static final Logger LOG = Logger.getLogger(BatelcoRetrieveChannelStrategy.class);

  private EnumerationService enumerationService;


  public PriceRowChannel getChannel(SessionContext ctx) {
    PriceRowChannel priceRowChannel = null;
    if (ctx != null && ctx.getAttribute(UI_EXPERIENCE_SERVICE_DETECTED_LEVEL) != null) {
      priceRowChannel = getPriceRowChannel(ctx,CHANNEL);
      if (priceRowChannel == null) {
        priceRowChannel = getPriceRowChannel(ctx,UI_EXPERIENCE_SERVICE_DETECTED_LEVEL);
        if (priceRowChannel != null) {
          ctx.setAttribute(CHANNEL, priceRowChannel);
        }
      }

      LOG.debug("Price row channel " + priceRowChannel);
      return priceRowChannel;
    }

    return priceRowChannel;
  }

  private PriceRowChannel getPriceRowChannel(SessionContext ctx, String channel) {
    PriceRowChannel priceRowChannel;
    if (ctx.getAttribute(channel) instanceof EnumerationValue) {
      priceRowChannel = getEnumValueForCode(((EnumerationValue) ctx.getAttribute(channel)).getCode());
    } else {
      priceRowChannel = (PriceRowChannel) ctx.getAttribute(channel);
    }
    return priceRowChannel;
  }


  private PriceRowChannel getEnumValueForCode(String channel) {
    PriceRowChannel channelFromDb = null;

    try {
      channelFromDb = (PriceRowChannel) enumerationService.getEnumerationValue("PRICE_ROW_CHANNEL", channel);
    } catch (UnknownIdentifierException var3) {
      LOG.debug("This Enum is not setup in PriceRowChannel dynamic enum");
    }

    return channelFromDb;
  }

  @Override
  public List<PriceRowChannel> getAllChannels() {
    return enumerationService.getEnumerationValues(PRICE_ROW_CHANNEL);
  }

  @Required
  public void setEnumerationService(EnumerationService enumerationService) {
    this.enumerationService = enumerationService;
  }
}
