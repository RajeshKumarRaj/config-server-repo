package bt.batelco.core.price.calculation.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.commerceservices.strategies.NetGrossStrategy;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.jalo.order.price.PDTInformation;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.order.strategies.calculation.pdt.FindPDTValueInfoStrategy;
import de.hybris.platform.order.strategies.calculation.pdt.criteria.TaxValueInfoCriteria;
import de.hybris.platform.order.strategies.calculation.pdt.criteria.impl.DefaultTaxValueInfoCriteria;
import de.hybris.platform.order.strategies.calculation.pdt.impl.PDTEnumGroupsHelper;
import de.hybris.platform.util.PriceValue;
import de.hybris.platform.util.TaxValue;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import bt.batelco.core.price.calculation.BatelcoPriceCalculationService;

/**
 * Default implementation of {@link BatelcoPriceCalculationService}
 */
public class DefaultBatelcoPriceCalculationService implements BatelcoPriceCalculationService {
  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoPriceCalculationService.class);
  private static final int QUANTITY = 1;

  private PDTEnumGroupsHelper pdtEnumGroupsHelper;
  private FindPDTValueInfoStrategy<TaxValue, PDTInformation, TaxValueInfoCriteria> defaultFindTaxValueInfoStrategy;
  private NetGrossStrategy netGrossStrategy;


  @Override
  public Optional<TaxValue> computeTaxValue(BigDecimal price, CurrencyModel currency, TmaProductOfferingModel productOffering) {
    TaxValueInfoCriteria taxCriteria = DefaultTaxValueInfoCriteria.buildForValue().withCurrency(currency)
        .withProductTaxGroup(pdtEnumGroupsHelper.getPTG(productOffering)).build();

    try {
      List<TaxValue> taxValues = defaultFindTaxValueInfoStrategy.getPDTValues(taxCriteria);
      if (CollectionUtils.isEmpty(taxValues)) {
        LOG.debug("No tax information is available");
        return Optional.empty();
      }
      return Optional.ofNullable(
          taxValues.get(0).apply(QUANTITY, price.doubleValue(), currency.getDigits(), netGrossStrategy.isNet(), currency.getIsocode()));

    } catch (CalculationException ex) {
      LOG.error("An error occurred while computing the taxes {ex}", ex);
      return Optional.empty();
    }
  }

  @Override
  public Optional<PriceValue> computeNetPrice(BigDecimal price, CurrencyModel currency, List<TaxValue> taxes) {
    PriceValue netPriceValue = new PriceValue(currency.getIsocode(), price.doubleValue(), netGrossStrategy.isNet());
    return Optional.ofNullable(netPriceValue.getOtherPrice(taxes));
  }

  @Required
  public void setDefaultFindTaxValueInfoStrategy(
      FindPDTValueInfoStrategy<TaxValue, PDTInformation, TaxValueInfoCriteria> defaultFindTaxValueInfoStrategy) {
    this.defaultFindTaxValueInfoStrategy = defaultFindTaxValueInfoStrategy;
  }

  @Required
  public void setPdtEnumGroupsHelper(PDTEnumGroupsHelper pdtEnumGroupsHelper) {
    this.pdtEnumGroupsHelper = pdtEnumGroupsHelper;
  }

  @Required
  public void setNetGrossStrategy(NetGrossStrategy netGrossStrategy) {
    this.netGrossStrategy = netGrossStrategy;
  }
}
