package bt.batelco.core.price.calculation;


import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.util.PriceValue;
import de.hybris.platform.util.TaxValue;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Service responsible for computation the prices based on taxes
 */
public interface BatelcoPriceCalculationService {

  /**
   * Responsible for computing the tax corresponding for the given price
   *
   * @param price    price value
   * @param currency currency
   * @param net      net or gross price
   * @return the computed {@link TaxValue} if available, otherwise {@link Optional#empty()}
   */
  Optional<TaxValue> computeTaxValue(BigDecimal price, CurrencyModel currency, TmaProductOfferingModel productOffering);

  /**
   * Responsible for computing the net price for the given value and taxes
   *
   * @param price    price value
   * @param currency currency
   * @param taxes    tax values
   * @return the computed gross {@link PriceValue}, otherwise {@link Optional#empty()}
   */
  Optional<PriceValue> computeNetPrice(BigDecimal price, CurrencyModel currency, List<TaxValue> taxes);

}
