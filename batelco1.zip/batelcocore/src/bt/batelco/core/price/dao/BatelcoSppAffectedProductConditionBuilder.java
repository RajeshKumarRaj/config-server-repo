package bt.batelco.core.price.dao;

import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.b2ctelcoservices.pricing.dao.TmaSppAffectedProductConditionBuilder;

import org.apache.commons.collections.CollectionUtils;

/**
 * Custom implementation of {@link TmaSppAffectedProductConditionBuilder}
 */
public class BatelcoSppAffectedProductConditionBuilder extends TmaSppAffectedProductConditionBuilder {

  @Override
  protected boolean shouldApplyCondition(final TmaPriceContext priceContext) {
    return priceContext != null &&
           ((productIsBpo(priceContext.getProduct()) || CollectionUtils.isNotEmpty(priceContext.getParents()))
            && priceContext.getAffectedProduct() != null);
  }
}
