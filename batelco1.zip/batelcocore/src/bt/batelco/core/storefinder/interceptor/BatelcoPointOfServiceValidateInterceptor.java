package bt.batelco.core.storefinder.interceptor;


import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.ValidateInterceptor;
import de.hybris.platform.storelocator.model.PointOfServiceModel;

public class BatelcoPointOfServiceValidateInterceptor implements ValidateInterceptor<PointOfServiceModel> {

  @Override
  public void onValidate(PointOfServiceModel posModel, InterceptorContext interceptorContext)
      throws InterceptorException
  {
    validateLatitude(posModel);
    validateLongitude(posModel);
  }

  private void validateLatitude(PointOfServiceModel posModel) throws InterceptorException {
    if (posModel.getLatitude() == null || posModel.getLatitude() == 0) {
      throw new InterceptorException("Latitude must not be empty");
    }
  }

  private void validateLongitude(PointOfServiceModel posModel) throws InterceptorException {
    if (posModel.getLongitude() == null || posModel.getLongitude() == 0) {
      throw new InterceptorException("Longitude must not be empty");
    }
  }
}
