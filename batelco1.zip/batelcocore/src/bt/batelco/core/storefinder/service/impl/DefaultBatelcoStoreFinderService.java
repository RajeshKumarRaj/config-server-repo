package bt.batelco.core.storefinder.service.impl;

import de.hybris.platform.commerceservices.storefinder.impl.DefaultStoreFinderService;
import de.hybris.platform.commerceservices.store.data.GeoPoint;
import de.hybris.platform.commerceservices.storefinder.StoreFinderService;
import de.hybris.platform.commerceservices.storefinder.data.PointOfServiceDistanceData;
import de.hybris.platform.commerceservices.storefinder.data.StoreFinderSearchPageData;
import de.hybris.platform.storelocator.model.PointOfServiceModel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Default Batelco implementation of {@link StoreFinderService}
 *
 * @param <ITEM>
 *           distance to point of service
 */
public class DefaultBatelcoStoreFinderService<ITEM extends PointOfServiceDistanceData> extends
    DefaultStoreFinderService<ITEM> implements
    StoreFinderService<ITEM, StoreFinderSearchPageData<ITEM>>
{

  private static final int NO_DISTANCE = 0;

  @Override
  protected double calculateDistance(final GeoPoint centerPoint, final PointOfServiceModel posModel)
  {
      return NO_DISTANCE;
  }
}
