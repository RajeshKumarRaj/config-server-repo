package bt.batelco.core.consent.impl;

import de.hybris.platform.commerceservices.consent.CommerceConsentService;
import de.hybris.platform.commerceservices.consent.exceptions.CommerceConsentGivenException;
import de.hybris.platform.commerceservices.consent.impl.DefaultCommerceConsentService;
import de.hybris.platform.commerceservices.event.ConsentGivenEvent;
import de.hybris.platform.commerceservices.model.consent.ConsentModel;
import de.hybris.platform.commerceservices.model.consent.ConsentTemplateModel;
import de.hybris.platform.core.model.user.CustomerModel;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Default batelco implementation of {@link CommerceConsentService}
 */
public class DefaultBatelcoConsentService extends DefaultCommerceConsentService {

  @Override
  public void giveConsent(final CustomerModel customer, final ConsentTemplateModel consentTemplate) {
    validateParameterNotNullStandardMessage("customer", customer);
    validateParameterNotNullStandardMessage("consentTemplate", consentTemplate);

    ConsentModel consent = getActiveConsent(customer, consentTemplate);

    boolean withdrawable = consent != null &&
                           consent.getConsentTemplate() != null && consent.getConsentTemplate().getWithdrawable();

    if (withdrawable && isConsentGiven(consent) && !isConsentWithdrawn(consent)) {
      throw new CommerceConsentGivenException(
          String.format(
              "User with uid : [%s] has already given consent for ConsentTemplate with id : [%s], version : [%s] ",
              customer.getUid(), consentTemplate.getId(), consentTemplate.getVersion()));
    }

    if (consent == null || isConsentWithdrawn(consent)) {
      consent = createConsentModel(customer, consentTemplate);
    }

    consent.setConsentGivenDate(getTimeService().getCurrentTime());
    getModelService().save(consent);
    getEventService().publishEvent(initializeEvent(new ConsentGivenEvent(), consent));
  }
}
