package bt.batelco.core.product;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.services.TmaSubscriptionTermService;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import java.util.Set;

public interface BatelcoSubscriptionTermService extends TmaSubscriptionTermService {
  /**
   * Returns all subscription terms found in the price plans configured on given spo
   * Note: if a price plan has no subscription terms, then all subscription terms will be considered.
   *
   * @param spo         simple product offering
   * @param processType the process type for which price plans will be considered
   * @return {@link Set} of {@link SubscriptionTermModel}
   */
  Set<SubscriptionTermModel> getSpoApplicableSubscriptionTerms(TmaProductOfferingModel spo,
                                                               TmaProcessType processType);
}
