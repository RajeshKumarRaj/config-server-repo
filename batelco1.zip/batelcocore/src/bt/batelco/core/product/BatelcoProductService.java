package bt.batelco.core.product;

import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.services.TmaPoService;

/**
 * Service handling business logic around {@link TmaProductOfferingModel} and Batelco specific logic.
 */
public interface BatelcoProductService extends TmaPoService {

  /**
   * Retrieves the default variant's code for the given product code
   *
   * @param slangCode product code
   * @return default variant or product
   */
  TmaProductOfferingModel getProductOfferingForSlang(String slangCode);
}
