package bt.batelco.core.product;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.model.attribute.AbstractDynamicAttributeHandler;

/**
 * Attribute handler for determine if product is preorder
 */
public class PreorderProductAttributeHandler
    extends AbstractDynamicAttributeHandler<Boolean, ProductModel> {
  private static final String PREORDER_CATEGORY_CODE = "preorder";

  @Override
  public Boolean get(ProductModel model) {
    return model.getSupercategories().stream()
        .anyMatch(categoryModel -> PREORDER_CATEGORY_CODE.equalsIgnoreCase(categoryModel.getCode()));
  }
}
