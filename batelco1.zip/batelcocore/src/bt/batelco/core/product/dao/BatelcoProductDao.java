package bt.batelco.core.product.dao;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.daos.ProductDao;

import java.util.List;

public interface BatelcoProductDao extends ProductDao {

  /**
   * Returns for the given product <code>slang</code> the {@link ProductModel} collection.
   *
   * @param slang the product <code>code</code>
   * @return a {@link ProductModel}
   * @throws IllegalArgumentException if the given <code>slang</code> is <code>null</code>
   */
  List<ProductModel> findProductsBySlang(final String slang);

}
