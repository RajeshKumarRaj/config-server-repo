package bt.batelco.core.product.dao.impl;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.daos.ProductDao;
import de.hybris.platform.product.daos.impl.DefaultProductDao;

import java.util.Collections;
import java.util.List;

import bt.batelco.core.product.dao.BatelcoProductDao;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

/**
 * Default implementation of the {@link ProductDao}.
 */
public class DefaultBatelcoProductDao extends DefaultProductDao implements BatelcoProductDao {

  public DefaultBatelcoProductDao(final String typecode) {
    super(typecode);
  }

  @Override
  public List<ProductModel> findProductsBySlang(String slang) {
    validateParameterNotNull(slang, "Product slang code must not be null!");

    return find(Collections.singletonMap(ProductModel.SLANG, (Object) slang));
  }
}
