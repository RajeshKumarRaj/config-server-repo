package bt.batelco.core.product.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.services.impl.DefaultTmaPoService;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.exceptions.ModelNotFoundException;

import org.springframework.beans.factory.annotation.Required;

import java.util.List;

import bt.batelco.core.product.BatelcoProductService;
import bt.batelco.core.product.dao.BatelcoProductDao;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateIfSingleResult;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;
import static java.lang.String.format;

public class DefaultBatelcoProductService extends DefaultTmaPoService implements BatelcoProductService {

  private BatelcoProductDao batelcoProductDao;

  @Override
  public TmaProductOfferingModel getProductOfferingForSlang(String productCode) {
    TmaProductOfferingModel product = getPoForSlang(productCode);
    if (product instanceof TmaSimpleProductOfferingModel) {
      TmaSimpleProductOfferingModel productOffering = (TmaSimpleProductOfferingModel) product;
      if (productOffering.getDefaultTmaPoVariant() != null) {
        return productOffering.getDefaultTmaPoVariant();
      }
    }
    return product;
  }

  private TmaProductOfferingModel getPoForSlang(final String slang) {
    final ProductModel productModel = getProductForSlang(slang);
    if (productModel instanceof TmaProductOfferingModel) {
      return (TmaProductOfferingModel) productModel;
    }
    throw new ModelNotFoundException(TmaProductOfferingModel._TYPECODE + format("  with code '%s' not found!", slang));
  }

  private ProductModel getProductForSlang(final String slang) {
    validateParameterNotNull(slang, "Parameter code must not be null");
    final List<ProductModel> products = batelcoProductDao.findProductsBySlang(slang);

    validateIfSingleResult(products, format("Product with slang code '%s' not found!", slang),
                           format("Product slang code '%s' is not unique, %d products found!", slang, products.size()));

    return products.get(0);
  }

  @Required
  public void setBatelcoProductDao(BatelcoProductDao batelcoProductDao) {
    this.batelcoProductDao = batelcoProductDao;
  }
}
