package bt.batelco.core.product.impl;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.services.impl.DefaultTmaSubscriptionTermService;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import bt.batelco.core.product.BatelcoSubscriptionTermService;

public class DefaultBatelcoSubscriptionTermService extends DefaultTmaSubscriptionTermService implements
                                                                                             BatelcoSubscriptionTermService {
  @Override
  public Set<SubscriptionTermModel> getSpoApplicableSubscriptionTerms(TmaProductOfferingModel spo,
                                                                   TmaProcessType processType) {

    final List<SubscriptionTermModel> allSubscriptionTerms = getAllSubscriptionTerms();
    return getSubscriptionTermsFromSpo(spo, processType, allSubscriptionTerms);
  }

  private Set<SubscriptionTermModel> getSubscriptionTermsFromSpo(final TmaProductOfferingModel spo,
                                                                 final TmaProcessType processType,
                                                                 final List<SubscriptionTermModel> allSubscriptionTerms) {
    final Set<SubscriptionPricePlanModel>
        applicablePricePlans =
        getSubscriptionPricePlansForProcessType(spo, processType);
    return getSubscriptionTerms(applicablePricePlans, allSubscriptionTerms);
  }

  private Set<SubscriptionPricePlanModel> getSubscriptionPricePlansForProcessType(final TmaProductOfferingModel spo,
                                                                                  final TmaProcessType processType) {
    return getAllSubscriptionPricePlans(spo).stream()
        .filter(pp -> containsProcessType(pp, processType))
        .collect(Collectors.toSet());
  }

  private Set<SubscriptionTermModel> getSubscriptionTerms(final Set<SubscriptionPricePlanModel> applicablePricePlans,
                                                          final List<SubscriptionTermModel> allSubscriptionTerms) {
    final Set<SubscriptionTermModel> subscriptionTerms = new HashSet<>();
    for (final SubscriptionPricePlanModel pricePlan : applicablePricePlans) {
      if (pricePlan.getSubscriptionTerms().isEmpty()) {
        subscriptionTerms.addAll(allSubscriptionTerms);
        break;
      } else {
        subscriptionTerms.addAll(getApplicableSubscriptionTerms(pricePlan, allSubscriptionTerms));
      }
    }
    return subscriptionTerms;
  }

  private Set<SubscriptionPricePlanModel> getAllSubscriptionPricePlans(final TmaProductOfferingModel po) {
    return po.getEurope1Prices().stream()
        .filter(p -> p instanceof SubscriptionPricePlanModel)
        .map(p -> (SubscriptionPricePlanModel) p)
        .collect(Collectors.toSet());
  }

  private boolean containsProcessType(final SubscriptionPricePlanModel pp, final TmaProcessType processType) {
    return pp.getProcessTypes() == null || pp.getProcessTypes().isEmpty() || pp.getProcessTypes().contains(processType);
  }

  private Set<SubscriptionTermModel> getApplicableSubscriptionTerms(final SubscriptionPricePlanModel pricePlanModel,
                                                                    final List<SubscriptionTermModel> subscriptionTerms)
  {
    return pricePlanModel.getSubscriptionTerms().stream()
        .filter(pricePlanTerm -> subscriptionTerms.contains(pricePlanTerm)).collect(Collectors.toSet());
  }
}
