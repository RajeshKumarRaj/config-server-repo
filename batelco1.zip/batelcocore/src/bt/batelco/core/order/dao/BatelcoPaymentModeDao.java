package bt.batelco.core.order.dao;

import de.hybris.platform.order.daos.PaymentModeDao;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import java.util.List;

/**
 * Data Access Object oriented on PaymentMode
 */
public interface BatelcoPaymentModeDao extends PaymentModeDao {


  /**
   * Search for all offline parent PaymentModes if {@code offlineOnly} is TRUE.
   *
   * @param offlineOnly if true search only offline parent PaymentModes
   */
  List<StandardPaymentModeModel> findApplicableCheckoutPaymentTypes(boolean offlineOnly);
}
