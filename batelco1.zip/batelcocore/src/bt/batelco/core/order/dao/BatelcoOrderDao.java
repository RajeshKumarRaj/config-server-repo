package bt.batelco.core.order.dao;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.order.daos.OrderDao;

import java.util.List;

/**
 * Custom interface used to manage an order.
 */
public interface BatelcoOrderDao extends OrderDao {
  /**
   * Returns all orders which have one of the order status from the given list.
   *
   * @param orderStatuses target a list of {@link OrderStatus}
   * @return {@link List} of {@link AbstractOrderModel} - matched orders
   */
  List<AbstractOrderModel> findOrdersByStatuses(List<OrderStatus> orderStatuses);
}
