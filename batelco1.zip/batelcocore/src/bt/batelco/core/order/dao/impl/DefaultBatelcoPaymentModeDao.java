package bt.batelco.core.order.dao.impl;

import de.hybris.platform.core.model.ItemModel;
import de.hybris.platform.order.daos.impl.DefaultPaymentModeDao;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;

import java.util.List;

import bt.batelco.core.order.dao.BatelcoPaymentModeDao;

public class DefaultBatelcoPaymentModeDao extends DefaultPaymentModeDao implements BatelcoPaymentModeDao {
  
	
  private static final String IS_ONLINE_PARAM = "isOnline";

  private static final String ALL_BASE_PAYMENT_MODES =
      "SELECT {" + ItemModel.PK + "} FROM {" + StandardPaymentModeModel._TYPECODE + "}"
      + " WHERE {" + StandardPaymentModeModel.PARENT + "} is null";

  private static final String OFFLINE_PAYMENT_MODES =
      "SELECT {" + ItemModel.PK + "} FROM {" + StandardPaymentModeModel._TYPECODE + "}"
      + " WHERE {" + StandardPaymentModeModel.PARENT + "} is null"
      + " AND {" + StandardPaymentModeModel.ONLINE + "} = ?" + IS_ONLINE_PARAM;


  @Override
  public List<StandardPaymentModeModel> findApplicableCheckoutPaymentTypes(boolean offlineOnly) {

    FlexibleSearchQuery queryOffline  = new FlexibleSearchQuery(OFFLINE_PAYMENT_MODES);
    queryOffline.addQueryParameter(IS_ONLINE_PARAM, offlineOnly );
    FlexibleSearchQuery queryAllModes= new FlexibleSearchQuery(ALL_BASE_PAYMENT_MODES);

    FlexibleSearchQuery query = offlineOnly ? queryOffline : queryAllModes;

    return getFlexibleSearchService().<StandardPaymentModeModel>search(query).getResult();
  }
}
