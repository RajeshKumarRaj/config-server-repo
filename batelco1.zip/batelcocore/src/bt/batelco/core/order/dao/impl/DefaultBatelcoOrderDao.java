package bt.batelco.core.order.dao.impl;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.order.daos.impl.DefaultOrderDao;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;

import java.util.List;

import bt.batelco.core.order.dao.BatelcoOrderDao;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

public class DefaultBatelcoOrderDao extends DefaultOrderDao implements BatelcoOrderDao {
  private static final String ORDER_STATUSES_QUERY_PARAM = "orderStatuses";

  private static final String FIND_ORDERS_WITH_STATUS_IN =
      "SELECT {" + AbstractOrderModel.PK + "} FROM {" + AbstractOrderModel._TYPECODE
      + "} WHERE {" + AbstractOrderModel.STATUS + "} in (?" + ORDER_STATUSES_QUERY_PARAM + ")";

  @Override
  public List<AbstractOrderModel> findOrdersByStatuses(List<OrderStatus> orderStatuses) {
    validateParameterNotNull(orderStatuses, "orderStatuses must not be null!");

    FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_ORDERS_WITH_STATUS_IN);
    query.addQueryParameter(ORDER_STATUSES_QUERY_PARAM, orderStatuses);
    return getFlexibleSearchService().<AbstractOrderModel>search(query).getResult();
  }
}
