package bt.batelco.core.order;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.jalo.order.payment.PaymentInfo;
import de.hybris.platform.order.OrderService;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;

import java.util.Date;
import java.util.List;

/**
 * Custom interface used to manage an order.
 */
public interface BatelcoOrderService extends OrderService {

  /**
   * Updates order status.
   *
   * @param order  the order {@link OrderModel} model
   * @param status the order status {@link OrderStatus}
   * @param impersonate update the status in impersonate mode
   */
  void updateStatus(AbstractOrderModel order, OrderStatus status, boolean impersonate);


  /**
   * Updates order status to payment option expired <code>OrderStatus.ONLINE_PAYMENT_EXPIRED</code> if online payment
   * validity is expired.
   *
   * @param order {@link OrderModel} order model
   * @return flag if the status was updated or not
   */
  boolean updateStatusIfOnlinePaymentExpired(AbstractOrderModel order);

  /**
   * Returns all orders which have one of the order status from the given list.
   *
   * @param orderStatuses target a list of {@link OrderStatus}
   * @return {@link List} of {@link AbstractOrderModel} - matched orders
   */
  List<AbstractOrderModel> findOrdersByStatuses(List<OrderStatus> orderStatuses);

  /**
   * Gets the configured order statuses to be checked for expiry date
   *
   * @return the list of statuses
   */
  List<OrderStatus> getStatusesForExpiryCheck();

  /**
   * Returns the date of payment expiration
   *
   * @param order the order
   * @return {@link Date} of payment expiration
   */
  Date getPaymentOptionValidityDateForOrder(final AbstractOrderModel order);


  /**
   * Gets the configured order statuses to be ignored by the order status change event
   *
   * @return list of statuses
   */
  List<OrderStatus> getStatusesIgnoredOnStatusChangeEvent();

  /**
   * Verify for order and children orders if each order entry has set {@code ServiceNumber} for the {@link PaymentInfo}
   *
   * @param orderModel the order
   * @throws InterceptorException if the order entry has an invalid {@code ServiceNumber}
   */
  void verifyServiceNumbersForOrderAndChildren(OrderModel orderModel) throws InterceptorException;
}
