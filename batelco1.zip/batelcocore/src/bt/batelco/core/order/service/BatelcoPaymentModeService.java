package bt.batelco.core.order.service;

import de.hybris.platform.order.PaymentModeService;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import java.util.List;

/**
 * Service around the {@link StandardPaymentModeModel}.
 */
public interface BatelcoPaymentModeService extends PaymentModeService {

  /**
   * Gets all offline parent PaymentModes if {@code offlineOnly} is TRUE
   *
   * @param offlineOnly if true search only offline parent PaymentModes
   */
  List<StandardPaymentModeModel> getApplicableCheckoutPaymentTypes(boolean offlineOnly);
  
  
}
