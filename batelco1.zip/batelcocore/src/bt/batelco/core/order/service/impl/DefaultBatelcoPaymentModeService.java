package bt.batelco.core.order.service.impl;

import de.hybris.platform.order.impl.DefaultPaymentModeService;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import org.springframework.beans.factory.annotation.Required;

import java.util.List;

import bt.batelco.core.order.dao.BatelcoPaymentModeDao;
import bt.batelco.core.order.service.BatelcoPaymentModeService;

public class DefaultBatelcoPaymentModeService extends DefaultPaymentModeService implements BatelcoPaymentModeService {

  private BatelcoPaymentModeDao batelcoPaymentModeDao;

  @Override
  public List<StandardPaymentModeModel> getApplicableCheckoutPaymentTypes(boolean isOnline) {
    return batelcoPaymentModeDao.findApplicableCheckoutPaymentTypes(isOnline);
  }

  @Required
  public void setBatelcoPaymentModeDao(BatelcoPaymentModeDao batelcoPaymentModeDao) {
    this.batelcoPaymentModeDao = batelcoPaymentModeDao;
  }
}
