package bt.batelco.core.order.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.log4j.Logger;

import bt.batelco.core.event.OrderStatusChangedEvent;
import bt.batelco.core.event.OrderStatusUpdateEvent;
import bt.batelco.core.order.service.BatelcoOrderUpdateService;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.util.mail.MailUtils;
import de.hybris.platform.commerceservices.event.UpdatedProfileEvent;
import de.hybris.platform.core.enums.DeliveryStatus;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.model.ModelService;

public class DefaultBatelcoOrderUpdateService implements BatelcoOrderUpdateService {

	private static final Logger LOG = Logger.getLogger(DefaultBatelcoOrderUpdateService.class);
	
	private FlexibleSearchService flexibleSearchService;
	private ModelService modelService;
	private EventService eventService;
	
	public EventService getEventService() {
		return eventService;
	}

	public void setEventService(EventService eventService) {
		this.eventService = eventService;
	}

	public ModelService getModelService() {
		return modelService;
	}

	public void setModelService(ModelService modelService) {
		this.modelService = modelService;
	}

	public FlexibleSearchService getFlexibleSearchService() {
		return flexibleSearchService;
	}

	public void setFlexibleSearchService(FlexibleSearchService flexibleSearchService) {
		this.flexibleSearchService = flexibleSearchService;
	}

	@Override
	public String updateOrderStatus(String hybrisOrderId, String seibelOrderId, String orderStatus,
			String deliveryStatus, String deliveryPartnerName, String deliveryPartnerTrackingId, String deliveredDate,
			String remarks) {
		String response;

		try
		{
			LOG.info("hybrisOrderId" + hybrisOrderId);


			final OrderModel currentOrderModel = new OrderModel();
			currentOrderModel.setCode(hybrisOrderId);
			final OrderModel orderModel = flexibleSearchService.getModelByExample(currentOrderModel);
			LOG.info(orderModel);
			LOG.info("Order Status" + orderModel.getStatusInfo());
			//orderModel.setStatus(null);

			switch (orderStatus)
			{
				case "CANCELLED":
					orderModel.setStatus(OrderStatus.CANCELLED);
					break;
				case "PROCESSING":
					orderModel.setStatus(OrderStatus.PROCESSING);
					break;
				case "PENDING":
					orderModel.setStatus(OrderStatus.PENDING);
					break;
				case "COMPLETED":
					orderModel.setStatus(OrderStatus.COMPLETED);
					break;

				default:
					// code block
			}

			switch (deliveryStatus)
			{
				case "READY_FOR_PICKUP":
					orderModel.setDeliveryStatus(DeliveryStatus.READY_FOR_PICKUP);
					break;
				case "OUT_OF_DELIVERY":
					orderModel.setDeliveryStatus(DeliveryStatus.OUT_OF_DELIVERY);
					break;
				case "PAID":
					orderModel.setDeliveryStatus(DeliveryStatus.PAID);
					break;
				case "DELIVERED":
					orderModel.setDeliveryStatus(DeliveryStatus.DELIVERED);
					break;
				case "DELIVERY_CANCELLED":
					orderModel.setDeliveryStatus(DeliveryStatus.DELIVERY_CANCELLED);
					break;
				case "RETURN_AWAITING_APPROVAL":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURN_AWAITING_APPROVAL);
					break;
				case "RETURN_APPROVED":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURN_APPROVED);
					break;
				case "RETURN_INITIATED":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURN_INITIATED);
					break;
				case "RETURNED":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURNED);
					break;
				case "RETURNED_REJECTED_BATELCO":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURNED_REJECTED_BATELCO);
					break;
				case "RETURNED_REJECTED_COURIER":
					orderModel.setDeliveryStatus(DeliveryStatus.RETURNED_REJECTED_COURIER);
					break;

				default:
					// default code block
			}
			
			/*
			 * LOG.info(String.
			 * format("LOGII one- Triggering OrderStatusChangedEvent for order %s and with status %s ."
			 * ,orderModel.getCode(),orderModel.getStatus().getCode()));
			 * getEventService().publishEvent(new OrderStatusChangedEvent(orderModel));
			 */
			orderModel.setSeibelOrderId(seibelOrderId);
			orderModel.setDeliveryPartnerTrackingId(deliveryPartnerTrackingId);
			orderModel.setDeliveryPartnerName(deliveryPartnerName);
			final Date delivDate = new SimpleDateFormat("dd/MM/yyyy").parse(deliveredDate);
			LOG.info("delivDate =" + delivDate);
			orderModel.setDeliveredDate(new SimpleDateFormat("dd/MM/yyyy").parse(deliveredDate));
			orderModel.setRemarks(remarks);
			modelService.save(orderModel);
			System.out.println("SAved Order");
			//getEventService().publishEvent(initializeEvent(new OrderStatusUpdateEvent(orderModel), orderModel));

			
			/*
			 * try {
			 * 
			 * final Email email = MailUtils.getPreConfiguredEmail();
			 * email.setCharset("UTF-8"); email.setSubject("Email's subject");
			 * email.addTo("to@foobar.com"); email.setFrom("john@doe.com");
			 * email.setMsg("This is the message (body) of the email!"); email.send(); //
			 * send the email
			 * 
			 * } catch (final EmailException e) { LOG.error("Error sending an email", e); }
			 */
			
			  LOG.info(String.format("LOGII- Triggering OrderStatusUpdateEvent for order %s and with status %s .",orderModel.getCode(),orderModel.getStatus().getCode()));
		       // getEventService().publishEvent(new OrderStatusUpdateEvent(orderModel));
		        final OrderStatusUpdateEvent event = new OrderStatusUpdateEvent(orderModel);
	            event.setOrder(orderModel);
	            getEventService().publishEvent(event);

	            
	            
			response = "sucessfully saved";
		}
		catch (final Exception ex)
		{
			response = "Oops something went wrong" + ex;
		}
		return response;

	}

}
