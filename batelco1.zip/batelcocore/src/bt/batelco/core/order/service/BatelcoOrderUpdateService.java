package bt.batelco.core.order.service;

public interface BatelcoOrderUpdateService {

	String updateOrderStatus(String hybrisOrderId, String seibelOrderId, String orderStatus, String deliveryStatus, String deliveryPartnerName, String deliveryPartnerTrackingId, String deliveredDate, String remarks);
}
