package bt.batelco.core.order.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.commerceservices.impersonation.ImpersonationContext;
import de.hybris.platform.commerceservices.impersonation.ImpersonationService;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.order.impl.DefaultOrderService;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Required;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import bt.batelco.core.constants.BatelcoCoreConstants;
import bt.batelco.core.order.BatelcoOrderService;
import bt.batelco.core.order.dao.BatelcoOrderDao;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

public class DefaultBatelcoOrderService extends DefaultOrderService implements BatelcoOrderService {

  private static final String PAYMENT_OPTION_VALIDITY_PERIOD_CFG_KEY = "online.payment.option.validity.period.in.hours";
  private static final String DEFAULT_ONLINE_PAYMENT_OPTION_VALIDITY_IN_HOURS = "24";
  private static final Logger LOG = Logger.getLogger(DefaultBatelcoOrderService.class);
  private static final List<OrderStatus> DEF_STATUSES_FOR_EXPIRY_CHECK =
      Arrays.asList(OrderStatus.WAITING_ONLINE_PAYMENT, OrderStatus.ONLINE_PAYMENT_FAILED);
  private static final String STATUSES_FOR_EXPIRY_CHECK_CONFIG = "online.payment.order.status.expiry.check";
  private static final String STATUSES_IGNORED_ON_STATUS_CHANGE_EVENT = "order.status.ignore.at.status.change.event";
  private static final List<OrderStatus> DEFAULT_STATUS_IGNORED_ON_STATUS_CHANGE_EVENT =
      Arrays.asList(OrderStatus.ONLINE_PAYMENT_FAILED);
  private static final String SEPARATOR_REGEX = ",";

  private ConfigProviderService configService;
  private ImpersonationService impersonationService;

  @Override
  public void updateStatus(AbstractOrderModel order, OrderStatus status, boolean impersonate) {
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.ORDER_MODEL_PARAM, order);
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.ORDER_STATUS_PARAM, status);
    order.setStatus(status);
    if (impersonate) {
      saveOrderInImpersonateContext(order);
    } else {
      getModelService().save(order);
    }
  }
  
  @Override
  public boolean updateStatusIfOnlinePaymentExpired(final AbstractOrderModel order) {
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.ORDER_MODEL_PARAM, order);
    if (OrderStatus.ONLINE_PAYMENT_EXPIRED.equals(order.getStatus()) || !isOnlinePaymentOptionExpired(order)) {
      return false;
    }
    LOG.info("Online payment option is expired for order [" + order.getCode() + "].");
    updateStatus(order, OrderStatus.ONLINE_PAYMENT_EXPIRED, false);
    LOG.debug("Status of order [" + order.getCode() + "] has been changed to [" + order.getStatus().getCode() + "]");

    return true;
  }

  @Override
  public List<AbstractOrderModel> findOrdersByStatuses(List<OrderStatus> orderStatuses) {
    return ((BatelcoOrderDao) getOrderDao()).findOrdersByStatuses(orderStatuses);
  }

  @Override
  public List<OrderStatus> getStatusesForExpiryCheck() {
    return getConfigOrderStatuses(STATUSES_FOR_EXPIRY_CHECK_CONFIG, DEF_STATUSES_FOR_EXPIRY_CHECK);
  }

  @Override
  public List<OrderStatus> getStatusesIgnoredOnStatusChangeEvent() {
    return getConfigOrderStatuses(STATUSES_IGNORED_ON_STATUS_CHANGE_EVENT,
                                  DEFAULT_STATUS_IGNORED_ON_STATUS_CHANGE_EVENT);
  }

  @Override
  public Date getPaymentOptionValidityDateForOrder(final AbstractOrderModel order) {
    return DateUtils.addHours(order.getAwaitingPaymentStartDate(), Integer.parseInt(getPaymentOptionValidityPeriodInHours()));
  }

  @Override
  public void verifyServiceNumbersForOrderAndChildren(OrderModel orderModel) throws InterceptorException {
    verifyServiceNumbersForOrder(orderModel);
  }

  /**
   * If order entry has no {@code EntryGroupNumbers} check for unique {@code ServiceNumber}, otherwise check if {@code
   * ServiceNumber} is unique for the entire group
   */
  private void verifyServiceNumbersForOrder(AbstractOrderModel orderModel) throws InterceptorException {

    for (AbstractOrderEntryModel entry : orderModel.getEntries()) {

      if (entry.getInfo() == null) {
        throw new InterceptorException("Payment info not set for the order entry [" + entry.getPk() + "]");
      }

      final String serviceNumber = entry.getInfo();
      if (StringUtils.isEmpty(serviceNumber)) {
        throw new InterceptorException("Service number not set for the order entry [" + entry.getPk() + "]");
      }
    }
  }

  private String getPaymentOptionValidityPeriodInHours() {
    return getConfigService().<String>get(PAYMENT_OPTION_VALIDITY_PERIOD_CFG_KEY).conversion(source -> source)
        .onMissing(useDefault(DEFAULT_ONLINE_PAYMENT_OPTION_VALIDITY_IN_HOURS))
        .convert();
  }

  private boolean isOnlinePaymentOptionExpired(final AbstractOrderModel order) {
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.ORDER_MODEL_PARAM, order);

    if (!getStatusesForExpiryCheck().contains(order.getStatus())) {
      return false;
    }

    final Date paymentOptionValidityDate = getPaymentOptionValidityDateForOrder(order);
    final Date currentDate = DateTime.now().toDate();

    // return true if current date is after payment option validity period
    return currentDate != null && currentDate.compareTo(paymentOptionValidityDate) > 0;
  }

  /**
   * Fetches configured order statuses based on key and default order status list
   *
   * @param key             config key
   * @param defaultStatuses default list
   * @return configured list
   */
   
  private List<OrderStatus> getConfigOrderStatuses(String key, List<OrderStatus> defaultStatuses) {

    List<OrderStatus> configuredStatuses = getConfigService().<List<OrderStatus>>get(key)
        .conversion(this::convertToOrderStatus).convert();

    return CollectionUtils.isNotEmpty(configuredStatuses) ? configuredStatuses : defaultStatuses;

  }

  private List<OrderStatus> convertToOrderStatus(String configRes) {
    return Stream.of(configRes.split(SEPARATOR_REGEX)).map(OrderStatus::valueOf).collect(Collectors.toList());
  }

  private void saveOrderInImpersonateContext(AbstractOrderModel order) {
    final ImpersonationContext context = new ImpersonationContext();
    context.setLanguage(((OrderModel) order).getLanguage());
    context.setSite(order.getSite());
    context.setCurrency(order.getCurrency());
    impersonationService.executeInContext(context, () -> {
      getModelService().save(order);
      return null;
    });
  }

  public ConfigProviderService getConfigService() {
    return configService;
  }

  @Required
  public void setConfigService(ConfigProviderService configService) {
    this.configService = configService;
  }

  @Required
  public void setImpersonationService(ImpersonationService impersonationService) {
    this.impersonationService = impersonationService;
  }
}
