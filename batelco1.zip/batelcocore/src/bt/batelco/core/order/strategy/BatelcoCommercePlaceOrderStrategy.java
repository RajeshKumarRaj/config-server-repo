package bt.batelco.core.order.strategy;

import de.hybris.platform.commerceservices.order.impl.DefaultCommercePlaceOrderStrategy;
import de.hybris.platform.commerceservices.service.data.CommerceCheckoutParameter;
import de.hybris.platform.commerceservices.service.data.CommerceOrderResult;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.promotions.model.PromotionResultModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

/**
 * Custom implementation of {@link DefaultCommercePlaceOrderStrategy}
 */
public class BatelcoCommercePlaceOrderStrategy extends DefaultCommercePlaceOrderStrategy {
  private static final Logger LOG = LoggerFactory.getLogger(BatelcoCommercePlaceOrderStrategy.class);

  @Override
  public CommerceOrderResult placeOrder(final CommerceCheckoutParameter parameter) throws InvalidCartException {
    final CartModel cartModel = parameter.getCart();
    validateParameterNotNull(cartModel, "Cart model cannot be null");
    final CommerceOrderResult result = new CommerceOrderResult();

    try {
      beforePlaceOrder(parameter);
      if (getCalculationService().requiresCalculation(cartModel)) {
        LOG.error(String.format("CartModel's [%s] calculated flag was false", cartModel.getCode()));
      }

      final CustomerModel customer = (CustomerModel) cartModel.getUser();
      validateParameterNotNull(customer, "Customer model cannot be null");

      final OrderModel orderModel = getOrderService().createOrderFromCart(cartModel);
      if (orderModel != null) {
        // Reset the Date attribute for use in determining when the order was placed
        orderModel.setDate(getTimeService().getCurrentTime());

        // Store the current site and store on the order
        orderModel.setSite(getBaseSiteService().getCurrentBaseSite());
        orderModel.setStore(getBaseStoreService().getCurrentBaseStore());
        orderModel.setLanguage(getCommonI18NService().getCurrentLanguage());
        orderModel.setCprId(customer.getCprId());

        if (parameter.getSalesApplication() != null) {
          orderModel.setSalesApplication(parameter.getSalesApplication());
        }

        // clear the promotionResults that where cloned from cart PromotionService.transferPromotionsToOrder will copy them over bellow.
        orderModel.setAllPromotionResults(Collections.<PromotionResultModel>emptySet());

        getModelService().saveAll(customer, orderModel);

        if (cartModel.getPaymentInfo() != null && cartModel.getPaymentInfo().getBillingAddress() != null) {
          final AddressModel billingAddress = cartModel.getPaymentInfo().getBillingAddress();
          orderModel.setPaymentAddress(billingAddress);
          orderModel.getPaymentInfo().setBillingAddress(getModelService().clone(billingAddress));
          getModelService().save(orderModel.getPaymentInfo());
        }
        getModelService().save(orderModel);
        // Transfer promotions to the order
        getPromotionsService().transferPromotionsToOrder(cartModel, orderModel, false);

        // Calculate the order now that it has been copied
        try {
          getCalculationService().calculateTotals(orderModel, false);
          getExternalTaxesService().calculateExternalTaxes(orderModel);
        } catch (final CalculationException ex) {
          LOG.error("Failed to calculate order [" + orderModel + "]", ex);
        }

        getModelService().refresh(orderModel);
        getModelService().refresh(customer);

        result.setOrder(orderModel);

        this.beforeSubmitOrder(parameter, result);

        getOrderService().submitOrder(orderModel);
      } else {
        throw new IllegalArgumentException(String.format("Order was not properly created from cart %s", cartModel.getCode()));
      }
    } finally {
      getExternalTaxesService().clearSessionTaxDocument();
    }

    this.afterPlaceOrder(parameter, result);

    // at this point media references are transferred to orderModel so we detach them from cartModel in order to prevent media deletion when the cartModel is deleted
    detachMediasFromCart(cartModel);

    return result;
  }

  private void detachMediasFromCart(final CartModel cartModel) {
    cartModel.setCprFront(null);
    cartModel.setCprBack(null);
    cartModel.getEntries().forEach(entry -> entry.setAcquisitionForm(null));
    cartModel.setPaymentEvidence(null);
  }
}
