package bt.batelco.core.order;

import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.model.attribute.AbstractDynamicAttributeHandler;

import org.apache.commons.collections.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Attribute handler for determine if cart is preorder
 */
public class PreorderAtrributeHandler extends AbstractDynamicAttributeHandler<Boolean, AbstractOrderModel> {
  /**
   * Establish if cart is preorder. Only one product can be ordered as preorder product.
   */
  @Override
  public Boolean get(AbstractOrderModel model) {

    List<ProductModel> productModels =
        model.getEntries().stream().map(AbstractOrderEntryModel::getProduct).collect(Collectors.toList());

    if (CollectionUtils.isEmpty(productModels)) {
      return false;
    }

    return productModels.stream().allMatch(ProductModel::getPreorderProduct);
  }
}
