package bt.batelco.core.order.hook;

import de.hybris.platform.commerceservices.order.hook.CommercePlaceOrderMethodHook;
import de.hybris.platform.commerceservices.service.data.CommerceCheckoutParameter;
import de.hybris.platform.commerceservices.service.data.CommerceOrderResult;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.ordersplitting.model.WarehouseModel;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;

import bt.batelco.core.category.BatelcoCategoryService;
import bt.batelco.core.stock.BatelcoStockService;
import bt.batelco.core.stock.exceptions.NotEnoughStockException;

public class BatelcoReserveOrderQuantityHook implements CommercePlaceOrderMethodHook {

    private static final Logger LOG = Logger.getLogger(BatelcoReserveOrderQuantityHook.class);

    private BatelcoStockService stockService;
    private BatelcoCategoryService categoryService;

    @Override
    public void afterPlaceOrder(CommerceCheckoutParameter parameter, CommerceOrderResult orderModel) throws InvalidCartException {

        // Nothing done here
    }

    @Override
    public void beforePlaceOrder(CommerceCheckoutParameter parameter) throws InvalidCartException {
        List<WarehouseModel> warehouseList= parameter.getCart().getStore().getWarehouses();
        reserveStockForEntries(parameter.getCart(),warehouseList);
    }

    @Override
    public void beforeSubmitOrder(CommerceCheckoutParameter parameter, CommerceOrderResult result) throws InvalidCartException {

        // Nothing done here
    }

    private void reserveStockForEntries(CartModel cartModel, List<WarehouseModel> warehouseModelList) throws InvalidCartException {
        List<AbstractOrderEntryModel> entryListWithStock=categoryService.getEntryListWithStock(cartModel);

        if (CollectionUtils.isEmpty(entryListWithStock)) {
            LOG.info(String.format("Order with code %s hasn't entries with stock.", cartModel.getCode()));
            return;
        }

        try {
            stockService.reserveStockForEntries(entryListWithStock,warehouseModelList);
        } catch (NotEnoughStockException exception) {
            LOG.warn("Not enough stock was found for order: " + cartModel.getCode());
            throw new InvalidCartException(exception.getMessage());
        }
    }

    @Required
    public void setStockService(BatelcoStockService stockService) {
        this.stockService = stockService;
    }

    @Required
    public void setCategoryService(BatelcoCategoryService categoryService) {
        this.categoryService = categoryService;
    }

}
