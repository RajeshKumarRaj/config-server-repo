package bt.batelco.core.order.hook;

import de.hybris.platform.commerceservices.enums.SalesApplication;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.promotions.model.PromotionResultModel;
import de.hybris.platform.subscriptionservices.subscription.impl.DefaultSubscriptionCommercePlaceOrderMethodHook;

import org.apache.commons.lang.BooleanUtils;

import java.util.Collections;
import java.util.Date;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Custom implementation of {@link DefaultSubscriptionCommercePlaceOrderMethodHook}
 */
public class BatelcoCommercePlaceOrderMethodHook extends DefaultSubscriptionCommercePlaceOrderMethodHook {

  @Override
  protected OrderModel createEnrichedOrderFromCart(final CartModel masterCart, final CartModel cartModel,
                                                   final SalesApplication salesApplication,
                                                   final OrderModel masterOrder) throws InvalidCartException {
    validateParameterNotNullStandardMessage("masterCart", masterCart);
    validateParameterNotNullStandardMessage("cartModel", cartModel);

    if (BooleanUtils.isFalse(cartModel.getCalculated())) {
      throw new IllegalArgumentException("Cart model '" + cartModel.getCode() + "' must be calculated");
    }

    final CustomerModel customer = (CustomerModel) masterCart.getUser();
    validateParameterNotNull(customer, "Customer model cannot be null");

    final OrderModel orderModel = getOrderService().createOrderFromCart(cartModel);
    if (orderModel == null) {
      return orderModel;
    }

    if (!customer.equals(orderModel.getUser())) {
      orderModel.setUser(customer);
    }

    orderModel.setSite(getBaseSiteService().getCurrentBaseSite());
    orderModel.setStore(getBaseStoreService().getCurrentBaseStore());
    orderModel.setLanguage(getCommonI18NService().getCurrentLanguage());

    if (masterCart.equals(cartModel)) {
      orderModel.setDate(new Date());
    }

    if (salesApplication != null) {
      orderModel.setSalesApplication(salesApplication);
    }

    orderModel.setCprId(customer.getCprId());
    getModelService().saveAll(customer, orderModel);

    orderModel.setAllPromotionResults(Collections.<PromotionResultModel>emptySet());
    setPaymentMode(masterOrder, orderModel);
    setPaymentInfo(cartModel, masterOrder, orderModel);
    setDeliveryInfo(masterCart, cartModel, orderModel);

    getModelService().save(orderModel);

    getPromotionsService().transferPromotionsToOrder(cartModel, orderModel, false);

    return orderModel;
  }


  protected void setPaymentMode(final OrderModel masterOrder, final OrderModel orderModel) {
    setPaymentModeFromMasterOrder(masterOrder, orderModel);
  }

  protected void setPaymentModeFromMasterOrder(final OrderModel masterOrder, final OrderModel orderModel) {
    if (masterOrder != null && masterOrder.getPaymentMode() != null) {
      orderModel.setPaymentMode(masterOrder.getPaymentMode());
      getModelService().save(orderModel.getPaymentMode());
    }
  }
}
