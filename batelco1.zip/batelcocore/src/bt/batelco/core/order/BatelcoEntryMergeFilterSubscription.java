package bt.batelco.core.order;

import de.hybris.platform.commerceservices.order.EntryMergeFilter;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;

import javax.annotation.Nonnull;

/**
 * Denies merging of entries with the different subscription term.
 */
public class BatelcoEntryMergeFilterSubscription implements EntryMergeFilter {

  @Override
  public Boolean apply(@Nonnull AbstractOrderEntryModel candidate, @Nonnull AbstractOrderEntryModel target) {
    return candidate.getSubscriptionInfo().getSubscriptionTerm()
        .equals(target.getSubscriptionInfo().getSubscriptionTerm());
  }
}
