package bt.batelco.core.order.entry;

import de.hybris.platform.commerceservices.order.EntryMergeFilter;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;

import javax.annotation.Nonnull;

/**
 * Custom implementation for {@link EntryMergeFilter} in order to replace the OOTB {@link de.hybris.platform.commerceservices.order.impl.EntryMergeFilterProduct}
 */
public class BatelcoEntryMergeFilterProduct implements EntryMergeFilter {

    /**
     * Merging strategy based on the added product will be disabled and for each product added to the cart a new entry will be created
     *
     * @param candidate merge candidate
     * @param target    entry to merge the candidate into
     * @return {@link Boolean#FALSE}
     */
    @Override
    public Boolean apply(@Nonnull AbstractOrderEntryModel candidate, @Nonnull AbstractOrderEntryModel target) {
        return Boolean.FALSE;
    }
}
