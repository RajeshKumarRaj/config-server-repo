package bt.batelco.core.hook.impl;


import de.hybris.platform.b2ctelcoservices.hook.impl.TmaPoAddToCartMethodHook;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaCartSubscriptionInfoModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.commerceservices.order.CommerceCartModification;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.service.data.CommerceCartParameter;
import de.hybris.platform.core.enums.GroupType;
import de.hybris.platform.core.model.ItemModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.order.EntryGroup;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.subscriptionservices.model.BillingTimeModel;
import de.hybris.platform.subscriptionservices.model.OneTimeChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.ObjectUtils;

import java.util.*;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;


/**
 * {@link TmaProductOfferingModel} specific add to cart operations.
 *
 * @since 6.7
 */
public class BatelcoAddToCartMethodHook extends TmaPoAddToCartMethodHook {
  private String defaultProcessType;


  /**
   * Perform validation operations for cart entries containing {@link TmaProductOfferingModel}.
   *
   * @param parameters A parameter object - new cart entry details
   * @throws CommerceCartModificationException in case the parent is not valid
   */
  @Override
  public void beforeAddToCart(final CommerceCartParameter parameters) throws CommerceCartModificationException {
    if (!(parameters.getProduct() instanceof TmaProductOfferingModel)) {
      return;
    }
    if (!ObjectUtils.isEmpty(parameters.getPointOfService()) && StringUtils.isEmpty(parameters.getProcessType())) {
      parameters.setProcessType(defaultProcessType);
    }
    if (StringUtils.isEmpty(parameters.getProcessType())) {
      throw new CommerceCartModificationException(
          "Process type cannot be empty for entry with product code " + parameters.getProduct().getCode());
    }

    if (StringUtils.isNotEmpty(parameters.getBpoCode())) {
      final TmaBundledProductOfferingModel parentBundledOffering = (TmaBundledProductOfferingModel) getTmaPoService()
          .getPoForCode(parameters.getBpoCode());
      if (!getTmaPoService().isValidParent((TmaProductOfferingModel) parameters.getProduct(), parentBundledOffering)) {
        throw new CommerceCartModificationException("Invalid BPO parent code:" + parameters.getBpoCode()
                                                    + " for entry with product code " + parameters.getProduct().getCode());
      }
    }
    final CartModel cartModel = parameters.getCart();
    final BillingTimeModel masterCartBillingTimeModel = getBillingTimeService()
        .getBillingTimeForCode(getSubscriptionCommerceCartService().getMasterCartBillingTimeCode());
    getSubscriptionCommerceCartService().checkMasterCart(cartModel, masterCartBillingTimeModel);

    if (!checkSoldIndividuallyFlag(parameters)) {
      throw new CommerceCartModificationException(
          "Product: " + parameters.getProduct().getCode() + ",cannot be sold individually ");
    }

    if (!verifyCartEntriesProcessType(parameters)) {
      throw new CommerceCartModificationException("Invalid process type: " + parameters.getProcessType()
                                                  + ",for entry with product code " + parameters.getProduct().getCode());
    }
  }


  /**
   * Verifies if the process type is the same for all cart entries from the same entry group.
   *
   * @param parameter details for the new cart entry, before to be added to cart
   * @return true is the process type is the one set for all cart entries from the group, false otherwise
   */
  private boolean verifyCartEntriesProcessType(final CommerceCartParameter parameter) {
    if (parameter.getEntryGroupNumbers() == null || parameter.getEntryGroupNumbers().isEmpty()) {
      return true;
    }
    final EntryGroup correspondingGroup = getEntryGroupService().getGroupOfType(parameter.getCart(),
                                                                                parameter.getEntryGroupNumbers(), GroupType.B2CTELCO_BPO);
    if (correspondingGroup == null) // NOSONAR
    {
      return true;
    }
    for (final AbstractOrderEntryModel cartEntry : parameter.getCart().getEntries()) {
      if (cartEntry.getEntryGroupNumbers() != null
          && cartEntry.getEntryGroupNumbers().contains(correspondingGroup.getGroupNumber())
          && cartEntry.getProcessType() != null && !cartEntry.getProcessType().getCode().equals(parameter.getProcessType())) {
        return false;
      }
    }
    return true;
  }


  private boolean checkSoldIndividuallyFlag(final CommerceCartParameter parameters) {
    final TmaProductOfferingModel productOfferingModel = (TmaProductOfferingModel) parameters.getProduct();
    return StringUtils.isBlank(parameters.getBpoCode()) ? productOfferingModel.getSoldIndividually() : true;
  }


  /**
   * Assigns the cart entry group to the new added cart entry.The cart entries group is created based on the bundle
   * product offering containing the new added offer. In case the cart entry has specified the cart entry group number,
   * then the group is retrieved from the cart, otherwise a new group is created. For any billing time other than the
   * one from the master billing time, it's created a new child cart having the entries with the same billing time. The
   * child carts are updated with the process type, bpo and the prices are recalculated as per the new parameters of
   * the child cart.
   *
   * @param parameter
   * 		details for the new cart entry, before to be added to cart
   * @param result
   * 		details for the new cart entry, after it was added to cart
   */
  @Override
  public void afterAddToCart(final CommerceCartParameter parameter, final CommerceCartModification result)
  {
    if (!(parameter.getProduct() instanceof TmaProductOfferingModel))
    {
      return;
    }
    if (result.getQuantityAdded() <= 0 || result.getEntry() == null)
    {
      return;
    }
    final AbstractOrderEntryModel orderEntry = result.getEntry();
    final AbstractOrderModel order = orderEntry.getOrder();

    if (!isMasterCart(order))
    {
      return;
    }

    if (orderEntry.getBpo() == null)
    {
      createChildCartsAndEntries(orderEntry, parameter);
      getModelService().save(orderEntry);
      getModelService().refresh(orderEntry);
      getCompatibilityPolicyEngine().verifyCompatibilityPoliciesForStandaloneProducts(order);
      return;
    }
    final EntryGroup rootEntryGroup = getEntryGroup(parameter, order);
    assignGroupNumberToEntry(orderEntry, rootEntryGroup.getGroupNumber());
    result.setEntryGroupNumbers(orderEntry.getEntryGroupNumbers());

    updateGroupEntriesSubscriptionDetails(order, rootEntryGroup, orderEntry.getSubscriptionInfo());
    getTmaCartHookHelper().invalidateBpoEntries((CartModel) order, rootEntryGroup);
    createChildCartsForEntryGroup((CartModel) order, rootEntryGroup);

    getModelService().save(orderEntry);
    getModelService().refresh(orderEntry);
    getEntryGroupService().forceOrderSaving(order);

    getCompatibilityPolicyEngine().verifyCompatibilityPolicies(order, rootEntryGroup);
  }

  private boolean isMasterCart(final AbstractOrderModel orderModel)
  {
    return orderModel != null && orderModel.getParent() == null;
  }

  private void updateGroupEntriesSubscriptionDetails(final AbstractOrderModel order, final EntryGroup entryGroup,
                                                     final TmaCartSubscriptionInfoModel subscriptionInfoModel)
  {
    if (subscriptionInfoModel == null || subscriptionInfoModel.getSubscriptionTerm() == null)
    {
      return;
    }
    for (final AbstractOrderEntryModel cartEntry : order.getEntries())
    {
      if (cartEntry.getEntryGroupNumbers() != null && cartEntry.getEntryGroupNumbers().contains(entryGroup.getGroupNumber())
          && cartEntry.getSubscriptionInfo() == null)
      {
        cartEntry.setSubscriptionInfo(subscriptionInfoModel);
        getModelService().save(cartEntry);
        getModelService().refresh(cartEntry);

        final CommerceCartParameter cartEntryParam = new CommerceCartParameter();
        order.setCalculated(false);
        cartEntryParam.setCart((CartModel) order);
        cartEntryParam.setCreateNewEntry(false);
        cartEntryParam.setProduct(cartEntry.getProduct());
        cartEntryParam.setQuantity(cartEntry.getQuantity());
        cartEntryParam.setUnit(cartEntry.getUnit());
        cartEntryParam.setEnableHooks(false);
        cartEntryParam.setProcessType(cartEntry.getProcessType().getCode());
        cartEntryParam.setBpoCode(cartEntry.getBpo().getCode());
        cartEntryParam.setSubscriptionInfo(cartEntry.getSubscriptionInfo());

        getCommerceCartCalculationStrategy().calculateCart(cartEntryParam);
      }
    }
  }

  private void createChildCartsForEntryGroup(final CartModel masterCartModel, final EntryGroup entryGroup)
  {
    masterCartModel.getEntries().stream().filter(cartEntry -> cartEntry.getEntryGroupNumbers() != null
                                                              && cartEntry.getEntryGroupNumbers().contains(entryGroup.getGroupNumber())).forEach(cartEntry ->
                                                                                                                                                 {
                                                                                                                                                   final CommerceCartParameter cartEntryParameter = new CommerceCartParameter();
                                                                                                                                                   cartEntryParameter.setProduct(cartEntry.getProduct());
                                                                                                                                                   cartEntryParameter.setQuantity(cartEntry.getQuantity());
                                                                                                                                                   cartEntryParameter.setUnit(cartEntry.getUnit());
                                                                                                                                                   cartEntryParameter.setEnableHooks(true);
                                                                                                                                                   cartEntryParameter.setCart(getCartService().getSessionCart());
                                                                                                                                                   createChildCartsAndEntries(cartEntry, cartEntryParameter);
                                                                                                                                                 });
  }

  private void createChildCartsAndEntries(final AbstractOrderEntryModel masterCartEntry,
                                          final CommerceCartParameter masterCartParameter)
  {
    final CartModel masterCartModel = (CartModel) masterCartEntry.getOrder();
    final BillingTimeModel masterCartBillingTimeModel = getBillingTimeService()
        .getBillingTimeForCode(getSubscriptionCommerceCartService().getMasterCartBillingTimeCode());

    for (final BillingTimeModel billingTime : getBillingFrequenciesForMasterEntry(masterCartEntry))
    {
      if (!masterCartBillingTimeModel.equals(billingTime) && Boolean.TRUE.equals(billingTime.getCartAware()))
      {
        CartModel childCart = getSubscriptionCommerceCartService().getChildCartForBillingTime(masterCartModel, billingTime);
        if (childCart == null)
        {
          childCart = getSubscriptionCommerceCartService().createChildCartForBillingTime(masterCartModel, billingTime);
        }

        CartEntryModel childCartEntry = getCartEntryForProduct(childCart, masterCartEntry);
        if (childCartEntry == null)
        {
          childCartEntry = getCartService().addNewEntry(childCart, masterCartParameter.getProduct(),
                                                        masterCartParameter.getQuantity(), masterCartParameter.getUnit(), -1, false);
          childCartEntry.setMasterEntry(masterCartEntry);
          childCartEntry.setBpo(masterCartEntry.getBpo());
          childCartEntry.setProcessType(masterCartEntry.getProcessType());
          childCartEntry.setSubscriptionInfo(masterCartEntry.getSubscriptionInfo());
          childCartEntry.setEntryGroupNumbers(masterCartEntry.getEntryGroupNumbers());
          getModelService().save(childCartEntry);
        }


        final CommerceCartParameter childCartParameters = createChildEntryCommerceCartParameter(masterCartParameter,
                                                                                                childCart);
        getCommerceCartCalculationStrategy().calculateCart(childCartParameters);
      }
    }
  }

  private CartEntryModel getCartEntryForProduct(final CartModel cartModel, AbstractOrderEntryModel masterCartEntry)
  {
    if (CollectionUtils.isNotEmpty(cartModel.getEntries()))
    {
      final Optional<AbstractOrderEntryModel> cartEntryForProduct = cartModel.getEntries().stream()
          .filter(cartEntry -> masterCartEntry.getProduct().getCode().equalsIgnoreCase(cartEntry.getProduct().getCode()))
          .filter(cartEntry -> cartEntry.getEntryGroupNumbers().containsAll(masterCartEntry.getEntryGroupNumbers()))
          .filter(cartEntry -> masterCartEntry.getSubscriptionInfo().getSubscriptionTerm().equals(cartEntry.getSubscriptionInfo().getSubscriptionTerm()))
          .findFirst();

      if (cartEntryForProduct.isPresent())
      {
        return (CartEntryModel) cartEntryForProduct.get();
      }
    }
    return null;
  }

  private List<BillingTimeModel> getBillingFrequenciesForMasterEntry(final AbstractOrderEntryModel masterCartEntry)
  {
    final List<BillingTimeModel> billingTimeModels = new ArrayList<>();
    final TmaCartSubscriptionInfoModel subscriptionInfoModel = masterCartEntry.getSubscriptionInfo();
    if (subscriptionInfoModel == null)
    {
      return Collections.emptyList();
    }
    final SubscriptionTermModel subscriptionTermModel = subscriptionInfoModel.getSubscriptionTerm();
    if (subscriptionTermModel == null)
    {
      return Collections.emptyList();
    }
    billingTimeModels.add(subscriptionTermModel.getBillingPlan().getBillingFrequency());

    final PriceRowModel minimumPrice = getCommercePriceService().getMinimumPrice(masterCartEntry);
    if (minimumPrice != null && minimumPrice instanceof SubscriptionPricePlanModel)
    {
      final Collection<OneTimeChargeEntryModel> oneTimeChargeEntries = ((SubscriptionPricePlanModel) minimumPrice)
          .getOneTimeChargeEntries();
      if (CollectionUtils.isNotEmpty(oneTimeChargeEntries))
      {
        billingTimeModels.addAll(
            oneTimeChargeEntries.stream().map(OneTimeChargeEntryModel::getBillingEvent).collect(Collectors.toList()));
      }
    }
    return billingTimeModels;
  }

  private CommerceCartParameter createChildEntryCommerceCartParameter(final CommerceCartParameter masterCartParameters,
                                                                      final CartModel childCart)
  {
    final CommerceCartParameter childCartParameters = new CommerceCartParameter();
    childCartParameters.setCart(childCart);
    childCartParameters.setCreateNewEntry(masterCartParameters.isCreateNewEntry());
    childCartParameters.setProduct(masterCartParameters.getProduct());
    childCartParameters.setQuantity(masterCartParameters.getQuantity());
    childCartParameters.setUnit(masterCartParameters.getUnit());
    childCartParameters.setEnableHooks(false);
    childCartParameters.setProcessType(masterCartParameters.getProcessType());
    childCartParameters.setBpoCode(masterCartParameters.getBpoCode());
    childCartParameters.setAutomaticallyAdded(masterCartParameters.isAutomaticallyAdded());
    childCartParameters.setSubscriptionInfo(masterCartParameters.getSubscriptionInfo());
    return childCartParameters;
  }

  private void assignGroupNumberToEntry(final AbstractOrderEntryModel entry, final int entryGroupNumber)
  {
    final Set<Integer> numbers = new HashSet<>();
    if (entry.getEntryGroupNumbers() != null)
    {
      numbers.addAll(entry.getEntryGroupNumbers());
    }
    numbers.add(entryGroupNumber);
    entry.setEntryGroupNumbers(numbers);
  }

  /**
   * Retrieves a cart entry group to be associate to the new added cart entry. If an entry group number is provided,
   * then the group is retrieved from the existing cart groups, otherwise a new one si created.
   *
   * @param parameter
   * 		cart entry details
   * @param order
   * 		current order
   * @return the corresponding entry group
   */
  private EntryGroup getEntryGroup(final CommerceCartParameter parameter, final AbstractOrderModel order)
  {
    final TmaBundledProductOfferingModel rootBpo = (TmaBundledProductOfferingModel) getTmaPoService()
        .getPoForCode(parameter.getBpoCode());

    final EntryGroup rootEntryGroup = createEntryGroupStructure(rootBpo);
    rootEntryGroup.setProcessType(parameter.getProcessType());
    if (!parameter.getEntryGroupNumbers().isEmpty())
    {
      final EntryGroup correspondingCartGroup = getCorrespondingGroup(rootEntryGroup, order, parameter.getEntryGroupNumbers());

      if (correspondingCartGroup != null)
      {
        invalidateBpoEntries(parameter.getCart(), correspondingCartGroup.getGroupNumber());
        return correspondingCartGroup;
      }
    }
    assignGroupNumbers(rootEntryGroup, parameter.getCart());

    final List<EntryGroup> orderGroups = new ArrayList<>(order.getEntryGroups());
    orderGroups.add(rootEntryGroup);
    order.setEntryGroups(orderGroups);
    getEntryGroupService().forceOrderSaving(order);
    return rootEntryGroup;
  }

  /**
   * Marks all cart entries that belong to the same bpo as "not calculated", as the prices within a bpo may vary
   * depending on the product offerings bought as part of the same bpo and a re-calculation of the whole bpo entries
   * (and all carts that contain entries of the affected bundle) is necessary.
   *
   * @param cart
   * 		the cart to recalculate entries in.
   * @param entryGroupNumber
   * 		entry group number to retrieve the entries which need to be recalculated
   */
  protected void invalidateBpoEntries(@Nonnull final CartModel cart, final int entryGroupNumber)
  {
    final EntryGroup rootEntryGroup = getEntryGroupService().getRoot(cart, entryGroupNumber);
    final List<Integer> treeGroupIds = getEntryGroupService().getNestedGroups(rootEntryGroup).stream()
        .filter(group -> GroupType.B2CTELCO_BPO.equals(group.getGroupType())).map(EntryGroup::getGroupNumber)
        .collect(Collectors.toList());
    final Set<ItemModel> models = new HashSet<>();
    cart.getEntries().stream().filter(cartEntry -> cartEntry.getEntryGroupNumbers() != null
                                                   && CollectionUtils.containsAny(treeGroupIds, cartEntry.getEntryGroupNumbers())).forEach(cartEntry ->
                                                                                                                                           {
                                                                                                                                             cartEntry.setCalculated(Boolean.FALSE);
                                                                                                                                             cartEntry.getOrder().setCalculated(Boolean.FALSE);
                                                                                                                                             models.add(cartEntry);
                                                                                                                                             models.add(cartEntry.getOrder());
                                                                                                                                           });
    getModelService().saveAll(models);
  }

  private EntryGroup getCorrespondingGroup(final EntryGroup entryGroup, final AbstractOrderModel orderModel,
                                           final Set<Integer> groupNumbers)
  {
    final EntryGroup group = getEntryGroupService().getGroupOfType(orderModel, groupNumbers, GroupType.B2CTELCO_BPO);
    if (StringUtils.equals(group.getExternalReferenceId(), entryGroup.getExternalReferenceId())
        && group.getProcessType().equals(entryGroup.getProcessType()))
    {
      return group;
    }
    return null;
  }

  private void assignGroupNumbers(final EntryGroup group, final CartModel cart)
  {
    group.setGroupNumber(getEntryGroupService().findMaxGroupNumber(cart.getEntryGroups()) + 1);
  }

  private EntryGroup createEntryGroupStructure(final TmaBundledProductOfferingModel bpo)
  {
    final EntryGroup entryGroup = new EntryGroup();
    entryGroup.setErroneous(Boolean.FALSE);
    entryGroup.setExternalReferenceId(bpo.getCode());
    entryGroup.setGroupType(GroupType.B2CTELCO_BPO);
    entryGroup.setLabel(bpo.getName());
    entryGroup.setChildren(new ArrayList<>());
    return entryGroup;
  }

  private boolean isEntryWithoutSubscription(AbstractOrderEntryModel masterCartEntry) {
    return masterCartEntry.getSubscriptionInfo() == null;
  }

  @Required
  public void setDefaultProcessType(final String defaultProcessType) {
    this.defaultProcessType = defaultProcessType;
  }

}
