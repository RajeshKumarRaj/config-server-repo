package bt.batelco.core.interceptors.price;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.catalog.enums.ArticleApprovalStatus;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.subscriptionservices.model.RecurringChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.apache.commons.lang.BooleanUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.price.service.BatelcoCommercePriceService;

/**
 * Intercepts price value change, recalculates default (the one with minimum price) variant per base product
 */
public class RecurringPriceChangeInterceptor implements PrepareInterceptor<RecurringChargeEntryModel> {

  private static final Logger LOGGER = Logger.getLogger(RecurringPriceChangeInterceptor.class);
  private static final String CATALOG_SYNC_ACTIVE = "catalog.sync.active";
  private BatelcoCommercePriceService commercePriceService;
  private SessionService sessionService;

  @Override
  public void onPrepare(RecurringChargeEntryModel charge, InterceptorContext context) {
    Boolean catalogSyncActive = sessionService.getCurrentSession().getAttribute(CATALOG_SYNC_ACTIVE);
    if (BooleanUtils.isTrue(catalogSyncActive)) {
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Skip interceptor due to sync in progress " + catalogSyncActive);
      }
      return;
    }

    SubscriptionPricePlanModel priceRow = charge.getSubscriptionPricePlanRecurring();
    if (priceRow != null && isVariantApproved(priceRow) && isContextModified(charge, context)
        && getCommercePriceService().getBaseProduct(priceRow) != null) {
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Starting reset default variant for price row " + priceRow.getPk());
      }
      getCommercePriceService().resetDefaultVariant(priceRow, charge.getPrice());
    }
  }

  private boolean isVariantApproved(SubscriptionPricePlanModel priceRow) {
    return priceRow.getProduct() != null && priceRow.getProduct() instanceof TmaPoVariantModel
           && ArticleApprovalStatus.APPROVED.equals(priceRow.getProduct().getApprovalStatus());
  }


  private boolean isContextModified(RecurringChargeEntryModel charge, InterceptorContext context) {
    return context.isNew(charge) || context.isModified(charge, SubscriptionPricePlanModel.PRICE);
  }

  protected BatelcoCommercePriceService getCommercePriceService() {
    return commercePriceService;
  }

  @Required
  public void setCommercePriceService(BatelcoCommercePriceService commercePriceService) {
    this.commercePriceService = commercePriceService;
  }

  @Required
  public void setSessionService(SessionService sessionService) {
    this.sessionService = sessionService;
  }
}
