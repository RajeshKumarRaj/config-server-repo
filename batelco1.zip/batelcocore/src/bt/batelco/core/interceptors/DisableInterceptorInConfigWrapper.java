package bt.batelco.core.interceptors;

import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

public class DisableInterceptorInConfigWrapper<MODEL> implements PrepareInterceptor<MODEL> {

    private static final Logger LOGGER = Logger.getLogger(DisableInterceptorInConfigWrapper.class);
    private ConfigurationService configurationService;
    private PrepareInterceptor<MODEL> wrappedInterceptor;

    @Override
    public void onPrepare(MODEL model, InterceptorContext context) throws InterceptorException {
        boolean disableInterceptor = getConfigurationService().getConfiguration().getBoolean("batelco.interceptor.disable", false);
        if (disableInterceptor) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Skip interceptor because it was disabled.");
            }
            return;
        }

        getWrappedInterceptor().onPrepare(model, context);
    }

    public PrepareInterceptor<MODEL> getWrappedInterceptor() {
        return wrappedInterceptor;
    }

    @Required
    public void setWrappedInterceptor(PrepareInterceptor<MODEL> wrappedInterceptor) {
        this.wrappedInterceptor = wrappedInterceptor;
    }

    @Required
    public void setConfigurationService(ConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    public ConfigurationService getConfigurationService() {
        return configurationService;
    }

}
