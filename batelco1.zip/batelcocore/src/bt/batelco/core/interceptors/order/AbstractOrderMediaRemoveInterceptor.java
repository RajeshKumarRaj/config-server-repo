package bt.batelco.core.interceptors.order;

import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.RemoveInterceptor;
import de.hybris.platform.servicelayer.model.ModelService;

import org.springframework.beans.factory.annotation.Required;

/**
 * Deletes media associated to order before order removal.
 */
public class AbstractOrderMediaRemoveInterceptor implements RemoveInterceptor<AbstractOrderModel> {

  private ModelService modelService;

  @Override
  public void onRemove(AbstractOrderModel order, InterceptorContext ctx) {
    removeCprFront(order);
    removeCprBack(order);
    removeAcquisitionForms(order);
    removePaymentEvidence(order);
  }

  private void removeCprFront(AbstractOrderModel order) {
    if (order.getCprFront() != null) {
      getModelService().remove(order.getCprFront());
    }
  }

  private void removeCprBack(AbstractOrderModel order) {
    if (order.getCprBack() != null) {
      getModelService().remove(order.getCprBack());
    }
  }

  private void removeAcquisitionForms(AbstractOrderModel order) {
    order.getEntries().stream().filter(entry -> entry.getAcquisitionForm() != null)
        .forEach(entry -> getModelService().remove(entry.getAcquisitionForm()));
  }

  private void removePaymentEvidence(AbstractOrderModel order) {
    if (order.getPaymentEvidence() != null) {
      getModelService().remove(order.getPaymentEvidence());
    }
  }

  protected ModelService getModelService() {
    return modelService;
  }

  @Required
  public void setModelService(ModelService modelService) {
    this.modelService = modelService;
  }
}
