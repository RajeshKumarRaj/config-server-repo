package bt.batelco.core.interceptors.order;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.processengine.BusinessProcessService;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import de.hybris.platform.servicelayer.model.ItemModelContext;
import de.hybris.platform.servicelayer.model.ModelContextUtils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;
import java.util.Map;

import bt.batelco.core.event.OrderStatusChangedEvent;

import static de.hybris.platform.core.enums.OrderStatus.PREORDER_COMPLETED;

public class OrderStatusPrepareInterceptor extends AbstractOrderInterceptor {

    private static final Logger LOG = Logger.getLogger(OrderStatusPrepareInterceptor.class);

    private BusinessProcessService businessProcessService;
    private EventService eventService;

    @Override
    public void onPrepare(OrderModel orderModel, InterceptorContext interceptorContext) throws InterceptorException {
        if (!isOrderStatusValidForIntercepting(orderModel)) {
            return;
        }
        super.onPrepare(orderModel,interceptorContext);

        OrderStatus newStatus = orderModel.getStatus();
        if (OrderStatus.COMPLETED == newStatus || OrderStatus.CANCELLED == newStatus || PREORDER_COMPLETED == newStatus) {
            triggerOrderFulfilmentProcessCompletedEvent(orderModel);
            return;
        }

          triggerOrderStatusChangedEvent(orderModel);
    }

    private void triggerOrderStatusChangedEvent(OrderModel orderModel) {
        LOG.info(String.format("Triggering OrderStatusChangedEvent for order %s and with status %s .",orderModel.getCode(),orderModel.getStatus().getCode()));
        getEventService().publishEvent(new OrderStatusChangedEvent(orderModel));
    }

    private void triggerOrderFulfilmentProcessCompletedEvent(OrderModel orderModel) {
        String eventName = orderModel.getCode() +"_FulfilmentProcessCompletedEvent";
        LOG.info("Triggering event: " + eventName);
        getBusinessProcessService().triggerEvent(eventName);
    }


    public EventService getEventService() {
        return eventService;
    }

    @Required
    public void setEventService(EventService eventService) {
        this.eventService = eventService;
    }

    public BusinessProcessService getBusinessProcessService() {
        return businessProcessService;
    }

    @Required
    public void setBusinessProcessService(BusinessProcessService businessProcessService) {
        this.businessProcessService = businessProcessService;
    }

}
