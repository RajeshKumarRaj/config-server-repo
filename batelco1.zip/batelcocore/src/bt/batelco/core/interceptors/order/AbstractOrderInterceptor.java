package bt.batelco.core.interceptors.order;

import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import de.hybris.platform.servicelayer.model.ItemModelContext;
import de.hybris.platform.servicelayer.model.ModelContextUtils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;
import java.util.Map;

import static de.hybris.platform.core.enums.OrderStatus.PREORDER_COMPLETED;

public abstract class AbstractOrderInterceptor implements PrepareInterceptor<OrderModel> {

    private static final Logger LOG = Logger.getLogger(AbstractOrderInterceptor.class);

    private Map<OrderStatus, List<OrderStatus>> validationOrderForOrderStatuses;

    @Override
    public void onPrepare(OrderModel orderModel, InterceptorContext interceptorContext) throws InterceptorException {

        if (!isOrderStatusValidForIntercepting(orderModel)) {
            return;
        }
        validateStatus(getOldStatusValue(ModelContextUtils.getItemModelContext(orderModel)), orderModel.getStatus(), orderModel.getPreorder());
    }

    protected boolean isOrderStatusValidForIntercepting(OrderModel orderModel) {

        ItemModelContext itemModelContext = ModelContextUtils.getItemModelContext(orderModel);
        if (!itemModelContext.isLoaded(OrderModel.STATUS)) {
            return false;
        }
        OrderStatus oldStatus = getOldStatusValue(itemModelContext);
        OrderStatus newStatus = orderModel.getStatus();
        if (newStatus == null || newStatus == oldStatus || OrderStatus.PROCESSING_ERROR == newStatus) {
            return false;
        }

        return true;
    }

    private OrderStatus getOldStatusValue(ItemModelContext itemModelContext) {
        return itemModelContext.getOriginalValue(OrderModel.STATUS);
    }

    private void validateStatus(OrderStatus oldStatus, OrderStatus newStatus, Boolean preorder) throws InterceptorException {
        if (!isStatusConfiguredForFulfilmentProcess(newStatus)) {
            throw new InterceptorException(newStatus.toString() + " is not configured for fulfilment process");
        }

        if (!isStatusAllowedToBeChanged(oldStatus, newStatus)) {
            throw new InterceptorException("Your are not allowed to change the order status from " + oldStatus.toString() + " to " + newStatus.toString());
        }

        if (PREORDER_COMPLETED.equals(newStatus) && Boolean.TRUE != preorder) {
            throw new InterceptorException("Your are not allowed to change the order status to " + newStatus.toString() + " because your order doesn't contain pre order products!");
        }
    }

    private boolean isStatusAllowedToBeChanged(OrderStatus oldStatus, OrderStatus newStatus) {
        List<OrderStatus> validStatusList = getValidationOrderForOrderStatuses().get(oldStatus);
        return validStatusList.contains(newStatus);
    }

    private boolean isStatusConfiguredForFulfilmentProcess(OrderStatus newStatus) {
        return getValidationOrderForOrderStatuses().keySet().stream().anyMatch(status -> status == newStatus);
    }


    public Map<OrderStatus, List<OrderStatus>> getValidationOrderForOrderStatuses() {
        return validationOrderForOrderStatuses;
    }

    @Required
    public void setValidationOrderForOrderStatuses(Map<OrderStatus, List<OrderStatus>> validationOrderForOrderStatuses) {
        this.validationOrderForOrderStatuses = validationOrderForOrderStatuses;
    }
}
