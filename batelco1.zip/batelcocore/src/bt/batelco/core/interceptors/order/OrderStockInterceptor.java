package bt.batelco.core.interceptors.order;

import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.commerceservices.impersonation.ImpersonationContext;
import de.hybris.platform.commerceservices.impersonation.ImpersonationService;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.ordersplitting.model.WarehouseModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import de.hybris.platform.servicelayer.model.ItemModelContext;
import de.hybris.platform.servicelayer.model.ModelContextUtils;
import de.hybris.platform.servicelayer.model.ModelService;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import bt.batelco.core.category.BatelcoCategoryService;
import bt.batelco.core.stock.BatelcoStockService;
import bt.batelco.core.stock.exceptions.NotEnoughStockException;

/**
 * Order interceptor that triggers the reducing stock flow for order entries with stock.
 */
public class OrderStockInterceptor extends AbstractOrderInterceptor{
    private static final Logger LOG = Logger.getLogger(OrderStockInterceptor.class);

    private BatelcoStockService stockService;
    private BatelcoCategoryService categoryService;
    private ImpersonationService impersonationService;
    private ModelService modelService;

    @Override
    public void onPrepare(OrderModel orderModel, InterceptorContext interceptorContext) throws InterceptorException {

        if (!isOrderStatusValidForIntercepting(orderModel)) {
            return;
        }
        super.onPrepare(orderModel,interceptorContext);

        OrderStatus newStatus = orderModel.getStatus();
        List<OrderStatus> orderStatusesThatChangeStock = new ArrayList<>(Arrays.asList(OrderStatus.COMPLETED, OrderStatus.PREORDER_COMPLETED, OrderStatus.CANCELLED));
        if (!orderStatusesThatChangeStock.contains(newStatus)) {
            return;
        }

        List<AbstractOrderEntryModel> entryListWithStock;
        final ImpersonationContext context = createImpersonationContext(orderModel);
        entryListWithStock = impersonationService.executeInContext(context, () -> categoryService.getEntryListWithStock(orderModel));

        if (CollectionUtils.isEmpty(entryListWithStock)) {
            LOG.info(String.format("Order with code %s hasn't entries with stock.", orderModel.getCode()));
            return;
        }

        List<WarehouseModel> warehouseModelList = orderModel.getStore().getWarehouses();


        if (OrderStatus.CANCELLED == newStatus) {
            releaseStockForEntries(entryListWithStock, warehouseModelList);
        }

        if (OrderStatus.COMPLETED == newStatus || OrderStatus.PREORDER_COMPLETED == newStatus) {
            reduceStockForEntries(orderModel, entryListWithStock, warehouseModelList);
            clearOrderStatusInfoIfExist(orderModel);
        }

    }

    private void releaseStockForEntries(List<AbstractOrderEntryModel> entryListWithStock, List<WarehouseModel> warehouseModelList) {
        stockService.releaseStockForEntries(entryListWithStock, warehouseModelList);
    }


    private void reduceStockForEntries(OrderModel orderModel, List<AbstractOrderEntryModel> entryListWithStock, List<WarehouseModel> warehouseModelList) throws InterceptorException {
        try {
            stockService.reduceStockForEntries(entryListWithStock, warehouseModelList);
        } catch (NotEnoughStockException exception) {
            LOG.warn("Not enough stock was found for order: " + orderModel.getCode());
            updateOrder(orderModel, exception);
            throw new InterceptorException(exception.getMessage());
        }
    }

    private ImpersonationContext createImpersonationContext(OrderModel orderModel) {
        final ImpersonationContext context = new ImpersonationContext();
        context.setSite(orderModel.getSite());
        context.setCurrency(orderModel.getCurrency());
        context.setLanguage(orderModel.getLanguage());
        context.setCatalogVersions(getCatalogVersion(orderModel));
        return context;
    }

    private Collection<CatalogVersionModel> getCatalogVersion(OrderModel order) {
        List<CatalogVersionModel> catalogVersions = new ArrayList<>();
        order.getEntries().stream().findFirst().ifPresent(entry -> catalogVersions.add(entry.getProduct().getCatalogVersion()));
        return catalogVersions;
    }

    private void updateOrder(OrderModel orderModel, NotEnoughStockException exception) {
        orderModel.setStatus(OrderStatus.PROCESSING_ERROR);
        orderModel.setStatusInfo(exception.getMessage());
        modelService.save(orderModel);
    }

    private void clearOrderStatusInfoIfExist(OrderModel orderModel) {
        if (StringUtils.isEmpty(orderModel.getStatusInfo())) {
            return;
        }
        orderModel.setStatusInfo(StringUtils.EMPTY);
        modelService.save(orderModel);
    }

    @Required
    public void setModelService(ModelService modelService) {
        this.modelService = modelService;
    }

    @Required
    public void setStockService(BatelcoStockService stockService) {
        this.stockService = stockService;
    }

    @Required
    public void setCategoryService(BatelcoCategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @Required
    public void setImpersonationService(ImpersonationService impersonationService) {
        this.impersonationService = impersonationService;
    }
}
