package bt.batelco.core.media.strategy;

import com.google.common.base.Preconditions;
import de.hybris.platform.media.MediaSource;
import de.hybris.platform.media.storage.MediaStorageConfigService;
import de.hybris.platform.media.url.MediaURLStrategy;
import de.hybris.platform.util.MediaUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.apache.log4j.Logger;

/**
 * This class over rides OOB media URL generation, this custom URL generation is specific to Media of Facebook Product feed.
 */
public class FacebookFeedMediaUrlStrategy implements MediaURLStrategy {

    private static final Logger LOG = Logger.getLogger(FacebookFeedMediaUrlStrategy.class);
    public static final String ATTACHEMENT_PARAM = "attachment";
    private static final String URL_SEPARATOR = "/";
    private static final String AMPERSAND = "&";
    private static final String BATELCO_FEEDS = "batelcofeeds";

    /**
     * This method over rides OOB media URL generation, this custom URL generation is specific to Media of Facebook Product feed. Rest of the media uses OOB logic.
     * @param mediaFolderConfig
     *          MediaFolderConfig
     * @param mediaSource
     *          MediaSource
     * @return
     *      returns URL as String
     */
    @Override
    public String getUrlForMedia(MediaStorageConfigService.MediaFolderConfig mediaFolderConfig, MediaSource mediaSource) {
        Preconditions.checkArgument(mediaFolderConfig != null, "Folder config is required to perform this operation");
        Preconditions.checkArgument(mediaSource != null, "MediaSource is required to perform this operation");
        return this.assembleUrl(mediaFolderConfig.getFolderQualifier(), mediaSource);
    }

    /**
     * Method for generating URL
     * @param folderQualifier
     *              folderQualifier
     * @param mediaSource
     *          MediaSource
     * @return
     */
    private String assembleUrl(String folderQualifier, MediaSource mediaSource) {
        String url = "";
        if (!GenericValidator.isBlankOrNull(folderQualifier) && !GenericValidator.isBlankOrNull(mediaSource.getLocation())) {
            url =  this.assembleURLWithOutMediaContext(folderQualifier, mediaSource);
        }
        LOG.debug(url);
        return url;
    }

    /**
     * Method takes care of generating URL with out MediaContext
     * @param folderQualifier
     *              folderQualifier
     * @param mediaSource
     *          MediaSource
     * @return
     */
    private String assembleURLWithOutMediaContext(String folderQualifier, MediaSource mediaSource) {
        StringBuilder builder = new StringBuilder(URL_SEPARATOR);
        builder.append(BATELCO_FEEDS);
        builder.append(URL_SEPARATOR);
        String realFilename = this.getRealFileNameForMedia(mediaSource);
        if (realFilename != null) {
            builder.append(realFilename);
        }
        builder.append("?mediaPK="+mediaSource.getMediaPk());
        return builder.toString();
    }

    /**
     * Method returns the real file name of the Media
     * @param mediaSource
     *              MediaSource
     * @return
     *      returns RealFileName of the Media
     */
    private String getRealFileNameForMedia(MediaSource mediaSource) {
        String realFileName = mediaSource.getRealFileName();
        return StringUtils.isNotBlank(realFileName) ? MediaUtil.normalizeRealFileName(realFileName) : null;
    }

    /**
     * Returns the download URL of the Media
     * @param config
     *          MediaSource
     * @param mediaSource
     *          MediaSource
     * @return
     *       returns download URL of the Media as String
     */
    public String getDownloadUrlForMedia(MediaStorageConfigService.MediaFolderConfig config, MediaSource mediaSource) {
        StringBuilder url = new StringBuilder(this.getUrlForMedia(config, mediaSource));
        url.append(AMPERSAND);
        url.append(ATTACHEMENT_PARAM).append("=").append(Boolean.TRUE.toString());
        LOG.debug(url.toString());
        return url.toString();
    }

}
