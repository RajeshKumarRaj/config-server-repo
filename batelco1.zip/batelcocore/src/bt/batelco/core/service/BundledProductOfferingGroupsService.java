package bt.batelco.core.service;

import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;

import java.util.Set;

/**
 * Services that handles the products group split for bpo.
 */
public interface BundledProductOfferingGroupsService {

  /**
   * Identifies the devices if any from the bundled product offering and returns them.
   * It only checks the current bpo, it ignores the children bpos.
   *
   * @param bpo the bundled product offering.
   * @return devices
   */
  Set<TmaProductOfferingModel> getDevices(TmaBundledProductOfferingModel bpo);

  /**
   * Identifies the plans if any from the bundled product offering and returns them.
   * It only checks the current bpo, it ignores the children bpos.
   *
   * @param bpo the bundled product offering.
   * @return plan
   */
  Set<TmaProductOfferingModel> getPlans(TmaBundledProductOfferingModel bpo);

  /**
   * Identifies the boltons if any from the bundled product offering and returns them.
   * It only checks the current bpo, it ignores the children bpos.
   *
   * @param bpo the bundled product offering.
   * @return boltons
   */
  Set<TmaProductOfferingModel> getBoltons(TmaBundledProductOfferingModel bpo);

}