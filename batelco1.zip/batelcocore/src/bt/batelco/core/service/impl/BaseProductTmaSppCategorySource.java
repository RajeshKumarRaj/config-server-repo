package bt.batelco.core.service.impl;

import com.google.common.collect.ImmutableList;

import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.TmaSpoSource;
import de.hybris.platform.b2ctelcoservices.compatibility.eligibility.solr.indexing.TmaSppCategorySource;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.solrfacetsearch.config.IndexConfig;
import de.hybris.platform.solrfacetsearch.config.IndexedProperty;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Gets a set of categories from all the variants of that product.
 * Is useful if some variant's have different categories. (for category variants for example)
 */
public class BaseProductTmaSppCategorySource extends TmaSppCategorySource {

  private TmaSpoSource spoSource;

  @Override
  public Collection<CategoryModel> getCategoriesForConfigAndProperty(IndexConfig cfg, IndexedProperty prop, Object model) {
    Set<ProductModel> products = new HashSet<>();
    ProductModel productModel = getProducts(model).iterator().next();

    if (productModel instanceof TmaPoVariantModel) {
      productModel = ((TmaPoVariantModel) productModel).getTmaBasePo();
    }
    if (productModel instanceof TmaSimpleProductOfferingModel && CollectionUtils.isNotEmpty(((TmaSimpleProductOfferingModel) productModel).getTmaPoVariants())) {
      products.addAll(((TmaSimpleProductOfferingModel) productModel).getTmaPoVariants());
    } else {
      products.add(productModel);
    }

    Set<CategoryModel> directCategories = getDirectSuperCategories(products);
    if (directCategories == null || directCategories.isEmpty()) {
      return Collections.emptyList();
    }
    Collection<CatalogVersionModel> catalogVersions = ImmutableList.of(getCatalogVersion(model));
    Set<CategoryModel> allCategories = new HashSet<>();
    directCategories.stream()
        .map(category -> getAllCategories(category, lookupRootCategories(catalogVersions)))
        .forEach(allCategories::addAll);
    return allCategories;
  }

  protected CatalogVersionModel getCatalogVersion(Object model) {
    return ((PriceRowModel) model).getCatalogVersion();
  }

  @Override
  protected Set<ProductModel> getProducts(Object model) {
    return Collections.singleton(spoSource.getProduct((PriceRowModel) model));
  }

  public TmaSpoSource getSpoSource() {
    return spoSource;
  }

  public void setSpoSource(TmaSpoSource spoSource) {
    this.spoSource = spoSource;
  }
}
