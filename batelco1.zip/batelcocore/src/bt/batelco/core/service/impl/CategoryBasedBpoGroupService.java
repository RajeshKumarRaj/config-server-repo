package bt.batelco.core.service.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.commerceservices.category.CommerceCategoryService;

import org.springframework.beans.factory.annotation.Required;

import java.util.Set;
import java.util.stream.Collectors;

import bt.batelco.core.category.BatelcoCategoryService;
import bt.batelco.core.service.BundledProductOfferingGroupsService;

/**
 * Identifies products in a group based on the super categories.
 */
public class CategoryBasedBpoGroupService implements BundledProductOfferingGroupsService {

  private CommerceCategoryService commerceCategoryService;
  private BatelcoCategoryService categoryService;

  @Override
  public Set<TmaProductOfferingModel> getDevices(TmaBundledProductOfferingModel bpo) {
    return getProductsForGroupPosition(bpo, getCategoryService().getDevicesCategoryCode());
  }

  @Override
  public Set<TmaProductOfferingModel> getPlans(TmaBundledProductOfferingModel bpo) {
    return getProductsForGroupPosition(bpo, getCategoryService().getPlansCategoryCode());
  }

  @Override
  public Set<TmaProductOfferingModel> getBoltons(TmaBundledProductOfferingModel bpo) {
    return getProductsForGroupPosition(bpo, getCategoryService().getAddonsCategoryCode());
  }

  private Set<TmaProductOfferingModel> getProductsForGroupPosition(TmaBundledProductOfferingModel bpo,
                                                                   String category) {
    CategoryModel categoryModel = getCommerceCategoryService().getCategoryForCode(category);
    return bpo.getProductOfferingGroups().stream()
        .flatMap(group -> group.getChildProductOfferings().stream())
        .filter(product -> product.getSupercategories().contains(categoryModel) ||
                           product.getSupercategories().stream()
                               .flatMap(superCategory -> superCategory.getAllSupercategories().stream())
                               .anyMatch(superCategory -> superCategory.equals(categoryModel)))
        .collect(Collectors.toSet());
  }

  protected CommerceCategoryService getCommerceCategoryService() {
    return commerceCategoryService;
  }

  @Required
  public void setCommerceCategoryService(CommerceCategoryService commerceCategoryService) {
    this.commerceCategoryService = commerceCategoryService;
  }

  protected BatelcoCategoryService getCategoryService() {
    return categoryService;
  }

  @Required
  public void setCategoryService(BatelcoCategoryService categoryService) {
    this.categoryService = categoryService;
  }
}
