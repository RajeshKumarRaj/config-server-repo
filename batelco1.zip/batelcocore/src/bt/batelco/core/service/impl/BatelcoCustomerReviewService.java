package bt.batelco.core.service.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.customerreview.impl.DefaultCustomerReviewService;
import de.hybris.platform.customerreview.model.CustomerReviewModel;

import java.util.List;

public class BatelcoCustomerReviewService extends DefaultCustomerReviewService {

  @Override
  public CustomerReviewModel createCustomerReview(Double rating, String headline, String comment, UserModel user, ProductModel product) {
    return super.createCustomerReview(rating, headline, comment, user, getBaseProduct(product));
  }

  /** @deprecated  */
  @Deprecated
  @Override
  public void updateCustomerReview(CustomerReviewModel model, UserModel user, ProductModel product) {
    super.updateCustomerReview(model, user, getBaseProduct(product));
  }

  @Override
  public Double getAverageRating(ProductModel product) {
    return super.getAverageRating(getBaseProduct(product));
  }

  @Override
  public Integer getNumberOfReviews(ProductModel product) {
    return super.getNumberOfReviews(getBaseProduct(product));
  }

  @Override
  public List<CustomerReviewModel> getReviewsForProduct(ProductModel product) {
    return super.getReviewsForProduct(getBaseProduct(product));
  }

  @Override
  public List<CustomerReviewModel> getReviewsForProductAndLanguage(ProductModel product, LanguageModel language) {
    return super.getReviewsForProductAndLanguage(getBaseProduct(product), language);
  }

  private ProductModel getBaseProduct(ProductModel product) {
    if (product instanceof TmaPoVariantModel) {
      return ((TmaPoVariantModel) product).getTmaBasePo();
    }
    return product;
  }

}
