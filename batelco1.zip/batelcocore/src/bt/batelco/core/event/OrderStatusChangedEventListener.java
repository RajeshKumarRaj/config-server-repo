/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.core.event;

import com.iquest.dynamiclocalization.exceptions.DynamicLocalizationServiceException;
import com.iquest.dynamiclocalization.services.localization.DynamicLocalizationService;

import de.hybris.platform.acceleratorservices.site.AbstractAcceleratorSiteEventListener;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commerceservices.enums.SiteChannel;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.processengine.BusinessProcessService;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import org.apache.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.model.processes.OrderStatusChangedProcessModel;


/**
 * Listener for order status changed events.
 */
public class OrderStatusChangedEventListener extends AbstractAcceleratorSiteEventListener<OrderStatusChangedEvent> {

    private ModelService modelService;
    private BusinessProcessService businessProcessService;
    private DynamicLocalizationService dynamicLocalizationService;
    private I18NService i18NService;
    private static final String ORDER_STATUS_CHANGED_MESSAGE_KEY_PREFIX = "order.status.changed.";
    private static final Logger LOG = Logger.getLogger(OrderStatusChangedEventListener.class);

    protected BusinessProcessService getBusinessProcessService() {
        return businessProcessService;
    }

    @Required
    public void setBusinessProcessService(final BusinessProcessService businessProcessService) {
        this.businessProcessService = businessProcessService;
    }

    protected ModelService getModelService() {
        return modelService;
    }

    @Required
    public void setModelService(final ModelService modelService) {
        this.modelService = modelService;
    }

    @Override
    protected void onSiteEvent(final OrderStatusChangedEvent orderStatusChangedEvent) {
        final OrderModel orderModel = orderStatusChangedEvent.getOrder();
        final OrderStatusChangedProcessModel orderProcessModel = getBusinessProcessService().createProcess(
                "orderStatusChangedProcess-" + orderModel.getCode() + "-" + System.currentTimeMillis(),
                "orderStatusChangedProcess");
        orderProcessModel.setOrder(orderModel);
        orderProcessModel.setMessageToCustomer(getMessageForCustomer(orderModel));
        getModelService().save(orderProcessModel);
        getBusinessProcessService().startProcess(orderProcessModel);
    }

    private String getMessageForCustomer(OrderModel order) {
        String messageKey = ORDER_STATUS_CHANGED_MESSAGE_KEY_PREFIX + order.getStatus().toString().toLowerCase();
        try {
            return getDynamicLocalizationService().getLocalizedMessage(messageKey, i18NService.getCurrentLocale());
        } catch (DynamicLocalizationServiceException e) {
            LOG.warn("No dynamic localization found for key: " + messageKey);
        }
        return Strings.EMPTY;
    }

    @Override
    protected SiteChannel getSiteChannelForEvent(final OrderStatusChangedEvent event) {
        final OrderModel order = event.getOrder();
        ServicesUtil.validateParameterNotNullStandardMessage("event.order", order);
        final BaseSiteModel site = order.getSite();
        ServicesUtil.validateParameterNotNullStandardMessage("event.order.site", site);
        return site.getChannel();
    }

    public DynamicLocalizationService getDynamicLocalizationService() {
        return dynamicLocalizationService;
    }

    @Required
    public void setDynamicLocalizationService(DynamicLocalizationService dynamicLocalizationService) {
        this.dynamicLocalizationService = dynamicLocalizationService;
    }

    public I18NService getI18NService() {
        return i18NService;
    }

    @Required
    public void setI18NService(I18NService i18NService) {
        this.i18NService = i18NService;
    }
}
