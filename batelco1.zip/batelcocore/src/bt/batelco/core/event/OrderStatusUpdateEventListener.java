/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.core.event;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.model.processes.OrderStatusChangedProcessModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.processengine.BusinessProcessService;
import de.hybris.platform.servicelayer.event.impl.AbstractEventListener;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;


/**
 * Listener for order status changed events.
 */
public class OrderStatusUpdateEventListener extends AbstractEventListener<OrderStatusUpdateEvent> {
	private ModelService modelService;
	private BusinessProcessService businessProcessService;
	private I18NService i18NService;


	public I18NService getI18NService() {
		return i18NService;
	}

	public void setI18NService(I18NService i18nService) {
		i18NService = i18nService;
	}

	protected BusinessProcessService getBusinessProcessService()
	{
		return businessProcessService;
	}

	@Required
	public void setBusinessProcessService(final BusinessProcessService businessProcessService)
	{
		this.businessProcessService = businessProcessService;
	}

	/**
	 * @return the modelService
	 */
	protected ModelService getModelService()
	{
		return modelService;
	}
	
	/**
	 * @param modelService
	 *           the modelService to set
	 */
	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	@Override
	protected void onEvent(OrderStatusUpdateEvent orderStatusUpdateEvent) {
		// TODO Auto-generated method stub
		 final OrderModel orderModel = orderStatusUpdateEvent.getOrder();
	        final OrderProcessModel orderProcessModel = getBusinessProcessService().createProcess(
	                "userOrderUpdateNotificationEmailProcess-" + orderModel.getCode() + "-" + System.currentTimeMillis(),
	                "userOrderUpdateNotificationEmailProcess");
	        orderProcessModel.setOrder(orderModel);
	        //orderProcessModel.setMessageToCustomer(getMessageForCustomer(orderModel));
	        getModelService().save(orderProcessModel);
	        getBusinessProcessService().startProcess(orderProcessModel);
	}

	

  
}
