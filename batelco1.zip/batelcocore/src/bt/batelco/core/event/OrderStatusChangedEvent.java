package bt.batelco.core.event;

import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.event.events.AbstractEvent;

public class OrderStatusChangedEvent extends AbstractEvent {

    private OrderModel order;

    public OrderStatusChangedEvent(OrderModel order) {
        this.order=order;
    }

    public OrderModel getOrder() {
        return order;
    }

    public void setOrder(OrderModel order) {
        this.order = order;
    }
}
