package bt.batelco.core.phonenumber.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.cmsfacades.data.MediaData;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.phonenumber.PhoneNumberService;

public class DefaultPhoneNumberService implements PhoneNumberService {

  private static final String PHONE_COUNTRY_PREFIX = "phonenumber.countryPrefix";

  private ConfigProviderService configProviderService;

  private String countryPrefix;

  /**
   * Retrieves country prefix from configurations
   *
   * @return Phone country prefix
   */
  public String getCountryPrefix() {
    if (countryPrefix == null) {
      countryPrefix = this.configProviderService.<String>get(PHONE_COUNTRY_PREFIX)
          .conversion(source -> source).convert();
    }

    return countryPrefix;
  }

  /**
   * Prepends country prefix to given phone number
   *
   * @param phoneNumber
   * @return Phone number with prefix
   */
  public String prependPrefix(final String phoneNumber) {
    return getCountryPrefix() + phoneNumber;
  }

  @Required
  public void setConfigProviderService(final ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }

}
