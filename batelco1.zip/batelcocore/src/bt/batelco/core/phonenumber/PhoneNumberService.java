package bt.batelco.core.phonenumber;

/**
 * Phone number service
 */
public interface PhoneNumberService {
  /**
   * @return Country Prefix
   */
  String getCountryPrefix();

  /**
   * Prepends country prefix to given phone number
   *
   * @param phoneNumber
   * @return phoneNumber with prepended prefix
   */
  String prependPrefix(String phoneNumber);
}
