package bt.batelco.core.customer.dao.impl;

import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collections;
import java.util.List;

import bt.batelco.core.customer.dao.BatelcoCustomerDao;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

public class DefaultBatelcoCustomerDao extends DefaultGenericDao<CustomerModel> implements BatelcoCustomerDao {

  public DefaultBatelcoCustomerDao() {
    super(CustomerModel._TYPECODE);
  }

  @Override
  public CustomerModel findCustomerModelByCustomerId(String customerId) {
    validateParameterNotNull(customerId, "CustomerId must not be null!");

    List<CustomerModel> customerModels = find(Collections.singletonMap(CustomerModel.CUSTOMERID, customerId));

    if (CollectionUtils.isEmpty(customerModels)) {
      throw new IllegalArgumentException("Could not find result");
    }
    return customerModels.get(0);
  }

@Override
public CustomerModel findCustomerModelByAccountNumber(String accountNumber) {
	 validateParameterNotNull(accountNumber, "CustomerId must not be null!");
	 
	 List<CustomerModel> customerModels = find(Collections.singletonMap(CustomerModel.ACCOUNTNUMBER, accountNumber));
	 
	 if (CollectionUtils.isEmpty(customerModels)) {
	      throw new IllegalArgumentException("Could not find result");
	    }
	    return customerModels.get(0);
}
  
  
  
  
  
}
