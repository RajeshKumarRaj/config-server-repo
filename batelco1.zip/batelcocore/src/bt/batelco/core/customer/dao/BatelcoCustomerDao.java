package bt.batelco.core.customer.dao;

import de.hybris.platform.core.model.user.CustomerModel;

/**
 * Customer DAO
 */
public interface BatelcoCustomerDao {

  /**
   * Search for customer by its customerId.
   *
   * @param customerId customer id
   * @return result of search
   * @throws IllegalArgumentException if code is null
   */
  CustomerModel findCustomerModelByCustomerId(String customerId);
  
  CustomerModel findCustomerModelByAccountNumber(String accountNumber);
}
