package bt.batelco.core.customer.service.impl;

import de.hybris.platform.commerceservices.customer.impl.DefaultCustomerEmailResolutionService;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.util.mail.MailUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.mail.EmailException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Custom implementation to avoid log files info messages that are thrown every time when a anonymous user is accessing
 * the website because of inappropriate email format.
 */
public class DefaultBatelcoCustomerEmailResolutionService extends DefaultCustomerEmailResolutionService {

  private UserService userService;

  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoCustomerEmailResolutionService.class);

  @Override
  protected String validateAndProcessEmailForCustomer(final CustomerModel customerModel) {
    validateParameterNotNullStandardMessage("customerModel", customerModel);

    if (userService.isAnonymousUser(customerModel)) {
      return StringUtils.EMPTY;
    }

    try {
      final String email = customerModel.getUid();
      MailUtils.validateEmailAddress(email, "customer email");
      return email;
    } catch (final EmailException e) {
      LOG.warn("Given email is not appropriate for customer uid [{}].", customerModel.getUid());
    }

    return StringUtils.EMPTY;
  }

  @Required
  public void setUserService(UserService userService) {
    this.userService = userService;
  }
}
