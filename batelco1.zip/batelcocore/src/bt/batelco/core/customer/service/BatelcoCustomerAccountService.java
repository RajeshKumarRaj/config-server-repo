package bt.batelco.core.customer.service;

import de.hybris.platform.commerceservices.customer.CustomerAccountService;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.payment.dto.BillingInfo;

/**
 * Handles customer account management capabilities
 */
public interface BatelcoCustomerAccountService extends CustomerAccountService {

  /**
   * Find customer
   *
   * @param customerId customer Id
   */
  CustomerModel findCustomerModelByCustomerId(String customerId);

  /**
   * Creates a payment info for the given customer based on payment type selected.
   *
   * @param customerModel the customer model to add a new invoice payment info.
   * @param billingInfo   contains the billing address fields.
   * @return The created payment info the holding billing address details
   */
  PaymentInfoModel createPaymentInfoForCustomer(CustomerModel customerModel,
                                                BillingInfo billingInfo);

  /**
   * Updates the current user with the given parameters
   *
   * @param customerModel the customer to update
   * @throws DuplicateUidException if the email is not unique
   */
  void updateProfile(CustomerModel customerModel) throws DuplicateUidException;
  
  
  
  CustomerModel findCustomerModelByAccountNumber(String accountNumber);

  
}
