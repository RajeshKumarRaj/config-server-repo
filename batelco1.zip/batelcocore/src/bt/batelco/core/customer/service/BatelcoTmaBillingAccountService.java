package bt.batelco.core.customer.service;

import de.hybris.platform.b2ctelcoservices.services.TmaBillingAccountService;
import de.hybris.platform.core.model.user.CustomerModel;

import java.util.Set;

import bt.batelco.core.model.BatelcoBillingProfileModel;

/**
 * Customer interface class used to manage customer billing accounts.
 */
public interface BatelcoTmaBillingAccountService extends TmaBillingAccountService {

  /**
   * Returns available billing profile configured for customer.
   *
   * @param customer the customer model
   * @return the list of {@link BatelcoBillingProfileModel} configured for a customer
   */
  Set<BatelcoBillingProfileModel> getBillingProfilesForCustomer(final CustomerModel customer);
}
