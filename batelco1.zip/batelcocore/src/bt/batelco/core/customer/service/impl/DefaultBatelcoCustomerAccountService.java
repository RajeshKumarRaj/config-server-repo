package bt.batelco.core.customer.service.impl;

import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.commerceservices.customer.TokenInvalidatedException;
import de.hybris.platform.commerceservices.customer.impl.DefaultCustomerAccountService;
import de.hybris.platform.commerceservices.event.UpdatedProfileEvent;
import de.hybris.platform.commerceservices.security.SecureToken;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.order.payment.InvoicePaymentInfoModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.payment.dto.BillingInfo;
import de.hybris.platform.store.BaseStoreModel;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.UUID;

import bt.batelco.core.constants.BatelcoCoreConstants;
import bt.batelco.core.customer.dao.BatelcoCustomerDao;
import bt.batelco.core.customer.service.BatelcoCustomerAccountService;
import bt.batelco.core.order.BatelcoOrderService;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Default implementation of {@link BatelcoCustomerAccountService}
 */
public class DefaultBatelcoCustomerAccountService extends DefaultCustomerAccountService
    implements BatelcoCustomerAccountService {

  private BatelcoCustomerDao batelcoCustomerDao;
  private BatelcoOrderService orderService;

  @Override
  public CustomerModel findCustomerModelByCustomerId(String customerId) {
    return batelcoCustomerDao.findCustomerModelByCustomerId(customerId);
  }

  @Override
  public PaymentInfoModel createPaymentInfoForCustomer(CustomerModel customerModel, BillingInfo billingInfo) {
    PaymentInfoModel paymentInfo = getModelService().create(InvoicePaymentInfoModel.class);
    paymentInfo.setCode(customerModel.getUid() + "-" + UUID.randomUUID());
    paymentInfo.setUser(customerModel);
    paymentInfo.setSaved(true);

    final AddressModel billingAddress = createBillingAddress(customerModel, billingInfo);
    billingAddress.setOwner(paymentInfo);
    paymentInfo.setBillingAddress(billingAddress);

    getModelService().saveAll(billingAddress, paymentInfo);
    getModelService().refresh(customerModel);

    addPaymentInfo(customerModel, paymentInfo);

    return paymentInfo;
  }

  @Override
  public OrderModel getOrderDetailsForGUID(String guid, BaseStoreModel store) {
    OrderModel order = super.getOrderDetailsForGUID(guid, store);
    getOrderService().updateStatusIfOnlinePaymentExpired(order);
    return order;
  }

  @Override
  public OrderModel getOrderForCode(final CustomerModel customerModel, final String code, final BaseStoreModel store) {
    OrderModel order = super.getOrderForCode(code, store);
    getOrderService().updateStatusIfOnlinePaymentExpired(order);
    return order;
  }


  private AddressModel createBillingAddress(CustomerModel customerModel, BillingInfo billingInfo) {
    final AddressModel billingAddress = getModelService().create(AddressModel.class);
    billingAddress.setFirstname(billingInfo.getFirstName());
    billingAddress.setLastname(billingInfo.getLastName());
    billingAddress.setLine1(billingInfo.getStreet1());
    billingAddress.setLine2(billingInfo.getStreet2());
    billingAddress.setTown(billingInfo.getCity());
    billingAddress.setPostalcode(billingInfo.getPostalCode());
    billingAddress.setCountry(getCommonI18NService().getCountry(billingInfo.getCountry()));
    if (billingInfo.getRegion() != null) {
      billingAddress.setRegion(getCommonI18NService().getRegion(billingAddress.getCountry(), billingInfo.getRegion()));
    }
    billingAddress.setPhone1(billingInfo.getPhoneNumber());
    final String email = getCustomerEmailResolutionService().getEmailForCustomer(customerModel);
    billingAddress.setEmail(email);
    return billingAddress;
  }

  @Override
  public void updatePassword(final String token, final String newPassword) throws TokenInvalidatedException {
    Assert.hasText(token, "The field [token] cannot be empty");
    Assert.hasText(newPassword, "The field [newPassword] cannot be empty");

    final SecureToken data = getSecureTokenService().decryptData(token);
    if (getTokenValiditySeconds() > 0L) {
      final long delta = new Date().getTime() - data.getTimeStamp();
      if (delta / 1000 > getTokenValiditySeconds()) {
        throw new IllegalArgumentException("token expired");
      }
    }

    final CustomerModel customer = getUserService().getUserForUID(data.getData(), CustomerModel.class);
    if (customer == null) {
      throw new IllegalArgumentException("user for token not found");
    }
    if (!token.equals(customer.getToken())) {
      throw new TokenInvalidatedException();
    }
    customer.setToken(null);
    getModelService().save(customer);

    getUserService().setPassword(data.getData(), newPassword, getPasswordEncoding());
  }


  @Override
  public void updateProfile(CustomerModel customerModel) throws DuplicateUidException {
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.CUSTOMER_MODEL_PARAM, customerModel);

    internalSaveCustomer(customerModel);
    getEventService().publishEvent(initializeEvent(new UpdatedProfileEvent(), customerModel));
  }

  @Required
  public void setBatelcoCustomerDao(BatelcoCustomerDao batelcoCustomerDao) {
    this.batelcoCustomerDao = batelcoCustomerDao;
  }

  @Required
  public void setOrderService(BatelcoOrderService orderService) {
    this.orderService = orderService;
  }

  public BatelcoOrderService getOrderService() {
    return orderService;
  }

@Override
public CustomerModel findCustomerModelByAccountNumber(String accountNumber) {
	 return batelcoCustomerDao.findCustomerModelByAccountNumber(accountNumber);
}
}
