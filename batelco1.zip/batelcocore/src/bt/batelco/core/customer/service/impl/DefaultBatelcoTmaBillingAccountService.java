package bt.batelco.core.customer.service.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaBillingAccountModel;
import de.hybris.platform.b2ctelcoservices.services.impl.DefaultTmaBillingAccountService;
import de.hybris.platform.core.model.user.CustomerModel;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

import bt.batelco.core.constants.BatelcoCoreConstants;
import bt.batelco.core.customer.service.BatelcoTmaBillingAccountService;
import bt.batelco.core.model.BatelcoBillingProfileModel;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

public class DefaultBatelcoTmaBillingAccountService extends DefaultTmaBillingAccountService
    implements BatelcoTmaBillingAccountService {

  @Override
  public Set<BatelcoBillingProfileModel> getBillingProfilesForCustomer(final CustomerModel customer) {
    validateParameterNotNullStandardMessage(BatelcoCoreConstants.CUSTOMER_MODEL_PARAM, customer);

    final Set<TmaBillingAccountModel> billingAccounts = customer.getBillingAccounts();
    if (CollectionUtils.isEmpty(billingAccounts)) {
      return Collections.emptySet();
    }

    return billingAccounts.stream()
        .filter(billingAccount -> CollectionUtils.isNotEmpty(billingAccount.getBillingProfiles()))
        .flatMap(billingAccount -> billingAccount.getBillingProfiles().stream())
        .collect(Collectors.toSet());
  }
}
