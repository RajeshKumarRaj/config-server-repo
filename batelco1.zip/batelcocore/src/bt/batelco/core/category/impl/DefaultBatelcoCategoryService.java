package bt.batelco.core.category.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.b2ctelcoservices.services.impl.DefaultTmaCategoryService;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import bt.batelco.core.category.BatelcoCategoryService;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;

public class DefaultBatelcoCategoryService extends DefaultTmaCategoryService implements BatelcoCategoryService {

    private static final String CONFIG_KEY_FOR_CONFIGURED_STOCK_CATEGORY_LIST = "products.stock.categories";
    private static final String CONFIGURED_STOCK_CATEGORY_LIST_SEPARATOR = ",";
    private static final String DEVICES_DEFAULT = "devices";
    private static final String DEVICES_KEY = "category.devices";
    private static final String PLANS_DEFAULT = "plans";
    private static final String PLANS_KEY = "category.plans";
    private static final String ADDONS_DEFAULT = "addons";
    private static final String ADDONS_KEY = "category.addons";

    private ConfigProviderService configProviderService;
    private ConfigurationService configurationService;


    @Override
    public List<AbstractOrderEntryModel> getEntryListWithStock(AbstractOrderModel abstractOrderModel) {
        List<AbstractOrderEntryModel> entriesWithStock = new ArrayList<>();
        List<String> configuredListWithStockCategory = getConfiguredStockCategoryList();

        for (AbstractOrderEntryModel entry : abstractOrderModel.getEntries()) {
            List<String> allCategoryCodesFromProduct = getAllCategoryCodes(entry.getProduct());
            if (!Collections.disjoint(configuredListWithStockCategory, allCategoryCodesFromProduct)) {
                entriesWithStock.add(entry);
            }
        }

        return entriesWithStock;
    }

    @Override
    public String getDevicesCategoryCode() {
        return getConfig(DEVICES_KEY, DEVICES_DEFAULT);
    }

    @Override
    public String getPlansCategoryCode() {
        return getConfig(PLANS_KEY, PLANS_DEFAULT);
    }

    @Override
    public String getAddonsCategoryCode() {
        return getConfig(ADDONS_KEY, ADDONS_DEFAULT);
    }

    private String getConfig(String key, String defaultValue) {
        return getConfigProviderService().<String>get(key)
            .conversion(value -> value)
            .validateThat(StringUtils::isNotEmpty)
            .onInvalid(useDefault(defaultValue))
            .onMissing(useDefault(defaultValue))
            .convert();
    }

    private List<String> getConfiguredStockCategoryList() {
        String configuredCategoryList = configurationService.getConfiguration().getString(CONFIG_KEY_FOR_CONFIGURED_STOCK_CATEGORY_LIST);
        return Arrays.asList(configuredCategoryList.split(CONFIGURED_STOCK_CATEGORY_LIST_SEPARATOR));
    }

    private List<String> getAllCategoryCodes(ProductModel product) {
        Collection<CategoryModel> superCategories = product.getSupercategories();
        List<String> allCategoriesCodes = new ArrayList<>(convertToCategoryCodesList(superCategories));
        superCategories.forEach(categoryModel -> allCategoriesCodes.addAll(convertToCategoryCodesList(getAllSupercategoriesForCategory(categoryModel))));
        return allCategoriesCodes;
    }

    private List<String> convertToCategoryCodesList(Collection<CategoryModel> categoryModels) {
        return categoryModels.stream().map(CategoryModel::getCode).collect(Collectors.toList());
    }

    protected ConfigurationService getConfigurationService() {
        return configurationService;
    }

    @Required
    public void setConfigurationService(ConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    protected ConfigProviderService getConfigProviderService() {
        return configProviderService;
    }

    @Required
    public void setConfigProviderService(ConfigProviderService configProviderService) {
        this.configProviderService = configProviderService;
    }
}
