package bt.batelco.core.category;

import de.hybris.platform.category.CategoryService;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;

import java.util.List;

public interface BatelcoCategoryService extends CategoryService {

    List<AbstractOrderEntryModel> getEntryListWithStock(AbstractOrderModel abstractOrderModel);

    String getDevicesCategoryCode();

    String getPlansCategoryCode();

    String getAddonsCategoryCode();
}
