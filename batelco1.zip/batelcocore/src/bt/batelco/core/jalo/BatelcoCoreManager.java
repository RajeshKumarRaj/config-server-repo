package bt.batelco.core.jalo;

import bt.batelco.core.constants.BatelcoCoreConstants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.extension.ExtensionManager;
import org.apache.log4j.Logger;

@SuppressWarnings("PMD")
public class BatelcoCoreManager extends GeneratedBatelcoCoreManager
{
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger( BatelcoCoreManager.class.getName() );
	
	public static final BatelcoCoreManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (BatelcoCoreManager) em.getExtension(BatelcoCoreConstants.EXTENSIONNAME);
	}
	
}
