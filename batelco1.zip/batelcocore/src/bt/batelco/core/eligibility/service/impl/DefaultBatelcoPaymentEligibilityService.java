package bt.batelco.core.eligibility.service.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.b2ctelcoservices.model.TmaBillingAccountModel;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.Set;

import bt.batelco.core.customer.service.BatelcoTmaBillingAccountService;
import bt.batelco.core.eligibility.service.BatelcoPaymentEligibilityService;
import bt.batelco.core.order.BatelcoOrderService;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;
import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

/**
 * Default implementation of BatelcoPaymentEligibilityService
 */
public class DefaultBatelcoPaymentEligibilityService implements BatelcoPaymentEligibilityService {

  private static final String ENABLE_ELIGIBILITY_CHECK_DEF = "true";
  private static final String ENABLE_ELIGIBILITY_CHECK_CONFIG = "online.payment.enable.eligibility.check";
  private static final String MIN_PAYABLE_AMOUNT_CONFIG = "online.payment.min.payable.amount";
  private static final BigDecimal MIN_PAYABLE_AMOUNT_DEF = BigDecimal.ZERO;
  private static final String MIN_PAYABLE_AMOUNT_DEC_SEP_CONFIG =
      "online.payment.min.payable.amount.decimal.separator";
  private static final String MIN_PAYABLE_AMOUNT_DEC_SEP_DEF = ".";
  private static final String MIN_PAYABLE_AMOUNT_GROUP_SEP_CONFIG =
      "online.payment.min.payable.amount.group.separator";
  private static final String MIN_PAYABLE_AMOUNT_GROUP_SEP_DEF = ",";

  private static final String CUSTOMER_FIELD = "customer";
  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoPaymentEligibilityService.class);
  private static final int INDEX = 0;

  private BatelcoTmaBillingAccountService tmaBillingAccountService;
  private ConfigProviderService configService;
  private BatelcoOrderService orderService;

  @Override
  public boolean isEligibleForCheckoutOnlinePayment(final CustomerModel customer) {
    Assert.notNull(customer, "The field [" + CUSTOMER_FIELD + "] cannot be null.");

    final boolean eligibilityCheckEnabled = configService.<Boolean>get(ENABLE_ELIGIBILITY_CHECK_CONFIG)
        .conversion(Boolean::valueOf)
        .onMissing(useDefault(ENABLE_ELIGIBILITY_CHECK_DEF)).convert();

    LOG.info("Eligibility check for online payment {} ", eligibilityCheckEnabled);
    if (!eligibilityCheckEnabled) {
      return true;
    }

    final boolean isEligible = Strings.isNotEmpty(customer.getCustomerID()) &&
                               isBillingAccountConfiguredForCustomer(customer) &&
                               isNotEmpty(getTmaBillingAccountService().getBillingProfilesForCustomer(customer));
    LOG.info("For customer {} eligibility for online payment is {}", customer.getUid(), isEligible);

    return isEligible;

  }

  @Override
  public boolean canOrderBePaidOnline(OrderData orderData) {
    validateParameterNotNullStandardMessage("orderData", orderData);
    final StandardPaymentModeModel selectedPaymentMode = (StandardPaymentModeModel) orderData.getPaymentMode();

    if (selectedPaymentMode == null || CollectionUtils.isEmpty(selectedPaymentMode.getChildren())) {
      return false;
    }

    final boolean onlinePaymentSelected = selectedPaymentMode.getOnline();
    final boolean statusIsAllowed = orderService.getStatusesForExpiryCheck().contains(orderData.getStatus());
    return onlinePaymentSelected && statusIsAllowed;
  }

  @Override
  public BigDecimal getMinPayableAmount() {
    final String minimumAmountConfig = getConfig(MIN_PAYABLE_AMOUNT_CONFIG, MIN_PAYABLE_AMOUNT_DEF.toString());
    BigDecimal minPayableAmount = MIN_PAYABLE_AMOUNT_DEF;

    try {
      minPayableAmount = (BigDecimal) getConfiguredDecimalFormat().parse(minimumAmountConfig);
    } catch (ParseException e) {
      LOG.info("Error parsing the configured minimum payable amount {}, fallback to {}", minimumAmountConfig,
               MIN_PAYABLE_AMOUNT_DEF);
    }

    return minPayableAmount;
  }

  private DecimalFormat getConfiguredDecimalFormat() {
    final String decimalSeparator = getConfig(MIN_PAYABLE_AMOUNT_DEC_SEP_CONFIG, MIN_PAYABLE_AMOUNT_DEC_SEP_DEF);
    final String groupSeparator = getConfig(MIN_PAYABLE_AMOUNT_GROUP_SEP_CONFIG, MIN_PAYABLE_AMOUNT_GROUP_SEP_DEF);

    final DecimalFormatSymbols symbols = new DecimalFormatSymbols();
    symbols.setGroupingSeparator(groupSeparator.charAt(INDEX));
    symbols.setDecimalSeparator(decimalSeparator.charAt(INDEX));

    final String pattern = "#" + groupSeparator + "##0" + decimalSeparator + "0#";
    final DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
    decimalFormat.setParseBigDecimal(true);

    return decimalFormat;
  }

  @Override
  public boolean isTotalAmountPayEligible(OrderData orderData) {
    final BigDecimal totalOnlinePay = orderData.getOnlineTotalPay() == null ?
                                      MIN_PAYABLE_AMOUNT_DEF : orderData.getOnlineTotalPay().getValue();
    return getMinPayableAmount().compareTo(totalOnlinePay) <= 0;
  }

  private String getConfig(String configKey, String defaultValue) {
    return configService.<String>get(configKey).conversion(s -> s)
        .onMissing(useDefault(defaultValue)).convert();
  }

  private boolean isBillingAccountConfiguredForCustomer(final CustomerModel customer) {
    Assert.notNull(customer, "The field [" + CUSTOMER_FIELD + "] cannot be null.");

    final Set<TmaBillingAccountModel> customerAccounts = customer.getBillingAccounts();
    return isNotEmpty(customerAccounts) && Strings.isNotEmpty(customerAccounts.iterator().next()
                                                                  .getBillingAccountId());
  }

  public BatelcoTmaBillingAccountService getTmaBillingAccountService() {
    return tmaBillingAccountService;
  }

  @Required
  public void setTmaBillingAccountService(final BatelcoTmaBillingAccountService tmaBillingAccountService) {
    this.tmaBillingAccountService = tmaBillingAccountService;
  }

  public ConfigProviderService getConfigService() {
    return configService;
  }

  @Required
  public void setConfigService(ConfigProviderService configService) {
    this.configService = configService;
  }

  @Required
  public void setOrderService(BatelcoOrderService orderService) {
    this.orderService = orderService;
  }

  public BatelcoOrderService getOrderService() {
    return orderService;
  }
}
