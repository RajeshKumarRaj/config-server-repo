package bt.batelco.core.eligibility.service;

import de.hybris.platform.b2ctelcoservices.model.TmaBillingAccountModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSubscriptionBaseModel;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.core.model.user.CustomerModel;

import java.math.BigDecimal;

import bt.batelco.core.model.BatelcoBillingProfileModel;

/**
 * Interface class for managing Batelco payment eligibility rules.
 */
public interface BatelcoPaymentEligibilityService {

  /**
   * Checks if target customer is eligible or not for online payment action. A customer is eligible for online payment
   * action only if it has a customer ID configured and at least one {@link TmaBillingAccountModel} created that
   * contains at least one {@link TmaSubscriptionBaseModel} that has a {@link BatelcoBillingProfileModel} configured.
   *
   * @param customer the customer model
   * @return returns true if customer is eligible for online payment, otherwise false
   */
  boolean isEligibleForCheckoutOnlinePayment(final CustomerModel customer);

  /**
   * Checks if an order can be paid online. An order can be paid online if selected payment mode has online enabled and
   * if order status is allowed for online payment.
   *
   * @param orderData the order
   * @return returns true if the order can be paid online, otherwise false
   */
  boolean canOrderBePaidOnline(OrderData orderData);

  /**
   * Gets the configured minimum payable amount
   *
   * @return amount
   */
  BigDecimal getMinPayableAmount();

  /**
   * Checks if the total pay online amount is greater than the minimum payable amount
   *
   * @param orderData the order
   * @return true/false
   */
  boolean isTotalAmountPayEligible(OrderData orderData);
}
