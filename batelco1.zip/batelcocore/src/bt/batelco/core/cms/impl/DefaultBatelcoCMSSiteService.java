package bt.batelco.core.cms.impl;

import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.impl.DefaultCMSSiteService;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Collection;

import bt.batelco.core.cms.BatelcoCMSSiteService;
import org.apache.commons.lang.StringUtils;

public class DefaultBatelcoCMSSiteService extends DefaultCMSSiteService implements BatelcoCMSSiteService {

  private static final String NODE_IPS = "cluster.node.ips";
  private static final String CLUSTER_NODE_IP_DELIMITER = ",";
  private ConfigurationService configurationService;

  @Override
  public void updateUrlPatterns(String siteUid) {
    CMSSiteModel site = (CMSSiteModel) getBaseSiteService().getBaseSiteForUID(siteUid);
    Collection<String> urlPatterns = new ArrayList<>(createPatternsForClusterNodeIps());
    urlPatterns.addAll(site.getUrlPatterns());
    site.setUrlPatterns(urlPatterns);
    getModelService().save(site);
  }

  private Collection<String> createPatternsForClusterNodeIps() {
    Collection<String> patterns = new ArrayList<>();
    String config = getConfigurationService().getConfiguration().getString(NODE_IPS);
    if (StringUtils.isEmpty(config)) {
      return patterns;
    }
    String[] nodeIps = config.split(CLUSTER_NODE_IP_DELIMITER);
    for (String nodeIp : nodeIps) {
      patterns.add(createPatternFromIp(nodeIp));
    }
    return patterns;
  }

  private String createPatternFromIp(String ip) {
    return "(?i)^https?://" + ip.replaceAll("\\.", "\\\\.") + "(:[\\d]+)?(|/.*|\\?.*)$";
  }

  protected ConfigurationService getConfigurationService() {
    return configurationService;
  }

  @Required
  public void setConfigurationService(ConfigurationService configurationService) {
    this.configurationService = configurationService;
  }
}
