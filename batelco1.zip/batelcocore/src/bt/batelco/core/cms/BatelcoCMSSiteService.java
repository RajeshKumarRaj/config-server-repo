package bt.batelco.core.cms;

import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;

public interface BatelcoCMSSiteService extends CMSSiteService {

  /**
   * Updates the URL patterns of the given site with patterns specific for cluster nodes
   *
   * @param siteUid the uid of the site
   */
  void updateUrlPatterns(String siteUid);
}
