package bt.batelco.core.stock.dao;

import de.hybris.platform.basecommerce.enums.InStockStatus;
import de.hybris.platform.core.PK;
import de.hybris.platform.core.model.type.ComposedTypeModel;
import de.hybris.platform.ordersplitting.model.StockLevelModel;
import de.hybris.platform.servicelayer.exceptions.SystemException;
import de.hybris.platform.servicelayer.type.TypeService;
import de.hybris.platform.stock.impl.DefaultStockLevelDao;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

public class DefaultBatelcoStockLevelDao extends DefaultStockLevelDao {

    private TransactionTemplate transactionTemplate;
    private JdbcTemplate jdbcTemplate;
    private DefaultBatelcoStockLevelDao.StockLevelColumns stockLevelColumns;
    private TypeService typeService;

    public void updateActualAmount(final StockLevelModel stockLevel, final int actualAmount) {
        this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            protected void doInTransactionWithoutResult(TransactionStatus arg0) {
                try {
                    int rows = runJdbcQuery(assembleUpdateStockLevelQuery(), actualAmount, stockLevel);
                    if (rows > 1) {
                        throw new IllegalStateException("more stock level rows found for the update: [" + stockLevel.getPk() + "]");
                    }
                } catch (DataAccessException var3) {
                    throw new SystemException(var3);
                }
            }
        });
    }

    public Integer release(final StockLevelModel stockLevel, final int amount) {
        return this.transactionTemplate.execute(status -> {
            try {
                int rows = runJdbcQuery(assembleReleaseStockLevelQuery(), amount, stockLevel);
                return peekStockLevelReserved(rows, stockLevel.getPk(),"more rows found for the release: [");
            } catch (DataAccessException var3) {
                throw new SystemException(var3);
            }
        });
    }

    public Integer reserve(final StockLevelModel stockLevel, final int amount) {
        return this.transactionTemplate.execute(status -> {
            try {
                InStockStatus inStockStatus = stockLevel.getInStockStatus();
                String reserveQuery = assembleReserveStockLevelQuery(inStockStatus);
                long pk = stockLevel.getPk().getLongValue();
                int rows;
                if (InStockStatus.FORCEINSTOCK.equals(inStockStatus)) {
                    rows = jdbcTemplate.update(reserveQuery, amount, pk);
                } else {
                    rows = jdbcTemplate.update(reserveQuery, amount, pk, amount);
                }

                return peekStockLevelReserved(rows, stockLevel.getPk(), "more rows found for the reservation: [");
            } catch (DataAccessException var7) {
                throw new SystemException(var7);
            }
        });
    }

    private Integer peekStockLevelReserved(int rows, PK pk, String message) {
        long pkLong = pk.getLongValue();
        Integer currentReserved = -1;
        if (rows == 1) {
            String requestAmountQuery = assembleRequestStockLevelQuery();
            currentReserved = this.jdbcTemplate.queryForObject(requestAmountQuery, Integer.class, pkLong);
        } else if (rows > 1) {
            throw new IllegalStateException(message + rows + "] rows for stock level [" + pkLong + "]");
        }

        return rows == 1 ? currentReserved : null;
    }


    private int runJdbcQuery(String query, int amount, StockLevelModel stockLevel) {
        Integer theAmount = amount;
        Long pk = stockLevel.getPk().getLongValue();
        return this.jdbcTemplate.update(query, theAmount, pk);
    }

    private String assembleReserveStockLevelQuery(InStockStatus inStockStatus) {
        this.prepareStockLevelColumns();
        StringBuilder query = (new StringBuilder("UPDATE ")).append(this.stockLevelColumns.tableName);
        query.append(" SET ").append(this.stockLevelColumns.reservedCol).append(" = ").append(this.stockLevelColumns.reservedCol).append(" + ? ");
        query.append(" WHERE ").append(this.stockLevelColumns.pkCol).append("=?");
        if (!InStockStatus.FORCEINSTOCK.equals(inStockStatus)) {
            query.append(" AND ").append(this.stockLevelColumns.availableCol).append(" + ").append(this.stockLevelColumns.oversellingCol).append(" - ").append(this.stockLevelColumns.reservedCol).append(" >= ? ");
        }

        return query.toString();
    }

    private String assembleUpdateStockLevelQuery() {
        this.prepareStockLevelColumns();
        StringBuilder query = (new StringBuilder("UPDATE ")).append(this.stockLevelColumns.tableName);
        query.append(" SET ").append(this.stockLevelColumns.availableCol).append(" =?");
        query.append(" WHERE ").append(this.stockLevelColumns.pkCol).append("=?");
        return query.toString();
    }

    private String assembleRequestStockLevelQuery() {
        this.prepareStockLevelColumns();
        StringBuilder query = (new StringBuilder("SELECT ")).append(this.stockLevelColumns.reservedCol);
        query.append(" FROM ").append(this.stockLevelColumns.tableName).append(" WHERE ").append(this.stockLevelColumns.pkCol).append("=?");
        return query.toString();
    }


    private String assembleReleaseStockLevelQuery() {
        this.prepareStockLevelColumns();
        StringBuilder query = (new StringBuilder("UPDATE ")).append(this.stockLevelColumns.tableName);
        query.append(" SET ").append(this.stockLevelColumns.reservedCol).append(" = ").append(this.stockLevelColumns.reservedCol).append(" - ? ");
        query.append(" WHERE ").append(this.stockLevelColumns.pkCol).append("=?");
        return query.toString();
    }

    private void prepareStockLevelColumns() {
        if (this.stockLevelColumns == null) {
            this.stockLevelColumns = new DefaultBatelcoStockLevelDao.StockLevelColumns(this.typeService);
        }

    }

    public TransactionTemplate getTransactionTemplate() {
        return transactionTemplate;
    }

    @Required
    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    @Required
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Required
    public void setTypeService(TypeService typeService) {
        this.typeService = typeService;
    }

    private class StockLevelColumns {
        private final String tableName;
        private final String pkCol;
        private final String reservedCol;
        private final String availableCol;
        private final String oversellingCol;

        private StockLevelColumns(TypeService typeService) {
            ComposedTypeModel stockLevelType = typeService.getComposedTypeForClass(StockLevelModel.class);
            this.tableName = stockLevelType.getTable();
            this.pkCol = typeService.getAttributeDescriptor(stockLevelType, "pk").getDatabaseColumn();
            this.reservedCol = typeService.getAttributeDescriptor(stockLevelType, "reserved").getDatabaseColumn();
            this.availableCol = typeService.getAttributeDescriptor(stockLevelType, "available").getDatabaseColumn();
            this.oversellingCol = typeService.getAttributeDescriptor(stockLevelType, "overSelling").getDatabaseColumn();
        }
    }
}
