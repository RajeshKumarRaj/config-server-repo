package bt.batelco.core.stock;

import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.ordersplitting.model.WarehouseModel;
import de.hybris.platform.stock.StockService;

import java.util.List;

import bt.batelco.core.stock.exceptions.NotEnoughStockException;

public interface BatelcoStockService extends StockService {

    /**
     * Method that reduces the stock for product from order entry with the quantity that are in order entry.
     *
     * @param orderEntryList the given entry list that has product with stock.
     * @param warehouses list with warehouses.
     * @throws NotEnoughStockException in case an entry doesn't have enough stock
     */
    void reduceStockForEntries(List<AbstractOrderEntryModel> orderEntryList,List<WarehouseModel> warehouses) throws NotEnoughStockException;

    /**
     * Method that reserves the stock for product from order entry with the quantity that are in order entry.
     *
     * @param orderEntryList the given entry list that has product with stock.
     * @param warehouses list with warehouses.
     * @throws NotEnoughStockException in case an entry doesn't have enough stock
     */
    void reserveStockForEntries(List<AbstractOrderEntryModel> orderEntryList,List<WarehouseModel> warehouses) throws NotEnoughStockException;

    /**
     * Method that releases the stock for product from order entry with the quantity that are in order entry.
     *
     * @param orderEntryList the given entry list that has product with stock.
     * @param warehouses list with warehouses.
     */
    void releaseStockForEntries(List<AbstractOrderEntryModel> orderEntryList,List<WarehouseModel> warehouses);
}
