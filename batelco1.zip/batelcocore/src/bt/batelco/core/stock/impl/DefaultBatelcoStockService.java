package bt.batelco.core.stock.impl;

import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.ordersplitting.model.WarehouseModel;
import de.hybris.platform.stock.exception.InsufficientStockLevelException;
import de.hybris.platform.stock.impl.DefaultStockService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Date;
import java.util.List;
import java.util.Map;

import bt.batelco.core.stock.BatelcoStockService;
import bt.batelco.core.stock.exceptions.NotEnoughStockException;

import static java.lang.String.format;

public class DefaultBatelcoStockService extends DefaultStockService implements BatelcoStockService {

    private TransactionTemplate transactionTemplate;
    private static final Logger LOG = Logger.getLogger(DefaultBatelcoStockService.class);
    private static final String REDUCE_STOCK_COMMENT="Reduce stock for order %s.";
    private static final String RELEASE_STOCK_COMMENT="Release stock for order %s.";
    private static final String NOT_ENOUGH_STOCK_ERROR_MESSAGE="Not enough stock for product %s.";

    @Override
    public void reduceStockForEntries(List<AbstractOrderEntryModel> orderEntryList, List<WarehouseModel> warehouses) throws NotEnoughStockException {

        this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                orderEntryList.forEach(entry -> reduceStockForEntry(entry,warehouses));
            }
        });
    }

    @Override
    public void reserveStockForEntries(List<AbstractOrderEntryModel> orderEntryList, List<WarehouseModel> warehouses) throws NotEnoughStockException {
        this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                orderEntryList.forEach(entry -> reserveStockForEntry(entry,warehouses));
            }
        });
    }

    private void reserveStockForEntry(AbstractOrderEntryModel entry, List<WarehouseModel> warehouses) {
        int orderQuantity = entry.getQuantity().intValue();
        Map<WarehouseModel, Integer> availability = getAvailability(warehouses, entry.getProduct(), new Date());
        final int totalAvailability = availability.values().stream().mapToInt(Integer::intValue).sum();
        if (totalAvailability < orderQuantity) {
            throw new NotEnoughStockException(String.format(NOT_ENOUGH_STOCK_ERROR_MESSAGE,entry.getProduct().getCode()));
        }

        try {
            reserve(entry.getProduct(),warehouses.get(0),orderQuantity,String.format(REDUCE_STOCK_COMMENT,entry.getOrder().getCode()));
        } catch (InsufficientStockLevelException e) {
            throw new NotEnoughStockException(String.format(NOT_ENOUGH_STOCK_ERROR_MESSAGE,entry.getProduct().getCode()));
        }
    }

    @Override
    public void releaseStockForEntries(List<AbstractOrderEntryModel> orderEntryList, List<WarehouseModel> warehouses){

        this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                orderEntryList.forEach(entry -> releaseStockForEntry(entry,warehouses));
            }
        });
    }

    private void releaseStockForEntry(AbstractOrderEntryModel entry, List<WarehouseModel> warehouses) {
        int orderQuantity = entry.getQuantity().intValue();
        release(entry.getProduct(),warehouses.get(0),orderQuantity,String.format(RELEASE_STOCK_COMMENT,entry.getOrder().getCode()));
    }

    private void reduceStockForEntry(AbstractOrderEntryModel orderEntryModel, List<WarehouseModel> warehouses) throws NotEnoughStockException {


        Map<WarehouseModel, Integer> availability = getAvailability(warehouses, orderEntryModel.getProduct(), new Date());

        final int totalAvailability = availability.values().stream().mapToInt(Integer::intValue).sum();
        int orderQuantity = orderEntryModel.getQuantity().intValue();
        if (totalAvailability < orderQuantity) {
            throw new NotEnoughStockException(String.format(NOT_ENOUGH_STOCK_ERROR_MESSAGE,orderEntryModel.getProduct().getCode()));
        }

        reduceStockFromWhereAvailable(orderEntryModel, availability, orderQuantity);
        releaseStockForEntry(orderEntryModel,warehouses);
    }

    private void reduceStockFromWhereAvailable(AbstractOrderEntryModel orderEntryModel, Map<WarehouseModel, Integer> availability, int orderQuantity) {
        for (Map.Entry<WarehouseModel, Integer> warehouseAvailability : availability.entrySet()) {

            if (warehouseAvailability.getValue() <= 0) {
                break;
            }

            if (hasEnoughStock(orderQuantity, warehouseAvailability)) {
                updateStock(orderEntryModel, warehouseAvailability.getKey(), warehouseAvailability.getValue() - orderQuantity);
                return;
            }

            orderQuantity -= warehouseAvailability.getValue();
            updateStock(orderEntryModel, warehouseAvailability.getKey(), 0);

            if (orderQuantity <= 0) {
                return;
            }
        }
    }

    private boolean hasEnoughStock(int orderQuantity, Map.Entry<WarehouseModel, Integer> entry) {
        return entry.getValue() - orderQuantity > 0;
    }

    private void updateStock(AbstractOrderEntryModel orderEntryModel, WarehouseModel warehouse, int remainingQuantityInWarehouse) {
        ProductModel productModel = orderEntryModel.getProduct();
        updateActualStockLevel(productModel, warehouse, remainingQuantityInWarehouse, "Updated stock availability for order: " + orderEntryModel.getOrder().getCode());
        LOG.info(format("Setting stock to: %s for product %s from warehouse %s", remainingQuantityInWarehouse, productModel.getCode(), warehouse.getCode()));
    }


    @Required
    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }
}
