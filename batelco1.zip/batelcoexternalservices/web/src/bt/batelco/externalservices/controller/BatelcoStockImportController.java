package bt.batelco.externalservices.controller;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import bt.batelco.facades.product.StockImportFacade;

/**
 * Controller exposing operations related to the stock import.
 **/
@Controller
@RequestMapping("/stock")
public class BatelcoStockImportController {
  private static final Logger LOG = LoggerFactory.getLogger(BatelcoStockImportController.class);
  private static final String ENCODING_UTF8 = "UTF-8";

  @Resource(name = "stockImportFacade")
  private StockImportFacade stockImportFacade;

  /**
   * Import stock method
   *
   * @param request - request
   * @return {@link ResponseEntity} with message and status
   */
  @RequestMapping(value = "/isAlive", method = RequestMethod.GET)
  @ResponseBody
  public ResponseEntity<String> isAlive(final HttpServletRequest request) {
    return new ResponseEntity<>("Stock update endpoint alive", HttpStatus.OK);
  }

  /**
   * Import stock method
   *
   * @param request - request
   * @return {@link ResponseEntity} with message and status
   */
  @RequestMapping(value = "/import", method = RequestMethod.POST)
  @ResponseBody
  public ResponseEntity<String> importStock(final HttpServletRequest request) {
    List<String> lines;
    try {
      lines = IOUtils.readLines(request.getInputStream(), ENCODING_UTF8);
    } catch (IOException e) {
      LOG.error("An error appears while reading request body", e);
      return new ResponseEntity<>("Bad request body", HttpStatus.BAD_REQUEST);
    }

    int notImportedLines = stockImportFacade.performImport(lines);

    return new ResponseEntity<>(getMessage(notImportedLines), HttpStatus.OK);
  }

  private String getMessage(int notImportedLines) {
    StringBuilder buf = new StringBuilder("Import finished ");
    if (notImportedLines > 0) {
      buf.append(". ").append(notImportedLines).append(" line(s) were not imported successfully. Please check logs.");
    } else {
      buf.append("successfully.");
    }
    return buf.toString();
  }
}
