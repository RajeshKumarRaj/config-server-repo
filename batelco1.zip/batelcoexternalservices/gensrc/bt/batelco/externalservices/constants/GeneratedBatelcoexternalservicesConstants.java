/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 2, 2020 11:04:10 AM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.externalservices.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBatelcoexternalservicesConstants
{
	public static final String EXTENSIONNAME = "batelcoexternalservices";
	
	protected GeneratedBatelcoexternalservicesConstants()
	{
		// private constructor
	}
	
	
}
