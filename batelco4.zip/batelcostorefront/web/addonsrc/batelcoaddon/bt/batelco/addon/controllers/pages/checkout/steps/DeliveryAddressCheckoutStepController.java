package bt.batelco.addon.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateQuoteCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.forms.AddressForm;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.user.data.AddressData;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Stream;

import static bt.batelco.addon.constants.BatelcoaddonWebConstants.ADD_EDIT_DELIVERY_ADDRESS_PAGE;

/**
 * Delivery address page controller.
 */
@Controller
@RequestMapping(value = "/checkout/multi/delivery-address")
public class DeliveryAddressCheckoutStepController
    extends de.hybris.platform.b2ctelcoaddon.controllers.pages.checkout.steps.DeliveryAddressCheckoutStepController {


  private static final String CHECKOUT_STEP_NUMBER = "checkoutStepNumber";
  private static final String CHECKOUT_STEPS = "checkoutSteps";
  private static final String PAGE_TYPE = "pageType";

  @Override
  @RequestMapping(value = "/add", method = RequestMethod.GET)
  @RequireHardLogIn
  @PreValidateQuoteCheckoutStep
  @PreValidateCheckoutStep(checkoutStep = DELIVERY_ADDRESS)
  public String enterStep(final Model model, final RedirectAttributes redirectAttributes)
      throws CMSItemNotFoundException {
    super.enterStep(model, redirectAttributes);
    setCheckoutStepNumber(model);
    model.addAttribute(PAGE_TYPE, PageType.CHECKOUT_DELIVERY_ADDRESS.name());
    return ADD_EDIT_DELIVERY_ADDRESS_PAGE;
  }

  private void setCheckoutStepNumber(Model model) {
    List<CheckoutSteps> checkoutSteps = (List) model.asMap().get(CHECKOUT_STEPS);
    checkoutSteps.stream().filter(step -> step.getProgressBarId().equals(getCheckoutStep().getProgressBarId()))
        .findAny().ifPresent(found ->
                                 model.addAttribute(CHECKOUT_STEP_NUMBER, found.getStepNumber())
    );
  }

  @Override
  @RequestMapping(value = "/add", method = RequestMethod.POST)
  @RequireHardLogIn
  public String add(final AddressForm addressForm, final BindingResult bindingResult, final Model model,
                    final RedirectAttributes redirectModel) throws CMSItemNotFoundException {
    final AddressData selectedDeliveryAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();

    if (selectedDeliveryAddress != null && isAddressFormEmpty(addressForm)) {
      return getCheckoutStep().nextStep();
    }

    return super.add(addressForm, bindingResult, model, redirectModel);
  }

  private Boolean isAddressFormEmpty(final AddressForm addressForm) {
    return Stream.of(
        addressForm.getFirstName(),
        addressForm.getLastName(),
        addressForm.getLine1(),
        addressForm.getLine2(),
        addressForm.getTownCity(),
        addressForm.getPostcode()
    ).allMatch(StringUtils::isEmpty);
  }

}
