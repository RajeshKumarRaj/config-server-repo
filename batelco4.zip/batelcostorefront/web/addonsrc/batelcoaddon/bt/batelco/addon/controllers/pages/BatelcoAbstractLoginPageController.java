package bt.batelco.addon.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.Breadcrumb;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.b2ctelcoaddon.controllers.pages.AbstractLoginPageController;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.commerceservices.enums.CountryType;
import de.hybris.platform.subscriptionfacades.exceptions.SubscriptionFacadeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bt.batelco.addon.forms.BatelcoLoginForm;
import bt.batelco.addon.forms.BatelcoRegisterForm;
import bt.batelco.facades.consens.BatelcoConsensFacade;
import bt.batelco.facades.country.BatelcoCountryFacade;
import bt.batelco.facades.customer.BatelcoCustomerFacade;
import bt.batelco.facades.exception.ConsentAlreadySignedFacadeException;
import bt.batelco.facades.exception.InvalidCustomerFacadeException;

/**
 * Abstract base class for login page controllers.
 * Added due to changes related to registerForm, form validation and converter from BatelcoRegisterForm
 * to registerData
 */
public abstract class BatelcoAbstractLoginPageController extends AbstractLoginPageController {

  private static final Logger LOG = LoggerFactory.getLogger(BatelcoAbstractLoginPageController.class);
  private static final String REGISTER_FORM = "registerForm";
  private static final String HEADER_LINK_LOGIN = "header.link.login";
  private static final String IS_COUNTRY_DISABLED = "isCountryDisabled";
  private static final String LOGIN_FORM = "loginForm";

  @Resource(name = "batelcoRegisterValidator")
  private Validator registrationValidator;

  @Resource(name = "batelcoRegisterDataConverter")
  Converter<BatelcoRegisterForm, RegisterData> batelcoRegisterDataConverter;

  @Resource(name = "customerFacade")
  private BatelcoCustomerFacade batelcoCustomerFacade;

  @Resource(name = "batelcoCountryFacade")
  private BatelcoCountryFacade batelcoCountryFacade;

  @Resource(name = "batelcoConsensFacade")
  private BatelcoConsensFacade batelcoConsensFacade;

  @ModelAttribute("countries")
  public Collection<CountryData> getCountries() {
    return batelcoCountryFacade.getCountries(CountryType.SHIPPING);
  }

  @Override
  protected String getDefaultLoginPage(final boolean loginError, final HttpSession session, final Model model)
      throws CMSItemNotFoundException {
    final BatelcoLoginForm loginForm = new BatelcoLoginForm();
    final Collection<CountryData> countries = getCountries();

    boolean isCountryDisabled = false;
    BatelcoRegisterForm registerForm = new BatelcoRegisterForm();

    if (countries.size() == 1) {
      registerForm.setCountry(countries.iterator().next().getIsocode());
      isCountryDisabled = true;
    }

    model.addAttribute(LOGIN_FORM, loginForm);
    model.addAttribute(REGISTER_FORM, registerForm);
    model.addAttribute(IS_COUNTRY_DISABLED, isCountryDisabled);

    final String username = (String) session.getAttribute(SPRING_SECURITY_LAST_USERNAME);
    if (username != null) {
      session.removeAttribute(SPRING_SECURITY_LAST_USERNAME);
    }

    loginForm.setJ_username(username);
    storeCmsPageInModel(model, getCmsPage());
    setUpMetaDataForContentPage(model, (ContentPageModel) getCmsPage());
    model.addAttribute("metaRobots", "index,follow");
    addRegistrationConsentDataToModel(model);
    model.addAttribute("termsAndConditionsConsentTemplate",
                       batelcoConsensFacade.getTermsAndConditionsConsentTemplateData());

    final Breadcrumb loginBreadcrumbEntry =
        new Breadcrumb("#", getMessageSource().getMessage(HEADER_LINK_LOGIN, null,
                                                          HEADER_LINK_LOGIN, getI18nService().getCurrentLocale()),
                       null);
    model.addAttribute("breadcrumbs", Collections.singletonList(loginBreadcrumbEntry));

    if (loginError) {
      model.addAttribute("loginError", Boolean.valueOf(loginError));
      try {
        if (username != null && batelcoCustomerFacade.isRegistrationNotCompleted(username)) {
          LOG.warn("LOGIN-101 User has no valid account. Registration not completed. Username: " + username);
          GlobalMessages.addErrorMessage(model, "login.unregistered.error.account.title");
        } else {
          LOG.warn("LOGIN-102 Username or password was incorrect. Username: " + username);
          GlobalMessages.addErrorMessage(model, "login.error.account.not.found.title");
        }
      } catch (InvalidCustomerFacadeException ex) {
        LOG.warn("LOGIN-103 Cannot find user with uid " + username, ex);
        GlobalMessages.addErrorMessage(model, "login.error.account.not.found.title");
      }
    }
    return getView();
  }

  protected String processRegisterUserRequest(final String referer, final BatelcoRegisterForm form,
                                              final BindingResult bindingResult, final Model model,
                                              final HttpServletRequest request,
                                              final HttpServletResponse response,
                                              final RedirectAttributes redirectModel) throws CMSItemNotFoundException {
    registrationValidator.validate(form, bindingResult);

    if (bindingResult.hasErrors()) {
      form.setTermsCheck(false);
      model.addAttribute(REGISTER_FORM, form);
      model.addAttribute(LOGIN_FORM, new BatelcoLoginForm());

      GlobalMessages.addErrorMessage(model, "form.global.error");
      return handleRegistrationError(model);
    }

    final RegisterData data = batelcoRegisterDataConverter.convert(form);

    try {
      getCustomerFacade().register(data);

      final ConsentForm consentForm = form.getConsentForm();
      if (consentForm != null && consentForm.getConsentGiven()) {
        batelcoConsensFacade.giveConsent(consentForm.getConsentTemplateId(),
                                         consentForm.getConsentTemplateVersion(),
                                         data.getLogin());
      }

      final ConsentForm termsAndConditions = form.getTermsConsent();
      batelcoConsensFacade.giveConsent(termsAndConditions.getConsentTemplateId(),
                                       termsAndConditions.getConsentTemplateVersion(), data.getLogin());

      getSubscriptionFacade().updateProfile(new HashMap<>());

      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
                                     "registration.confirmation.message.title");
    } catch (final DuplicateUidException e) {
      LOG.warn("registration failed: " + e);
      model.addAttribute(form);
      model.addAttribute(LOGIN_FORM, new BatelcoLoginForm());

      bindingResult.rejectValue("email", "registration.error.account.exists.title");
      GlobalMessages.addErrorMessage(model, "form.global.error");
      return handleRegistrationError(model);
    } catch (final SubscriptionFacadeException e) {
      LOG.warn("Creating new subscription billing profile for user failed", e);
      model.addAttribute(LOGIN_FORM, new BatelcoLoginForm());
      GlobalMessages.addErrorMessage(model, "registration.error.subscription.billing.profil");
      return handleRegistrationError(model);
    } catch (final ConsentAlreadySignedFacadeException e) {
      LOG.warn("Saving consent already given", e);
      model.addAttribute(LOGIN_FORM, new BatelcoLoginForm());
      GlobalMessages.addErrorMessage(model, "text.consent.already.given");
      return handleRegistrationError(model);
    }

    return REDIRECT_PREFIX + getSuccessRedirect(request, response);
  }

  @Override
  protected String getDefaultRegistrationPage(final Model model) throws CMSItemNotFoundException {
    storeCmsPageInModel(model, getCmsPage());
    setUpMetaDataForContentPage(model, (ContentPageModel) getCmsPage());
    final Breadcrumb loginBreadcrumbEntry =
        new Breadcrumb("#", getMessageSource().getMessage(HEADER_LINK_LOGIN, null,
                                                          getI18nService().getCurrentLocale()), null);
    model.addAttribute("breadcrumbs", Collections.singletonList(loginBreadcrumbEntry));
    model.addAttribute(REGISTER_FORM, new BatelcoRegisterForm());
    return getView();
  }

  public BatelcoCustomerFacade getBatelcoCustomerFacade() {
    return batelcoCustomerFacade;
  }

}
