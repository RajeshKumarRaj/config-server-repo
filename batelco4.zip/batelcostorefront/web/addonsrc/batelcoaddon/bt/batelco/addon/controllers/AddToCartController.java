package bt.batelco.addon.controllers;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.CartModificationData;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.order.CommerceCartModificationStatus;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;

import bt.batelco.addon.validation.PhoneNumberValidator;
import bt.batelco.addon.validation.ValidationResult;
import bt.batelco.core.phonenumber.PhoneNumberService;

@Controller
public class AddToCartController extends de.hybris.platform.b2ctelcoaddon.controllers.misc.AddToCartController {

  private static final Logger LOG = LoggerFactory.getLogger(AddToCartController.class);

  private static final String MODIFIED_CART_DATA = "modifiedCartData";

  private static final String BASKET_INFORMATION_QUANTITY_NO_ITEMS_ADDED = "basket.information.quantity.noItemsAdded";

  private static final String BASKET_ERROR_OCCURRED = "basket.error.occurred";

  private static final String CART_ENTRY_WAS_NOT_CREATED_REASON = "Cart entry was not created. Reason: ";

  private static final String CART = "/cart";

  private static final String BASKET_ERROR_QUANTITY_INVALID = "basket.error.quantity.invalid";

  private static final String QUANTITY = "quantity";

  private static final String ERROR_MSG_TYPE = "errorMsg";

  protected static final String SUCCESS = "success";
  private static final String BOLTON_REGEX = "#";

  @Resource(name = "phoneNumberService")
  private PhoneNumberService phoneNumberService;

  @Resource(name = "phoneNumberValidator")
  private PhoneNumberValidator phoneNumberValidator;

  /**
   * Adds a new {@link TmaSimpleProductOfferingModel} entry to cart. The
   * entry can be added as a simple product offering, or also as part of a bundled product offering identified through
   * the rootBpoCode parameter.
   *
   * @param productCodePost     {@link TmaSimpleProductOfferingModel#CODE}
   * @param processType         represents the process flow in the context of which the entry is added to cart
   *                            (Acquisition, Retention,
   *                            etc.)
   * @param qty                 quantity to be added;default value is 1
   * @param rootBpoCode         {@link TmaBundledProductOfferingModel#CODE} of
   *                            the root
   *                            Bundled Product Offering, as part of which the
   *                            {@link TmaSimpleProductOfferingModel} is
   *                            added
   * @param cartGroupNo         specifies the cart entries group number where the entry to be added too; if -1, then a
   *                            separate cart
   *                            entry group is created
   * @param subscriptionTermId  specifies the identifier of the new subscription term
   * @param subscriberIdentity  represents subscriber identity for an existing customer
   * @param subscriberBillingId represents subscriber billing system id for an existing customer
   * @param model               the Spring model
   * @return the path for AddToCart popup showing the new added entries
   */
  @RequestMapping(value = "/cart/add", method = RequestMethod.POST, produces = "application/json")
  public String addSpoToCart(@RequestParam("productCodePost") final String productCodePost,
                             @RequestParam(value = "processType") final String processType,
                             @RequestParam(value = "qty", required = false, defaultValue = "1") final long qty,
                             @RequestParam(value = "rootBpoCode", required = false) final String rootBpoCode,
                             @RequestParam(value = "cartGroupNo", required = false, defaultValue = "-1") final int cartGroupNo,
                             @RequestParam(value = "subscriptionTermId", required = false) final String subscriptionTermId,
                             @RequestParam(value = "subscriberIdentity") final String subscriberIdentity,
                             @RequestParam(value = "subscriberBillingId", required = false) final String subscriberBillingId,
                             final Model model) {
    if (qty <= 0) {
      model.addAttribute(ERROR_MSG_TYPE, BASKET_ERROR_QUANTITY_INVALID);
      model.addAttribute(QUANTITY, 0L);
    } else {
      ValidationResult validationResult = phoneNumberValidator.validate(subscriberIdentity);
      if (!validationResult.isValid()) {
        model.addAttribute(ERROR_MSG_TYPE, validationResult.getErrors().get(0));
      } else {
        addProductOfferingToCart(productCodePost, qty, processType, rootBpoCode, cartGroupNo, subscriptionTermId,
                                 phoneNumberService.prependPrefix(subscriberIdentity), subscriberBillingId, model);
      }
    }

    model.addAttribute("product",
                       getProductFacade().getProductForCodeAndOptions(productCodePost,
                                                                      Arrays.asList(ProductOption.BASIC,
                                                                                    ProductOption.CATEGORIES)));

    return REDIRECT_PREFIX + CART;
  }


  private CartModificationData addProductOfferingToCart(final String spoCode, final long quantity,
                                                        final String processType,
                                                        final String rootBpoCode, final int cartGroupNo,
                                                        final String subscriptionTermId, final String subscriberId,
                                                        final String subscriberBillingId, final Model model) {
    CartModificationData cartModification = new CartModificationData();

    try {
      cartModification =
          getTmaCartFacade().addProductOfferingToCart(spoCode, quantity, processType, rootBpoCode, cartGroupNo,
                                                      subscriptionTermId, subscriberId, subscriberBillingId);

      model.addAttribute(MODIFIED_CART_DATA, Collections.singleton(cartModification));

      if (cartModification.getQuantityAdded() == 0L) {
        GlobalMessages
            .addErrorMessage(model, "basket.information.quantity.noItemsAdded." + cartModification.getStatusCode());
        model.addAttribute(ERROR_MSG_TYPE,
                           "basket.information.quantity.noItemsAdded." + cartModification.getStatusCode());
      } else if (cartModification.getQuantityAdded() < quantity) {
        GlobalMessages.addErrorMessage(model,
                                       "basket.information.quantity.reducedNumberOfItemsAdded." + cartModification
                                           .getStatusCode());
        model.addAttribute(ERROR_MSG_TYPE,
                           "basket.information.quantity.reducedNumberOfItemsAdded." + cartModification.getStatusCode());

      }

      model.addAttribute("entry", cartModification.getEntry());
      model.addAttribute("cartCode", cartModification.getCartCode());
      model.addAttribute(QUANTITY, quantity);
    } catch (final CommerceCartModificationException ex) {
      model.addAttribute(ERROR_MSG_TYPE, BASKET_ERROR_OCCURRED);
      LOG.warn("Couldn't add product of code " + spoCode + " to cart.", ex);
    }
    final CartData cartData = getCartFacade().getSessionCart();
    model.addAttribute("cartData", cartData);
    return cartModification;
  }


  /**
   * Adds multiple {@link de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel} entries to cart, as
   * part of a bundle product offering specified by the given rootBpoCode. The entries can be added under an existing
   * cart entries group indicated by the cartGroupNo parameter, or under a new entry group .
   *
   * @param device      device {@link de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel#CODE}
   * @param plan        plan {@link de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel#CODE}
   * @param boltons     a bolton list of {@link de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel#CODE}
   * @param processType represents the process flow in the context of which the entry is added to cart (Acquisition,
   *                    Retention,
   *                    etc.)
   * @param rootBpoCode {@link de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel#CODE} of the
   *                    root
   *                    Bundled Product Offering, as part of which the
   *                    {@link de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel} are added
   * @param cartGroupNo specifies the cart entries group number where the entries to be added; if -1, then a separate
   *                    cart entry
   *                    group is created
   * @param model       the Spring model
   * @return the link to cart page
   */

  @RequestMapping(value = "/cart/addBundle", method = RequestMethod.POST)
  public String addBpoToCart(@RequestParam(value = "devicePo", required = false) final String device,
                             @RequestParam(value = "planPo") final String plan,
                             @RequestParam(value = "boltonPos", required = false, defaultValue = "") final List<String> boltons,
                             @RequestParam(value = "processType") final String processType,
                             @RequestParam(value = "rootBpoCode") final String rootBpoCode,
                             @RequestParam(value = "cartGroupNo", required = false, defaultValue = "-1") int cartGroupNo,
                             @RequestParam(value = "subscriptionTermId") final String subscriptionTermId,
                             @RequestParam(value = "deviceInstallmentId", required = false) final String deviceInstallmentId,
                             final Model model) {
    try {
      final List<CartModificationData> cartModifications = new ArrayList<>();
      cartModifications.add(getTmaCartFacade().addProductOfferingToCart(plan, 1, processType, rootBpoCode, cartGroupNo,
                                                                        subscriptionTermId, null, null));
      if (cartGroupNo == -1) {
        CartModificationData firstEntry = cartModifications.get(0);
        if (firstEntry.getStatusCode().equals(CommerceCartModificationStatus.SUCCESS)) {
          cartGroupNo = firstEntry.getEntryGroupNumbers().iterator().next();
        }
      }
      if (StringUtils.isNotBlank(device)) {
        cartModifications.add(getTmaCartFacade()
                                  .addProductOfferingToCart(device, 1, processType, rootBpoCode, cartGroupNo,
                                                            deviceInstallmentId, null, null));
      }
      for (String bolton : boltons) {
        String[] boltonInput = bolton.split(BOLTON_REGEX);
        if (boltonInput.length == 2) {
          cartModifications.add(getTmaCartFacade()
                                    .addProductOfferingToCart(boltonInput[0], 1, processType, rootBpoCode, cartGroupNo,
                                                              boltonInput[1], null, null));
        } else {
          GlobalMessages.addErrorMessage(model, BASKET_ERROR_OCCURRED);
          throw new CommerceCartModificationException(CART_ENTRY_WAS_NOT_CREATED_REASON + "Bolton [" + bolton
                                                      + " ] not well configured - missing subscription term");
        }
      }

      model.addAttribute(MODIFIED_CART_DATA, cartModifications);

      for (final CartModificationData cartModification : cartModifications) {
        if (cartModification.getEntry() == null) {
          GlobalMessages.addErrorMessage(model, BASKET_INFORMATION_QUANTITY_NO_ITEMS_ADDED);
          model.addAttribute(ERROR_MSG_TYPE, BASKET_INFORMATION_QUANTITY_NO_ITEMS_ADDED);
          throw new CommerceCartModificationException(
              CART_ENTRY_WAS_NOT_CREATED_REASON + cartModification.getStatusCode());
        }
      }
    } catch (final CommerceCartModificationException ex) {
      model.addAttribute(ERROR_MSG_TYPE, BASKET_ERROR_OCCURRED);
      LOG.error("Couldn't add BPO of code {} and spos with codes {}, {}, {}", rootBpoCode, device, plan, boltons, ex);
    }
    return REDIRECT_PREFIX + CART;
  }

}
