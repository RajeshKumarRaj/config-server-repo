package bt.batelco.addon.forms;

public class AcquisitionFormNew {
	
	String cartEntryNumber;
	String productCategory;
	String contractName;
	String contactName;
	String contactNumber;
	String flat;
	String building;
	String road;
	String block;
	String telephoneDirectory;
	String consent;
	
	String circuitNumber;
	String preferredLang;
	String activateEBilling;
	
	String signImageData;
	
	public String getCartEntryNumber() {
		return cartEntryNumber;
	}
	public void setCartEntryNumber(String cartEntryNumber) {
		this.cartEntryNumber = cartEntryNumber;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getContractName() {
		return contractName;
	}
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getFlat() {
		return flat;
	}
	public void setFlat(String flat) {
		this.flat = flat;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	public String getBlock() {
		return block;
	}
	public void setBlock(String block) {
		this.block = block;
	}
	public String getTelephoneDirectory() {
		return telephoneDirectory;
	}
	public void setTelephoneDirectory(String telephoneDirectory) {
		this.telephoneDirectory = telephoneDirectory;
	}
	public String getConsent() {
		return consent;
	}
	public void setConsent(String consent) {
		this.consent = consent;
	}
	public String getCircuitNumber() {
		return circuitNumber;
	}
	public void setCircuitNumber(String circuitNumber) {
		this.circuitNumber = circuitNumber;
	}
	public String getPreferredLang() {
		return preferredLang;
	}
	public void setPreferredLang(String preferredLang) {
		this.preferredLang = preferredLang;
	}
	public String getActivateEBilling() {
		return activateEBilling;
	}
	public void setActivateEBilling(String activateEBilling) {
		this.activateEBilling = activateEBilling;
	}
	public String getSignImageData() {
		return signImageData;
	}
	public void setSignImageData(String signImageData) {
		this.signImageData = signImageData;
	}

}
