package bt.batelco.addon.controllers.pages;

import com.iquest.config.service.ConfigProviderService;
import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ReviewForm;
import de.hybris.platform.acceleratorstorefrontcommons.util.MetaSanitizerUtil;
import de.hybris.platform.b2ctelcoaddon.controllers.pages.ProductPageController;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.catalog.enums.ProductReferenceTypeEnum;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.ProductReferenceData;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.subscriptionfacades.data.SubscriptionPricePlanData;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bt.batelco.core.phonenumber.PhoneNumberService;
import bt.batelco.core.product.BatelcoProductService;
import bt.batelco.facades.product.BatelcoTmaProductOfferFacade;
import bt.batelco.facades.product.data.DeviceInstalmentTerm;
import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;

@Controller
@Scope("tenant")
@RequestMapping(value = "/**/p")
public class BatelcoProductPageController extends ProductPageController {

  private static final Logger LOG = Logger.getLogger(BatelcoProductPageController.class);

  private static final String PHONE_COUNTRY_PREFIX = "phoneCountryPrefix";
  private static final String PRODUCT_CODE_PATH_VARIABLE_PATTERN = "/{productCode:.*}";
  private static final String PRODUCT_SLANG_PATH_VARIABLE_PATTERN = "/{slangCode:.*}";
  private static final String PRODUCT_DATA = "product";
  private static final String CANONICAL_LINK = "canonicalLink";
  private static final String REVIEWS_PATH_VARIABLE_PATTERN = "{numberOfReviews:.*}";
  private static final String NONE = "none";
  private static final String VAT = "vat";
  private static final String NO_CONTRACT_SUBSCRIPTION_TERM_DISPLAY_NAME_FOR_DEVICE = "device.nocontract.subscriptionterm.display.name";

  @Resource(name = "phoneNumberService")
  private PhoneNumberService phoneNumberService;

  @Resource(name = "productModelUrlResolver")
  private UrlResolver<ProductModel> productModelUrlResolver;

  @Resource(name = "productFacade")
  private ProductFacade productFacade;

  @Resource(name = "configProviderService")
  private ConfigProviderService configProviderService;

  @Override
  @RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
  public String productDetail(@PathVariable("productCode") final String slangCode, final Model model,
                              final HttpServletRequest request, final HttpServletResponse response)
          throws CMSItemNotFoundException, UnsupportedEncodingException {

    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    final String redirection = checkRequestUrl(request, response, productModelUrlResolver.resolve(productModel));
    if (StringUtils.isNotEmpty(redirection)) {
      return redirection;
    }
    defaultProductDetails(model, request, productModel);

    model.addAttribute(PHONE_COUNTRY_PREFIX, phoneNumberService.getCountryPrefix());
    model.addAttribute(CANONICAL_LINK, getBatelcoProductOfferFacade().getCanonicalLink(productModel));

    return getViewForPage(model);
  }

  private void defaultProductDetails(Model model, HttpServletRequest request, TmaProductOfferingModel productModel)
          throws CMSItemNotFoundException {
    updatePageTitle(productModel, model);
    populateProductDetailForDisplay(productModel, model, request);
    model.addAttribute(new ReviewForm());
    final List<ProductReferenceData> productReferences =
            productFacade.getProductReferencesForCode(productModel.getCode(),
                    Arrays.asList(ProductReferenceTypeEnum.SIMILAR,
                            ProductReferenceTypeEnum.ACCESSORIES),
                    Arrays.asList(ProductOption.BASIC, ProductOption.PRICE), null);
    model.addAttribute("productReferences", productReferences);
    model.addAttribute("pageType", PageType.PRODUCT.name());

    final ProductData productData = (ProductData) model.asMap().get(PRODUCT_DATA);

    try{
      updateSubscriptionTermName(productData);
    }catch(Exception e){
      //To be removed in next release. Last moment change.
      LOG.error("Exception while updating SubscriptionTermName",e);
    }

    final String metaKeywords = MetaSanitizerUtil.sanitizeKeywords(productData.getKeywords());
    final String metaDescription = MetaSanitizerUtil.sanitizeDescription(productData.getDescription());
    setUpMetaData(model, metaKeywords, metaDescription);
  }

  private void updateSubscriptionTermName(ProductData productData) {
    List<SubscriptionPricePlanData> noContractPriceWithVat = productData.getProductOfferingPrices().stream()
            .filter(offeringPrice -> offeringPrice.getSubscriptionTerms().stream()
                    .anyMatch(s -> s.getId().equalsIgnoreCase(NONE)))
            .filter(offeringPrice -> offeringPrice.getOneTimeChargeEntries().stream()
                    .anyMatch( otc -> (otc.getBillingTime() != null && otc.getBillingTime().getCode().equalsIgnoreCase(VAT))))
            .collect(Collectors.toList());

    if(CollectionUtils.isNotEmpty(noContractPriceWithVat)){
      List<DeviceInstalmentTerm> deviceInstalmentTerms =   productData.getDeviceInstallments().stream()
              .filter(deviceInstalmentTerm -> deviceInstalmentTerm.getCode().equalsIgnoreCase(NONE))
              .collect(Collectors.toList());

      deviceInstalmentTerms.stream().forEach(deviceInstalmentTerm -> {
        deviceInstalmentTerm.setName(getSubscriptionTermDisplayName(deviceInstalmentTerm));
      });
    }
  }

  private String getSubscriptionTermDisplayName(DeviceInstalmentTerm deviceInstalmentTerm) {
    return configProviderService.<String>get(NO_CONTRACT_SUBSCRIPTION_TERM_DISPLAY_NAME_FOR_DEVICE)
            .conversion(source -> source).onMissing(useDefault(deviceInstalmentTerm.getName())).convert();
  }

  @Override
  @RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/quickView", method = RequestMethod.GET)
  public String showQuickView(@PathVariable("productCode") final String slangCode, final Model model,
                              final HttpServletRequest request) {
    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    return super.showQuickView(productModel.getCode(), model, request);
  }

  @Override
  @RequestMapping(value = PRODUCT_SLANG_PATH_VARIABLE_PATTERN + "/review", method =
          {RequestMethod.GET, RequestMethod.POST})
  public String postReview(@PathVariable final String slangCode, final ReviewForm form, final BindingResult result,
                           final Model model, final HttpServletRequest request, final RedirectAttributes redirectAttrs)
          throws CMSItemNotFoundException {
    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    return super.postReview(productModel.getCode(), form, result, model, request, redirectAttrs);
  }

  @Override
  @RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/reviewhtml/"
          + REVIEWS_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
  public String reviewHtml(@PathVariable("productCode") final String slangCode,
                           @PathVariable("numberOfReviews") final String numberOfReviews, final Model model, final HttpServletRequest request) {
    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    return super.reviewHtml(productModel.getCode(), numberOfReviews, model, request);
  }


  @Override
  @RequestMapping(value = PRODUCT_SLANG_PATH_VARIABLE_PATTERN + "/writeReview", method = RequestMethod.GET)
  public String writeReview(@PathVariable final String slangCode, final Model model) throws CMSItemNotFoundException {
    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    return super.writeReview(productModel.getCode(), model);
  }

  @Override
  @RequestMapping(value = PRODUCT_SLANG_PATH_VARIABLE_PATTERN + "/writeReview", method = RequestMethod.POST)
  public String writeReview(@PathVariable final String slangCode, final ReviewForm form, final BindingResult result,
                            final Model model, final HttpServletRequest request, final RedirectAttributes redirectAttrs)
          throws CMSItemNotFoundException {
    TmaProductOfferingModel productModel = getProductService().getProductOfferingForSlang(slangCode);
    return super.writeReview(productModel.getCode(), form, result, model, request, redirectAttrs);
  }


  private BatelcoProductService getProductService() {
    return (BatelcoProductService) getTmaPoService();
  }

  private BatelcoTmaProductOfferFacade getBatelcoProductOfferFacade() {
    return (BatelcoTmaProductOfferFacade) getProductOfferFacade();
  }
}
