package bt.batelco.addon.forms;

import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.LoginForm;

public class BatelcoLoginForm extends LoginForm {

  private ConsentForm termsConsent;
  private boolean termsCheck;

  public boolean isTermsCheck() {
    return termsCheck;
  }

  public void setTermsCheck(boolean termsCheck) {
    this.termsCheck = termsCheck;
  }

  public ConsentForm getTermsConsent() {
    return termsConsent;
  }

  public void setTermsConsent(ConsentForm termsConsent) {
    this.termsConsent = termsConsent;
  }
}
