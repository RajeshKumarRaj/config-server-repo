package bt.batelco.addon.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorservices.enums.CheckoutPciOptionEnum;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.PlaceOrderForm;
import de.hybris.platform.b2ctelcoaddon.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.order.InvalidCartException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.iquest.config.service.ConfigProviderService;
import org.apache.commons.lang.StringUtils;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bt.batelco.addon.forms.BatelcoPlaceOrderForm;
import bt.batelco.addon.forms.PaymentDetailsForm;
import bt.batelco.facades.consens.BatelcoConsensFacade;
import bt.batelco.facades.order.BatelcoCheckoutFacade;
import bt.batelco.facades.payment.dto.InitPayment;
import bt.batelco.facades.payment.dto.InitPaymentCartItem;
import bt.batelco.facades.payment.dto.InitPaymentData;
import bt.batelco.facades.payment.dto.InitRequest;
import bt.batelco.facades.payment.dto.PaymentCart;
import bt.batelco.payment.service.BatelcoPaymentService;
import de.hybris.platform.util.Config;
import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CHECKOUT_SUMMARY_PAGE;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwInvalidConfigException;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwMissingConfigException;

/**
 * Checkout controller.
 */
@Controller
@RequestMapping(value = "/checkout/multi/summary")
public class SummaryCheckoutStepController extends AbstractCheckoutStepController {
  private static final Logger LOG = LoggerFactory.getLogger(SummaryCheckoutStepController.class);

  private static final String SUMMARY = "summary";
  private static final String CHECKOUT_PAYMENT_METHOD_NO_SECURITY_CODE = "checkout.paymentMethod.noSecurityCode";
  private static final String CHECKOUT_PAYMENT_METHOD_NOT_SELECTED = "checkout.paymentMethod.notSelected";
  private static final String CHECKOUT_MULTI_SUMMARY_BREADCRUMB = "checkout.multi.summary.breadcrumb";
  private static final String TEXT_CONSENT_ALREADY_GIVEN = "text.consent.already.given";
  private static final String CHECKOUT_PLACE_ORDER_FAILED = "checkout.placeOrder.failed";
  private static final String CHECKOUT_DELIVERY_ADDRESS_NOT_SELECTED = "checkout.deliveryAddress.notSelected";
  private static final String CHECKOUT_DELIVERY_METHOD_NOT_SELECTED = "checkout.deliveryMethod.notSelected";
  private static final String CHECKOUT_ERROR_TERMS_NOT_ACCEPTED = "checkout.error.terms.not.accepted";
  private static final String CHECKOUT_ERROR_TAX_MISSING = "checkout.error.tax.missing";
  private static final String CHECKOUT_ERROR_CART_NOTCALCULATED = "checkout.error.cart.notcalculated";
  private static final String CHECKOUT_STEP_NUMBER = "checkoutStepNumber";
  private static final String CHECKOUT_STEPS = "checkoutSteps";
  private static final String PAGE_TYPE = "pageType";
  private static final String INIT_PAYMENT_URL_CFG_KEY = "payment.gateway.init.transaction.url";
  private static final String PAYMENT_GENERAL_ERROR_MSG = "order.payment.generalError";
  private static final String PAYMENT_GATEWAY_RESPONSE = "paymentGatewayResponse";
  
  public static final String REDIRECT_TO_PAYMENT_PAGE = "redirect:/checkout/multi/payment-method/add";
  
  
  
  @Resource(name = "batelcoConsensFacade")
  private BatelcoConsensFacade batelcoConsensFacade;

  @Resource(name = "acceleratorCheckoutFacade")
  private BatelcoCheckoutFacade batelcoCheckoutFacade;
  
  @Resource(name="batelcoPaymentService")
  private BatelcoPaymentService batelcoPaymentService;

  @Resource(name = "configProviderService")
  private ConfigProviderService configProviderService;

  @Resource(name = "batelcoRestTemplate")
  private RestTemplate restTemplate;
  
  private void initialEnterStep(final Model model)
      throws CMSItemNotFoundException {
    final CartData cartData = batelcoCheckoutFacade.getCartData();

    model.addAttribute("cartData", cartData);
    model.addAttribute("allItems", cartData.getEntries());
    model.addAttribute("deliveryAddress", cartData.getDeliveryAddress());
    model.addAttribute("deliveryMode", cartData.getDeliveryMode());
    model.addAttribute("paymentInfo", cartData.getPaymentInfo());

    // Only request the security code if the SubscriptionPciOption is set to Default.
    final boolean requestSecurityCode = CheckoutPciOptionEnum.DEFAULT
        .equals(getCheckoutFlowFacade().getSubscriptionPciOption());
    model.addAttribute("requestSecurityCode", Boolean.valueOf(requestSecurityCode));

    model.addAttribute("placeOrderForm", new BatelcoPlaceOrderForm());

    storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
    setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
    model.addAttribute(WebConstants.BREADCRUMBS_KEY,
                       getResourceBreadcrumbBuilder().getBreadcrumbs(CHECKOUT_MULTI_SUMMARY_BREADCRUMB));
    model.addAttribute("metaRobots", "noindex,nofollow");
    model.addAttribute(PAGE_TYPE, PageType.CHECKOUT_SUMMARY.name());

    setCheckoutStepNumber(model);
    setCheckoutStepLinksForModel(model, getCheckoutStep());
  }

  private void setCheckoutStepNumber(Model model) {
    List<CheckoutSteps> checkoutSteps = (List) model.asMap().get(CHECKOUT_STEPS);
    checkoutSteps.stream().filter(step -> step.getProgressBarId().equals(getCheckoutStep().getProgressBarId()))
        .findAny().ifPresent(found ->
                                 model.addAttribute(CHECKOUT_STEP_NUMBER, found.getStepNumber())
    );
  }

  @RequestMapping(value = "/view", method = RequestMethod.GET)
  @RequireHardLogIn
  @Override
  @PreValidateCheckoutStep(checkoutStep = SUMMARY)
  public String enterStep(Model model, RedirectAttributes redirectAttributes) throws CMSItemNotFoundException {
	  
	  //populating initpaymentrequest and user redirect url into model for place orde submission
	  
	  LOG.info("cart object and code " + batelcoCheckoutFacade.getCheckoutCart().getCode());
	  
	  InitRequest initPaymentRequest = batelcoCheckoutFacade.createInitPaymentRequest();
	  final ResponseEntity<String> responseEntity = batelcoPaymentService.initPaymentRequest(initPaymentRequest);
	  try {
	  String paymentCustomerRedirectURL = batelcoCheckoutFacade.getPaymentRedirectUrl(responseEntity);

	  LOG.info("inside /view -- getting paymentredirect url " + paymentCustomerRedirectURL);
	  
	  model.addAttribute("paymentRedirectUrl", paymentCustomerRedirectURL);
	  
	  }catch(JsonParseException e) {
		  e.printStackTrace();
		  LOG.info("Error -- " + e.getMessage() );
	  }catch(JsonMappingException e) {
		  e.printStackTrace();
	  }catch(IOException e) {
		  e.printStackTrace();
	  }
	 
    initialEnterStep(model);
    CartData cartData = getCheckoutFacade().getCheckoutCart();
    LOG.info("cart object and code " + cartData.getCode());
    model.addAttribute("billingAddress", cartData.getBatelcoPaymentInfo().getBillingAddress());
    model.addAttribute("termsAndConditionsConsentTemplate",
                       batelcoConsensFacade.getTermsAndConditionsConsentTemplateData());

    return CHECKOUT_SUMMARY_PAGE;
  }
  
  private String getInitPaymentGatewayUrl() {
	    return configProviderService.<String>get(INIT_PAYMENT_URL_CFG_KEY).conversion(source -> source)
	        .onMissing(throwMissingConfigException()).onInvalid(throwInvalidConfigException()).convert();
	  }

  
  @RequestMapping(value = "/orderConfirmation")
  @RequireHardLogIn
  public String orderSuccess(final Model model, final RedirectAttributes redirectModel,final HttpServletRequest request) throws CMSItemNotFoundException {
	  
	  final OrderData orderData;
	    try {
	      orderData = getCheckoutFacade().placeOrder();
	    } catch (final InvalidCartException e) {
	      LOG.error("Failed to place Order", e);
	      GlobalMessages.addErrorMessage(model, CHECKOUT_PLACE_ORDER_FAILED);
	      return enterStep(model, redirectModel);
	    }

	    return redirectToOrderConfirmationPage(orderData);  
  }
  
  @RequestMapping(value = "/orderfailure")
  @RequireHardLogIn
  public String orderFailure(final Model model, final RedirectAttributes redirectModel,final HttpServletRequest request) throws CMSItemNotFoundException {
	  
	  GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, PAYMENT_GENERAL_ERROR_MSG,
              null);

// have to redirect to the payment page with error message
	  	return REDIRECT_TO_PAYMENT_PAGE;  
  }
  
  @RequestMapping(value = "/placeOrder")
  @RequireHardLogIn
  public String placeOrder(@ModelAttribute("placeOrderForm") final BatelcoPlaceOrderForm placeOrderForm,
                           final Model model, final RedirectAttributes redirectModel,final HttpServletRequest request) throws CMSItemNotFoundException {

	  LOG.info("inside custom_batelco_batelcoaddon_acceleratoraddon_web_src_bt_batelco_addon_controllers_pages_checkout_steps_SummaryCheckoutStepController.java ");
	  
    if (validateOrderForm(placeOrderForm, model)) {
      return enterStep(model, redirectModel);
    }
    
    String paymentGatewayInitTransactionUrl = getInitPaymentGatewayUrl();
    
    //Validate the cart
    if (validateCart(redirectModel)) {
      // Invalid cart. Bounce back to the cart page.
      return REDIRECT_PREFIX + "/cart";
    }
    try {
      final ConsentForm termsConsent = placeOrderForm.getTermsConsent();
      batelcoConsensFacade.giveConsent(termsConsent.getConsentTemplateId(), termsConsent.getConsentTemplateVersion());
    } catch (RuntimeException ex) {
      LOG.error("Failed to place Order", ex);
      GlobalMessages.addErrorMessage(model, TEXT_CONSENT_ALREADY_GIVEN);
      return enterStep(model, redirectModel);
    }

    final OrderData orderData;
    try {
      orderData = getCheckoutFacade().placeOrder();
    } catch (final InvalidCartException e) {
      LOG.error("Failed to place Order", e);
      GlobalMessages.addErrorMessage(model, CHECKOUT_PLACE_ORDER_FAILED);
      return enterStep(model, redirectModel);
    }

    return redirectToOrderConfirmationPage(orderData);
  }
  
  

  /*
  @RequestMapping(value = "/redirectPayment")
  @RequireHardLogIn
  public String paymentConfirmation(@ModelAttribute("placeOrderForm") final BatelcoPlaceOrderForm placeOrderForm,
                           final Model model, final RedirectAttributes redirectModel,final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException,JsonMappingException, IOException, JsonParseException {
	  
	  
	  String paymentCustomerRedirectURL = (String) redirectModel.getAttribute("paymentCustomerRedirectURL");
			  
			  getAttribute("paymentCustomerRedirectURL");
	  
	  String paymentCustomerRedirectURL = (String) request.getAttribute("paymentCustomerRedirectURL");
	  
	  response.sendRedirect(paymentCustomerRedirectURL);
	  
	  RedirectView redirectView = new RedirectView();
	  redirectView.setUrl(paymentCustomerRedirectURL);
	  return redirectView;
	  
	  try {
	      final ConsentForm termsConsent = placeOrderForm.getTermsConsent();
	      batelcoConsensFacade.giveConsent(termsConsent.getConsentTemplateId(), termsConsent.getConsentTemplateVersion());
	    } catch (RuntimeException ex) {
	      LOG.error("Failed to place Order", ex);
	      GlobalMessages.addErrorMessage(model, TEXT_CONSENT_ALREADY_GIVEN);
	      return enterStep(model, redirectModel);
	    }

	    final OrderData orderData;
	    try {
	      orderData = getCheckoutFacade().placeOrder();
	    } catch (final InvalidCartException e) {
	      LOG.error("Failed to place Order", e);
	      GlobalMessages.addErrorMessage(model, CHECKOUT_PLACE_ORDER_FAILED);
	      return enterStep(model, redirectModel);
	    }

	    return redirectToOrderConfirmationPage(orderData);
	  
	  
  }
  */

	
  
  
  
  private boolean isErrorResponse(final ResponseEntity<String> responseEntity) {
	    final HttpStatus responseStatus = responseEntity.getStatusCode();
	    final String responseBody = responseEntity.getBody();
	    
	    return responseStatus.is5xxServerError() || responseStatus.is4xxClientError() || StringUtils.isEmpty(responseBody);
	  }
  
  /**
   * Validates the order form before to filter out invalid order states.
   *
   * @param placeOrderForm The spring form of the order being submitted
   * @param model          A spring Model
   * @return True if the order form is invalid and false if everything is valid.
   */
  private boolean validateOrderForm(final PlaceOrderForm placeOrderForm, final Model model) {
    final String securityCode = placeOrderForm.getSecurityCode();
    boolean invalid = false;

    if (getCheckoutFlowFacade().hasNoDeliveryAddress()) {
      GlobalMessages.addErrorMessage(model, CHECKOUT_DELIVERY_ADDRESS_NOT_SELECTED);
      invalid = true;
    }

    if (getCheckoutFlowFacade().hasNoDeliveryMode()) {
      GlobalMessages.addErrorMessage(model, CHECKOUT_DELIVERY_METHOD_NOT_SELECTED);
      invalid = true;
    }

    if (getCheckoutFlowFacade().hasNoPaymentInfo()) {
      GlobalMessages.addErrorMessage(model, CHECKOUT_PAYMENT_METHOD_NOT_SELECTED);
      invalid = true;
    } else {
      // Only require the Security Code to be entered on the summary page if the SubscriptionPciOption is set to Default.
      if (CheckoutPciOptionEnum.DEFAULT.equals(getCheckoutFlowFacade().getSubscriptionPciOption())
          && StringUtils.isBlank(securityCode)) {
        GlobalMessages.addErrorMessage(model, CHECKOUT_PAYMENT_METHOD_NO_SECURITY_CODE);
        invalid = true;
      }
    }

    if (!placeOrderForm.isTermsCheck()) {
      GlobalMessages.addErrorMessage(model, CHECKOUT_ERROR_TERMS_NOT_ACCEPTED);
      return true;
    }
    final CartData cartData = getCheckoutFacade().getCheckoutCart();

    if (!getCheckoutFacade().containsTaxValues()) {
      LOG.error(String.format("Cart %s does not have any tax values, which means the tax cacluation "
                              + "was not properly done, placement of order can't continue", cartData.getCode()));
      GlobalMessages.addErrorMessage(model, CHECKOUT_ERROR_TAX_MISSING);
      invalid = true;
    }

    if (!cartData.isCalculated()) {
      LOG.error(
          String
              .format("Cart %s has a calculated flag of FALSE, placement of order can't continue", cartData.getCode()));
      GlobalMessages.addErrorMessage(model, CHECKOUT_ERROR_CART_NOTCALCULATED);
      invalid = true;
    }

    return invalid;
  }

  @RequestMapping(value = "/back", method = RequestMethod.GET)
  @RequireHardLogIn
  @Override
  public String back(final RedirectAttributes redirectAttributes) {
    return getCheckoutStep().previousStep();
  }

  @RequestMapping(value = "/next", method = RequestMethod.GET)
  @RequireHardLogIn
  @Override
  public String next(final RedirectAttributes redirectAttributes) {
    return getCheckoutStep().nextStep();
  }

  protected CheckoutStep getCheckoutStep() {
    return getCheckoutStep(SUMMARY);
  }

}
