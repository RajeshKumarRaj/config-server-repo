package bt.batelco.addon.forms.validation;

import org.apache.commons.lang.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import bt.batelco.addon.forms.BatelcoUpdateProfileForm;

/**
 * Profile validator
 */
public class BatelcoProfileValidator implements Validator {
  @Override
  public boolean supports(Class<?> aClass) {
    return BatelcoUpdateProfileForm.class.equals(aClass);
  }

  @Override
  public void validate(Object object, Errors errors) {
    final BatelcoUpdateProfileForm profileForm = (BatelcoUpdateProfileForm) object;

    validateField(errors, profileForm.getFirstName(), "firstName", "profile.firstName.invalid");
    validateField(errors, profileForm.getLastName(), "lastName", "profile.lastName.invalid");
    validateField(errors, profileForm.getCprId(), "cprId", "profile.cprId.invalid");
    validateField(errors, profileForm.getPhone(), "phone", "profile.phone.invalid");
  }

  private void validateField(Errors errors, String field, String fieldName, String invalidMessage) {
    if (StringUtils.isBlank(field) || StringUtils.length(field) > 255) {
      errors.rejectValue(fieldName, invalidMessage);
    }
  }

}
