package bt.batelco.addon.forms;

import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;

public class BatelcoRegisterForm extends de.hybris.platform.acceleratorstorefrontcommons.forms.RegisterForm {

  private String cprId;
  private String phone;
  private String country;
  private String city;
  private String addressLine1;
  private String addressLine2;
  private String zipCode;
  private ConsentForm termsConsent;

  public String getCprId() {
    return cprId;
  }

  public void setCprId(String cprId) {
    this.cprId = cprId;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getAddressLine1() {
    return addressLine1;
  }

  public void setAddressLine1(String addressLine1) {
    this.addressLine1 = addressLine1;
  }

  public String getAddressLine2() {
    return addressLine2;
  }

  public void setAddressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
  }

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public ConsentForm getTermsConsent() {
    return termsConsent;
  }

  public void setTermsConsent(ConsentForm termsConsent) {
    this.termsConsent = termsConsent;
  }
}
