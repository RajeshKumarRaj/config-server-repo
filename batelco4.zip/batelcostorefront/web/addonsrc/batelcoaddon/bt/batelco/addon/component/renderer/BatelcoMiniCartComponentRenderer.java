package bt.batelco.addon.component.renderer;

import de.hybris.platform.acceleratorcms.model.components.MiniCartComponentModel;
import de.hybris.platform.b2ctelcoaddon.component.renderer.MiniCartComponentRenderer;

import bt.batelco.addon.constants.BatelcoaddonConstants;


/**
 * Renderer for mini cart component - it shows only the total items count
 */
public class BatelcoMiniCartComponentRenderer<C extends MiniCartComponentModel> extends MiniCartComponentRenderer<C>
{
  @Override
  protected String getAddonUiExtensionName(final C component)
  {
    return BatelcoaddonConstants.EXTENSIONNAME;
  }
}
