package bt.batelco.addon.forms;


import de.hybris.platform.acceleratorstorefrontcommons.forms.AddressForm;


public class PaymentDetailsForm {

  private boolean useDeliveryAddress;
  private boolean saveInAddressBook;
  private AddressForm billingAddressForm;
  
  private String paymentTypeCode;
  private String paymentMode;

  public String getPaymentTypeCode() {
	return paymentTypeCode;
}

public void setPaymentTypeCode(String paymentTypeCode) {
	this.paymentTypeCode = paymentTypeCode;
}

public String getPaymentMode() {
	return paymentMode;
}

public void setPaymentMode(String paymentMode) {
	this.paymentMode = paymentMode;
}

public PaymentDetailsForm() {
    this.billingAddressForm = new AddressForm();
  }

  public boolean isUseDeliveryAddress() {
    return useDeliveryAddress;
  }

  public void setUseDeliveryAddress(boolean useDeliveryAddress) {
    this.useDeliveryAddress = useDeliveryAddress;
  }

  public boolean isSaveInAddressBook() {
    return saveInAddressBook;
  }

  public void setSaveInAddressBook(boolean saveInAddressBook) {
    this.saveInAddressBook = saveInAddressBook;
  }

  public AddressForm getBillingAddressForm() {
    return billingAddressForm;
  }

  public void setBillingAddressForm(AddressForm billingAddressForm) {
    this.billingAddressForm = billingAddressForm;
  }
}
