package com.iquest.dynamiclocalizationaddon;

import com.iquest.dynamiclocalization.facades.localization.LocalizationFacade;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import java.text.MessageFormat;
import java.util.Locale;


/**
 * Custom message source used to read localization messages from the database.
 */
public class DynamicLocalizationMessageSource extends ReloadableResourceBundleMessageSource
{
	private static final Logger LOG = Logger.getLogger(DynamicLocalizationMessageSource.class);
	private static final String VALUE_FOUND_IN_DB = "Returning value %s for code %s and locale %s from the database.";
	private static final String SEARCH_FOR_VALUE_IN_FILE = "Returning value for code %s and locale %s from the properties file.";
	private LocalizationFacade localizationFacade;


	@Override
	protected String resolveCodeWithoutArguments(String code, Locale locale)
	{
		String localizedMessage = localizationFacade.findLocalizedMessage(code, locale);

		if (StringUtils.isNotEmpty(localizedMessage))
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug(String.format(VALUE_FOUND_IN_DB, localizedMessage, code, locale));
			}

			return localizedMessage;
		}

		if (LOG.isDebugEnabled())
		{
			LOG.debug(String.format(SEARCH_FOR_VALUE_IN_FILE, code, locale));
		}

		return super.resolveCodeWithoutArguments(code, locale);
	}

	@Override
	protected MessageFormat resolveCode(String code, Locale locale)
	{
		String localizedMessage = localizationFacade.findLocalizedMessage(code, locale);
		if (StringUtils.isNotEmpty(localizedMessage))
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug(String.format(VALUE_FOUND_IN_DB, localizedMessage, code, locale));
			}
			return new MessageFormat(localizedMessage, locale);
		}

		if (LOG.isDebugEnabled())
		{
			LOG.debug(String.format(SEARCH_FOR_VALUE_IN_FILE, code, locale));
		}
		return super.resolveCode(code, locale);
	}


	@Required
	public void setLocalizationFacade(LocalizationFacade localizationFacade)
	{
		this.localizationFacade = localizationFacade;
	}
}
