/*
* [y] hybris Platform
*
* Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
*
* This software is the confidential and proprietary information of SAP
* ("Confidential Information"). You shall not disclose such Confidential
* Information and shall use it only in accordance with the terms of the
* license agreement you entered into with SAP.
*
*/
package de.hybris.platform.b2ctelcoaddon.forms;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;


/**
 * Validation form for Deleting a bundle.
 */
public class DeleteBundleForm
{
	@NotNull(message = "{basket.error.groupno.notNull}")
	@Min(value = 1, message = "{basket.error.groupno.invalid}")
	@Digits(fraction = 0, integer = 10, message = "{basket.error.groupno.invalid}")
	private int groupNumber;

	public int getGroupNumber()
	{
		return groupNumber;
	}

	public void setGroupNumber(final int groupNumber)
	{
		this.groupNumber = groupNumber;
	}

}
