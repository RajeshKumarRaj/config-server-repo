module.exports = function(grunt) {
  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    watch: {
        less: {
            files: ['webroot/WEB-INF/_ui-src/shared/less/variableMapping.less','webroot/WEB-INF/_ui-src/shared/less/generatedVariables.less',
                    'webroot/WEB-INF/_ui-src/responsive/lib/ybase-*/less/*', 'webroot/WEB-INF/_ui-src/**/themes/**/less/**/*.less'],
            tasks: ['less'],
        },
        fonts: {
            files: ['webroot/WEB-INF/_ui-src/**/themes/**/fonts/**'],
            tasks: ['sync:syncfonts'],
        },
        ybasejs: {
            files: ['webroot/WEB-INF/_ui-src/responsive/lib/ybase-0.1.0/js/**/*.js'],
            tasks: ['sync:syncybase'],
        },
        batelcojs: {
            files: ['webroot/WEB-INF/_ui-src/responsive/lib/batelco/*.js'],
            tasks: ['sync:syncbatelcojs'],
        },
        commonjs: {
          files: ['webroot/WEB-INF/_ui-src/responsive/lib/common/**/*.js'],
          tasks: ['sync:synccommonjs'],
        },
        jquery: {
            files: ['webroot/WEB-INF/_ui-src/responsive/lib/jquery*.js'],
            tasks: ['sync:syncjquery'],
        },
        addonfiles: {
          files: ['../../batelcoaddon/acceleratoraddon/web/webroot/WEB-INF/**'],
          tasks: ['sync:syncaddonfiles'],
        }
    },
    less: {
        default: {
            files: [
                {
                    expand: true,
                    cwd: 'webroot/WEB-INF/_ui-src/',
                    src: '**/themes/**/less/style.less',
                    dest: 'webroot/_ui/',
                    ext: '.css',
                    rename:function(dest,src){
                       var nsrc = src.replace(new RegExp("/themes/(.*)/less"),"/theme-$1/css");
                       return dest+nsrc;
                    }
                }
            ]
        },
    },

    sync : {
      syncaddonfiles: {
        files: [
          {
            expand: true,
            cwd: '../../batelcoaddon/acceleratoraddon/web/webroot/WEB-INF/tags/',
            src: '**',
            dest: 'webroot/WEB-INF/tags/addons/batelcoaddon/'
          },
          {
            expand: true,
            cwd: '../../batelcoaddon/acceleratoraddon/web/webroot/WEB-INF/views/',
            src: '**',
            dest: 'webroot/WEB-INF/views/addons/batelcoaddon/'
          },
          {
            expand: true,
            cwd: '../../batelcoaddon/acceleratoraddon/web/webroot/WEB-INF/messages/',
            src: '**',
            dest: 'webroot/WEB-INF/messages/addons/batelcoaddon/'
          }
        ]
      },
    	syncfonts: {
    		files: [{
                expand: true,
    			cwd: 'webroot/WEB-INF/_ui-src/',
    			src: '**/themes/**/fonts/**',
    			dest: 'webroot/_ui/',
    			rename:function(dest,src){
                	var nsrc = src.replace(new RegExp("/themes/(.*)"),"/theme-$1");
                	return dest+nsrc;
             }
    		}]
    	},
    	syncybase: {
    		files: [{
    			cwd: 'webroot/WEB-INF/_ui-src/responsive/lib/ybase-0.1.0/js/',
    			src: '**/*.js',
    			dest: 'webroot/_ui/responsive/common/js',
    		}]
    	},
    	syncjquery: {
    		files: [{
    			cwd: 'webroot/WEB-INF/_ui-src/responsive/lib',
    			src: 'jquery*.js',
    			dest: 'webroot/_ui/responsive/common/js',
    		}]
    	},
      nodemodulesjs: {
        files: [
          {cwd: 'node_modules/svg-injector/dist/', src: [ 'svg-injector.min.js' ], dest: 'webroot/WEB-INF/_ui-src/responsive/lib/common'},
          {cwd: 'node_modules/slick-carousel/', src: [ 'slick/**' ], dest: 'webroot/WEB-INF/_ui-src/responsive/lib/common', expand: true}
        ]
      },
      synccommonjs: {
        files: [{
          expand: true,
          cwd: 'webroot/WEB-INF/_ui-src/responsive/lib/common',
          src: '**',
          dest: 'webroot/_ui/responsive/common/js',
        }]
      },
      syncbatelcojs: {
        files: [{
          expand: true,
          cwd: 'webroot/WEB-INF/_ui-src/responsive/lib/batelco',
          src: '**',
          dest: 'webroot/_ui/responsive/common/js',
        }]
      }
    }

});

  // Plugins
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-sync');


  // Default task(s). Run 'grunt watch' to start the watching task or add 'watch' to the task list and run 'grunt'.
  grunt.registerTask('default', ['less', 'sync']);



};
