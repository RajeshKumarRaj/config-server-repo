package bt.batelco.storefront.constants;

/*
 * Constants used in the Web tier
 */
public class WebConstants {
  public static final String ERROR_TOKEN = "errorToken";
  public static final String ERROR_OBJECT = "error";

  private WebConstants () {

  }
}
