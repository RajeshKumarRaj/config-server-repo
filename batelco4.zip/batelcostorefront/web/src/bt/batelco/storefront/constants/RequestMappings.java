package bt.batelco.storefront.constants;

public class RequestMappings {
  /**
   * Contains error page request mappings.
   */
  public static final class ErrorPage {

    /**
     * Represents the URL pointing to the error page
     */
    public static final String PAGE_URL = "/error";
  }
}
