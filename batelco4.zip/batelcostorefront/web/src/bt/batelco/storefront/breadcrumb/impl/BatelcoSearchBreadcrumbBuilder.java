package bt.batelco.storefront.breadcrumb.impl;

import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.Breadcrumb;
import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.impl.SearchBreadcrumbBuilder;
import de.hybris.platform.catalog.model.classification.ClassificationClassModel;
import de.hybris.platform.category.model.CategoryModel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

/**
 * Custom Batelco search breadcrumb builder.
 */
public class BatelcoSearchBreadcrumbBuilder extends SearchBreadcrumbBuilder {

  private static final String LAST_LINK_CLASS = "active";

  @Override
  protected void createBreadcrumbCategoryHierarchyPath(String categoryCode, boolean emptyBreadcrumbs,
                                                       List<Breadcrumb> breadcrumbs) {
    final List<Breadcrumb> categoryBreadcrumbs = new ArrayList<>();
    final Collection<CategoryModel> categoryModels = new ArrayList<>();
    final CategoryModel lastCategoryModel = getCommerceCategoryService().getCategoryForCode(categoryCode);
    categoryModels.addAll(lastCategoryModel.getSupercategories());
    categoryBreadcrumbs.add(getCategoryBreadcrumb(lastCategoryModel, !emptyBreadcrumbs ? LAST_LINK_CLASS : ""));

    while (!categoryModels.isEmpty()) {
      final CategoryModel categoryModel = categoryModels.iterator().next();

      if (!(categoryModel instanceof ClassificationClassModel) && categoryModel != null &&
          CollectionUtils.isNotEmpty(categoryModel.getSupercategories())) {
        if (categoryModel.getVisible() == Boolean.TRUE) {
          categoryBreadcrumbs.add(getCategoryBreadcrumb(categoryModel));
        }

        categoryModels.clear();
        categoryModels.addAll(categoryModel.getSupercategories());
      } else {
        categoryModels.remove(categoryModel);
      }
    }

    Collections.reverse(categoryBreadcrumbs);
    breadcrumbs.addAll(categoryBreadcrumbs);
  }
}
