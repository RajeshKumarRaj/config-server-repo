package bt.batelco.storefront.filters;


import org.apache.logging.log4j.ThreadContext;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * LoggerFilter to add additional information in the log files
 */
public class LoggerFilter extends OncePerRequestFilter {

  private static final String SESSION_ID = "SessionID";
  private static final String REMOTE_ADDR = "RemoteAddr";
  private static final String NONE = "N/A";
  private static final String X_FORWARDED_FOR_HEADER = "X-FORWARDED-FOR";

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                  FilterChain filterChain) throws ServletException, IOException {
    HttpSession session = request.getSession(false);
    if (session != null) {
      ThreadContext.put(SESSION_ID, generateCustomSessionIdentifier(session.getId()));
    } else {
      ThreadContext.put(SESSION_ID, NONE);
    }
    ThreadContext.put(REMOTE_ADDR, getIpAddress(request));

    try {
      filterChain.doFilter(request, response);
    } finally {
      ThreadContext.remove(SESSION_ID);
      ThreadContext.remove(REMOTE_ADDR);
    }
  }

  /**
   * Gets the ip address of the request, based on the -Forwarded-For header
   * If the header is missing it falls back to request.getRemoteAddr()
   *
   * @param request the http request
   * @return ip address (string)
   */
  private String getIpAddress(HttpServletRequest request) {
    String ipAddress = request.getHeader(X_FORWARDED_FOR_HEADER);
    return ipAddress == null ? request.getRemoteAddr() : ipAddress;
  }

  @Override
  public void destroy() {
    // nothing to do here
  }

  /**
   * This method returns the first half from the real session id.
   *
   * @return a custom identifier for the user session
   */
  private String generateCustomSessionIdentifier(String sessionId) {
    return sessionId.substring(0, sessionId.length() / 2);
  }

}

