package bt.batelco.storefront.filters;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bt.batelco.storefront.constants.RequestMappings;
import bt.batelco.storefront.constants.WebConstants;

public class HandleUncaughtExceptionFilter extends OncePerRequestFilter {

  private static final Logger LOG = LoggerFactory.getLogger(HandleUncaughtExceptionFilter.class);

  @Override
  protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                                  FilterChain filterChain) throws IOException {
    try {
      filterChain.doFilter(httpServletRequest, httpServletResponse);
    } catch (Exception e) {
      processError(e, httpServletRequest);
      httpServletResponse.sendRedirect(httpServletRequest.getContextPath() + RequestMappings.ErrorPage.PAGE_URL);
    }
  }

  private void processError(Exception e, HttpServletRequest httpServletRequest) {
    String errorToken = UUID.randomUUID().toString();
    logException(e, errorToken);

    HttpSession session = httpServletRequest.getSession();
    session.setAttribute(WebConstants.ERROR_TOKEN, errorToken);
    session.setAttribute(WebConstants.ERROR_OBJECT, e);
  }

  private void logException(Exception e, String errorToken) {
    LOG.error(String.format("Server error with error token %s", errorToken), e);

    Throwable rootCause = ExceptionUtils.getRootCause(e);
    LOG.error(String.format("Cause for above exception with associated error token: %s", errorToken), rootCause);
    String errorStackTrace = ExceptionUtils.getFullStackTrace(e);
    LOG.error(String.format("The full stack trace of errors for error token %s: %s", errorToken, errorStackTrace));
  }

}
