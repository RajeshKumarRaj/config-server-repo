package bt.batelco.storefront.filters;

import de.hybris.platform.servicelayer.web.WebAppMediaFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Webapp filter to handle custom media [Specific to facebook feed], rest of the requests are delegated to OOTB WebAppMediaFilter
 */
public class BatelcoWebAppMediaFilter extends WebAppMediaFilter {

    private static final Logger LOG = Logger.getLogger(BatelcoWebAppMediaFilter.class);

    private String facebookFeedUrlResourcePath;

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        super.doFilter(request, response, chain);
    }

    protected boolean isMedia(String resourcePath) {
        if (StringUtils.containsIgnoreCase(resourcePath, getFacebookFeedUrlResourcePath())) {
            LOG.debug(resourcePath + "contains" +getFacebookFeedUrlResourcePath());
            return true;
        } else {
            return super.isMedia(resourcePath);
        }
    }

    /**
     * If the resource matches the batelco feeds Media resource path, considered as secure.
     *  For rest of the media, request is delegated to OOTB.
     * @param resourcePath
     *          Resourcepath of the request
     * @return
     *      returns boolean
     */
    protected boolean isSecureMedia(String resourcePath) {
        if (StringUtils.containsIgnoreCase(resourcePath, getFacebookFeedUrlResourcePath())) {
            LOG.debug(resourcePath + "contains" +getFacebookFeedUrlResourcePath());
            return true;
        } else {
            return super.isSecureMedia(resourcePath);
        }
    }

    public String getFacebookFeedUrlResourcePath() {
        return facebookFeedUrlResourcePath;
    }

    @Required
    public void setFacebookFeedUrlResourcePath(String facebookFeedUrlResourcePath) {
        this.facebookFeedUrlResourcePath = facebookFeedUrlResourcePath;
    }

}