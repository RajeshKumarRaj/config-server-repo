package bt.batelco.storefront.tags;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

import de.hybris.platform.commercefacades.product.data.CategoryData;
import de.hybris.platform.commercefacades.product.data.ImageData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.VariantMatrixElementData;
import de.hybris.platform.commercefacades.product.data.VariantOptionQualifierData;
import de.hybris.platform.subscriptionfacades.data.BillingTimePriceData;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This class contains static pure function.
 */
public final class Functions {
  private static final Logger LOG = Logger.getLogger(Functions.class);
  private static final String PREORDER_PAYNOW_CODE = "preorderPaynow";

  private Functions() {
    throw new IllegalStateException("Utility class");
  }

  /**
   * Formats a phone number based on the given country iso code.
   *
   * @param phoneNumber the given phone number
   * @param isoCode     the given country iso code
   * @return the formatted phone number
   */
  public static String formatPhoneNumber(String phoneNumber, String isoCode) {
    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
    PhoneNumber formattedPhoneNumber = new PhoneNumber();

    try {
      phoneUtil.parse(phoneNumber, isoCode, formattedPhoneNumber);
    } catch (NumberParseException e) {
      LOG.error("The phone number could not be updated.");
      LOG.error(e);
    }

    return phoneUtil.format(formattedPhoneNumber, PhoneNumberFormat.INTERNATIONAL);
  }

  /**
   * Split categories in base categories and variant categories.
   *
   * @param categories     list of CategoryData
   * @return splited categories
   */
  public static Map<String, Set<String>> splitCategories(final List<? extends CategoryData> categories) {
    return categories.stream().collect(
        Collectors.groupingBy(CategoryData::getType,
                              Collectors.mapping(CategoryData::getName, Collectors.toSet())
        )
    );
  }

  /**
   * Gets prices to be displayed. In case of preorder, a filtering is made.
   *
   * @param isPreorder preorder flag
   * @param prices     list of BillingTimePriceData
   * @return order prices
   */
  public static List<? extends BillingTimePriceData> getPrices(boolean isPreorder,
                                                               List<? extends BillingTimePriceData> prices) {
    if (isPreorder) {
      return prices.stream()
          .filter(orderPriceData -> orderPriceData.getBillingTime() != null )
          .filter(orderPriceData -> PREORDER_PAYNOW_CODE.equalsIgnoreCase(orderPriceData.getBillingTime().getCode()))
          .collect(Collectors.toList());
    }

    return prices;
  }

  /**
   * JSP EL Function to get an image for a Product in a specific format based on the product code.
   *
   * @param product     The product.
   * @param productCode The desired product code.
   * @param format      The desired format.
   * @return The image.
   */
  public static ImageData getImageForProductCode(final ProductData product, final String productCode,
                                                 final String format) {
    if (product != null && productCode != null && format != null) {
      return getImageData(product, productCode, format);
    }
    return null;
  }

  private static ImageData getImageData(final ProductData product, final String productCode, final String format) {
    int selectedIndex = 0;

    for (int i = 1; i <= product.getCategories().size(); i++) {
      int j = 0;
      final List<VariantMatrixElementData> theMatrix;

      if (i == 1 || CollectionUtils.isEmpty(product.getVariantMatrix().get(selectedIndex).getElements())) {
        theMatrix = product.getVariantMatrix();
      } else {
        theMatrix = product.getVariantMatrix().get(selectedIndex).getElements();
        selectedIndex = 0;
      }

      if (theMatrix.get(selectedIndex).getParentVariantCategory().getHasImage()) {
        for (final VariantMatrixElementData matrixElementData : theMatrix) {
          if (matrixElementData.getVariantOption().getVariantOptionQualifiers() != null
              && productCode.equals(matrixElementData.getVariantOption().getCode())) {
            for (final VariantOptionQualifierData variantOption : matrixElementData.getVariantOption()
                .getVariantOptionQualifiers()) {
              if (format.equals(variantOption.getImage().getFormat())) {
                return variantOption.getImage();
              }
            }
            selectedIndex = j;
          }

          j++;
        }
      }
    }
    return null;
  }


}

