package bt.batelco.storefront.pdf.util;

public class PDFFieldnameAndCoordinates {
	
	String fieldName;
	
	float offsetX;
	float offsetY;
	
	float width;
	float height;
	
	public PDFFieldnameAndCoordinates() {
		super();
	}
	
	public PDFFieldnameAndCoordinates(String fieldName, float offsetX, float offsetY) {
		super();
		this.fieldName = fieldName;
		this.offsetX = offsetX;
		this.offsetY = offsetY;
	}
	
	public PDFFieldnameAndCoordinates(String fieldName, float offsetX, float offsetY, float width, float height) {
		super();
		this.fieldName = fieldName;
		this.offsetX = offsetX;
		this.offsetY = offsetY;
		this.width = width;
		this.height = height;
	}

	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public float getOffsetX() {
		return offsetX;
	}
	public void setOffsetX(float offsetX) {
		this.offsetX = offsetX;
	}
	public float getOffsetY() {
		return offsetY;
	}
	public void setOffsetY(float offsetY) {
		this.offsetY = offsetY;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

}
