package bt.batelco.storefront.pdf.util;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream.AppendMode;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.text.PDFTextStripper;

import sun.misc.BASE64Decoder;

public class PDFUtils {
	
	private static Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
	
	public PDFGeneratedStreamData generatePDFDocumentFromStream(InputStream inputStream, AcquisitionForm documentData, 
			int cartEntryNumber, String documentType) {
		
		System.out.println("*** PDFUtils == generatePDFDocument() Method *****");
		
		PDFCoordinateMapper coordinateMapper = new PDFCoordinateMapper();
		PDFGeneratedStreamData pdfGeneratedStreamData = new PDFGeneratedStreamData();
		if(documentType.equalsIgnoreCase(PDFConstants.POSTPAID) 
				|| documentType.equalsIgnoreCase(PDFConstants.MOBILE_INTERNET)) {
			fieldMapper = coordinateMapper.getFieldNameAndCoordinatePostpaid();
			pdfGeneratedStreamData = generatePDFDocumentForPostpaid(inputStream, documentData, cartEntryNumber);
		}else if(documentType.equalsIgnoreCase(PDFConstants.MOBILE)) {
			fieldMapper = coordinateMapper.getFieldNameAndCoordinateMobile();
			pdfGeneratedStreamData = generatePDFDocumentForMobileDevice(inputStream, documentData, cartEntryNumber);
		}else if(documentType.equalsIgnoreCase(PDFConstants.HOME_INTERNET)) {
			fieldMapper = coordinateMapper.getFieldNameAndCoordinateFixedLineAndHomeInternet();
			pdfGeneratedStreamData = generatePDFDocumentForHomeInternetFixedLine(inputStream, documentData, cartEntryNumber);
		}else {
			
		}
		
		return pdfGeneratedStreamData;
	}

	private PDFGeneratedStreamData generatePDFDocumentForPostpaid(InputStream inputStream, AcquisitionForm acquisitionForm, 
			int cartEntryNumber) {
		PDFGeneratedStreamData pdfGeneratedStreamData = new PDFGeneratedStreamData();
		
		/*String directory = "D:\\Ananth\\PDFGenerateTesting";
		String generatedFileName = "Generated_"+PDFConstants.MOBILE+"_applicationForm_"+cartEntryNumber+".pdf";
		String targetPdf = directory+File.separator+generatedFileName;*/
		
		try {
			
			PDDocument document = PDDocument.load(inputStream);
			PDPage page1 = document.getPage(0);

			PDPageContentStream contentStream = new PDPageContentStream(document, page1, AppendMode.APPEND, true);
			contentStream.setFont(PDType1Font.COURIER, 9);
			
			//Request Type
			if(acquisitionForm.getRequestType().equalsIgnoreCase("New")) {
				writeTextToPdf(contentStream, "newCustomer", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("changeOfPackage")) {
				writeTextToPdf(contentStream, "changeOfPackage", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("renewContract")) {
				writeTextToPdf(contentStream, "renewContract", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("changeOfAddress")) {
				writeTextToPdf(contentStream, "changeOfAddress", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("miscellaneous")) {
				writeTextToPdf(contentStream, "miscellaneous", "X");
			}else {
				// Number Portability
				writeTextToPdf(contentStream, "numberPortability", "X");
			}
			
			//Personal Details -- START
			if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
				writeTextToPdf(contentStream, "name", acquisitionForm.getCustomerName().trim());
			}
			
			if(acquisitionForm.getCustomerNationality() != null && (acquisitionForm.getCustomerNationality().length() > 0)) {
				writeTextToPdf(contentStream, "nationality", acquisitionForm.getCustomerNationality().trim());
			}
			
			if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
				writeTextToPdf(contentStream, "cprNo", acquisitionForm.getCustomerCprId().trim());
			}
			
			if(acquisitionForm.getCustomerCrId() != null && (acquisitionForm.getCustomerCrId().length() > 0)) {
				writeTextToPdf(contentStream, "crNo", acquisitionForm.getCustomerCrId().trim());
			}
			
			if(acquisitionForm.getCustomerMobileNumber() != null && (acquisitionForm.getCustomerMobileNumber().length() > 0)) {
				writeTextToPdf(contentStream, "mobileNumber", acquisitionForm.getCustomerMobileNumber().trim());
			}
			
			if(acquisitionForm.getCustomerContactName() != null && (acquisitionForm.getCustomerContactName().length() > 0)) {
				writeTextToPdf(contentStream, "contactName", acquisitionForm.getCustomerContactName().trim());
			}
			
			if(acquisitionForm.getCustomerContactNumber() != null && (acquisitionForm.getCustomerContactNumber().length() > 0)) {
				writeTextToPdf(contentStream, "contactNumber", acquisitionForm.getCustomerContactNumber().trim());
			}
			
			//Personal Details -- END
			//Adderess Details -- START
			
			if(acquisitionForm.getAddressFlatNo() != null && (acquisitionForm.getAddressFlatNo().length() > 0)) {
				writeTextToPdf(contentStream, "flatNo", acquisitionForm.getAddressFlatNo().trim());
			}
			
			if(acquisitionForm.getAddressBuilding() != null && (acquisitionForm.getAddressBuilding().length() > 0)) {
				writeTextToPdf(contentStream, "houseOrBuildingNo", acquisitionForm.getAddressBuilding().trim());
			}
			
			if(acquisitionForm.getAddressRoad() != null && (acquisitionForm.getAddressRoad().length() > 0)) {
				writeTextToPdf(contentStream, "roadOrStreetName", acquisitionForm.getAddressRoad().trim());
			}
			
			if(acquisitionForm.getAddressBlock() != null && (acquisitionForm.getAddressBlock().length() > 0)) {
				writeTextToPdf(contentStream, "blockNo", acquisitionForm.getAddressBlock().trim());
			}
			
			if(acquisitionForm.getCustomerEmail() != null && (acquisitionForm.getCustomerEmail().length() > 0)) {
				writeTextToPdf(contentStream, "emailId", acquisitionForm.getCustomerEmail().trim());
			}
			//Adderess Details -- END
			//Telephone Dorectory Details -- START
			
			if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("Yes") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
				writeTextToPdf(contentStream, "teleDirYesCHk", "X");
			}else if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("No") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
				writeTextToPdf(contentStream, "teleDirNoChk", "X");
			}
			
			if(acquisitionForm.getMobilePackage() != null && (acquisitionForm.getMobilePackage().length() > 0)) {
				writeTextToPdf(contentStream, "mpOthersChk", "X");
				writeTextToPdf(contentStream, "mpOthersText", acquisitionForm.getMobilePackage().trim());
			}
			//Telephone Dorectory Details -- END

			contentStream.close();
			
			// signature
			PDPage page3 = document.getPage(2);
			PDPageContentStream contentStream1 = new PDPageContentStream(document, page3, AppendMode.APPEND, true);
			contentStream1.setFont(PDType1Font.COURIER, 9);
			
			String dateTime = new java.text.SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss").format(new java.util.Date());
			
			if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
				writeTextToPdf(contentStream1, "agreeAppName", acquisitionForm.getCustomerName().trim());
			}
			
			writeTextToPdf(contentStream1, "agreeDate", dateTime.trim());
			
			if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
				writeTextToPdf(contentStream1, "agreeIDNo", acquisitionForm.getCustomerCprId().trim());
			}
			
			if(acquisitionForm.getSignImageData() != null && (acquisitionForm.getSignImageData().length() > 0)) {
				writeImageToPdf(document, contentStream1, "agreeCustomerSign", acquisitionForm.getSignImageData());
			}
			contentStream1.close();
			
			String fileName = "Mobile-Postpaid-"+acquisitionForm.getMobilePackage().trim();
			String fileExt = ".pdf";
			String filePath = fileName+fileExt;
			
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			document.save(byteArrayOutputStream);
			InputStream pdfInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			
			pdfGeneratedStreamData.setEntryNumber(cartEntryNumber);
			pdfGeneratedStreamData.setDocumentName(filePath);
			pdfGeneratedStreamData.setPdfInputStream(pdfInputStream);
			
			//document.save(targetPdf);
			document.save(new File(filePath));
			document.close();
			System.out.println("Updated PDF Document Successfully Generated!!!");
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		
		return pdfGeneratedStreamData;
	}
	
	//For Mobile Device
		private PDFGeneratedStreamData generatePDFDocumentForMobileDevice(InputStream inputStream, AcquisitionForm acquisitionForm, 
				int cartEntryNumber) {
			PDFGeneratedStreamData pdfGeneratedStreamData = new PDFGeneratedStreamData();
			
			/*String directory = "D:\\Ananth\\PDFGenerateTesting";
			String generatedFileName = "Generated_"+PDFConstants.MOBILE+"_applicationForm_"+cartEntryNumber+".pdf";
			String targetPdf = directory+File.separator+generatedFileName;*/
			
			try {
				
				PDDocument document = PDDocument.load(inputStream);
				PDPage page1 = document.getPage(0);

				PDPageContentStream contentStream = new PDPageContentStream(document, page1, AppendMode.APPEND, true);
				contentStream.setFont(PDType1Font.COURIER, 9);
				
				//Request Type
				if(acquisitionForm.getRequestType().equalsIgnoreCase("New")) {
					writeTextToPdf(contentStream, "newCustomer", "X");
				}else if(acquisitionForm.getRequestType().equalsIgnoreCase("changeOfPackage")) {
					writeTextToPdf(contentStream, "changeOfPackage", "X");
				}else if(acquisitionForm.getRequestType().equalsIgnoreCase("renewContract")) {
					writeTextToPdf(contentStream, "renewContract", "X");
				}else if(acquisitionForm.getRequestType().equalsIgnoreCase("changeOfAddress")) {
					writeTextToPdf(contentStream, "changeOfAddress", "X");
				}else if(acquisitionForm.getRequestType().equalsIgnoreCase("miscellaneous")) {
					writeTextToPdf(contentStream, "miscellaneous", "X");
				}else {
					// Number Portability
					writeTextToPdf(contentStream, "numberPortability", "X");
				}
				
				//Personal Details -- START
				if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
					writeTextToPdf(contentStream, "name", acquisitionForm.getCustomerName().trim());
				}
				
				if(acquisitionForm.getCustomerNationality() != null && (acquisitionForm.getCustomerNationality().length() > 0)) {
					writeTextToPdf(contentStream, "nationality", acquisitionForm.getCustomerNationality().trim());
				}
				
				if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
					writeTextToPdf(contentStream, "cprNo", acquisitionForm.getCustomerCprId().trim());
				}
				
				if(acquisitionForm.getCustomerCrId() != null && (acquisitionForm.getCustomerCrId().length() > 0)) {
					writeTextToPdf(contentStream, "crNo", acquisitionForm.getCustomerCrId().trim());
				}
				
				if(acquisitionForm.getCustomerMobileNumber() != null && (acquisitionForm.getCustomerMobileNumber().length() > 0)) {
					writeTextToPdf(contentStream, "mobileNumber", acquisitionForm.getCustomerMobileNumber().trim());
				}
				
				if(acquisitionForm.getCustomerContactName() != null && (acquisitionForm.getCustomerContactName().length() > 0)) {
					writeTextToPdf(contentStream, "contactName", acquisitionForm.getCustomerContactName().trim());
				}
				
				if(acquisitionForm.getCustomerContactNumber() != null && (acquisitionForm.getCustomerContactNumber().length() > 0)) {
					writeTextToPdf(contentStream, "contactNumber", acquisitionForm.getCustomerContactNumber().trim());
				}
				
				//Personal Details -- END
				//Adderess Details -- START
				
				if(acquisitionForm.getAddressFlatNo() != null && (acquisitionForm.getAddressFlatNo().length() > 0)) {
					writeTextToPdf(contentStream, "flatNo", acquisitionForm.getAddressFlatNo().trim());
				}
				
				if(acquisitionForm.getAddressBuilding() != null && (acquisitionForm.getAddressBuilding().length() > 0)) {
					writeTextToPdf(contentStream, "houseOrBuildingNo", acquisitionForm.getAddressBuilding().trim());
				}
				
				if(acquisitionForm.getAddressRoad() != null && (acquisitionForm.getAddressRoad().length() > 0)) {
					writeTextToPdf(contentStream, "roadOrStreetName", acquisitionForm.getAddressRoad().trim());
				}
				
				if(acquisitionForm.getAddressBlock() != null && (acquisitionForm.getAddressBlock().length() > 0)) {
					writeTextToPdf(contentStream, "blockNo", acquisitionForm.getAddressBlock().trim());
				}
				
				if(acquisitionForm.getCustomerEmail() != null && (acquisitionForm.getCustomerEmail().length() > 0)) {
					writeTextToPdf(contentStream, "emailId", acquisitionForm.getCustomerEmail().trim());
				}
				//Adderess Details -- END
				//Telephone Dorectory Details -- START
				
				if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("Yes") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
					writeTextToPdf(contentStream, "teleDirYesCHk", "X");
				}else if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("No") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
					writeTextToPdf(contentStream, "teleDirNoChk", "X");
				}
				
				if(acquisitionForm.getMobilePackage() != null && (acquisitionForm.getMobilePackage().length() > 0)) {
					writeTextToPdf(contentStream, "mpOthersChk", "X");
					writeTextToPdf(contentStream, "mpOthersText", acquisitionForm.getMobilePackage().trim());
				}
				//Telephone Dorectory Details -- END
				
				//Mobile Device Details -- START
				
				if(acquisitionForm.getProductBrand() != null && (acquisitionForm.getProductBrand().length() > 0)) {
					writeTextToPdf(contentStream, "hiBrand", acquisitionForm.getProductBrand().trim());
				}
				if(acquisitionForm.getProductModel() != null && (acquisitionForm.getProductModel().length() > 0)) {
					writeTextToPdf(contentStream, "hiModel", acquisitionForm.getProductModel().trim());
				}
				
				if(acquisitionForm.getProductContractTerm() != null && acquisitionForm.getProductContractTerm().equalsIgnoreCase("12 Months") && (acquisitionForm.getProductContractTerm().length() > 0) ){
					writeTextToPdf(contentStream, "hiContractTerm12", "X");
				}else if(acquisitionForm.getProductContractTerm() != null && acquisitionForm.getProductContractTerm().equalsIgnoreCase("18 Months") && (acquisitionForm.getProductContractTerm().length() > 0)){
					writeTextToPdf(contentStream, "hiContractTerm18", "X");
				}else if(acquisitionForm.getProductContractTerm() != null && acquisitionForm.getProductContractTerm().equalsIgnoreCase("24 Months") && (acquisitionForm.getProductContractTerm().length() > 0)){
					writeTextToPdf(contentStream, "hiContractTerm24", "X");
				}
				//Mobile Device Details -- END

				contentStream.close();
				
				// signature
				PDPage page3 = document.getPage(2);
				PDPageContentStream contentStream1 = new PDPageContentStream(document, page3, AppendMode.APPEND, true);
				contentStream1.setFont(PDType1Font.COURIER, 9);
				
				String dateTime = new java.text.SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss").format(new java.util.Date());
				
				if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
					writeTextToPdf(contentStream1, "agreeAppName", acquisitionForm.getCustomerName().trim());
				}
				
				writeTextToPdf(contentStream1, "agreeDate", dateTime.trim());
				
				if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
					writeTextToPdf(contentStream1, "agreeIDNo", acquisitionForm.getCustomerCprId().trim());
				}
				
				if(acquisitionForm.getSignImageData() != null && (acquisitionForm.getSignImageData().length() > 0)) {
					writeImageToPdf(document, contentStream1, "agreeCustomerSign", acquisitionForm.getSignImageData());
				}
				
				contentStream1.close();
				
				String product = acquisitionForm.getProductBrand()+acquisitionForm.getProductModel();
				String fileName = "Mobile-Device-"+product;
				String fileExt = ".pdf";
				String filePath = fileName+fileExt;
				
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				document.save(byteArrayOutputStream);
				InputStream pdfInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
				
				pdfGeneratedStreamData.setEntryNumber(cartEntryNumber);
				pdfGeneratedStreamData.setDocumentName(filePath);
				pdfGeneratedStreamData.setPdfInputStream(pdfInputStream);
				
				//document.save(targetPdf);
				document.save(new File(filePath));
				document.close();
				System.out.println("Updated PDF Document Successfully Generated!!!");
				
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
			return pdfGeneratedStreamData;
		}

	private PDFGeneratedStreamData generatePDFDocumentForHomeInternetFixedLine(InputStream inputStream,
			AcquisitionForm acquisitionForm, int cartEntryNumber) {
		PDFGeneratedStreamData pdfGeneratedStreamData = new PDFGeneratedStreamData();
		
		try {
			
			PDDocument document = PDDocument.load(inputStream);
			PDPage page1 = document.getPage(0);

			PDPageContentStream contentStream = new PDPageContentStream(document, page1, AppendMode.APPEND, true);
			contentStream.setFont(PDType1Font.COURIER, 9);
			contentStream.setNonStrokingColor(Color.BLACK);
			
			//Request Type
			if(acquisitionForm.getRequestType().equalsIgnoreCase("New")) {
				writeTextToPdf(contentStream, "requestTypeNew", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("upgradeDowngrade")) {
				writeTextToPdf(contentStream, "requestTypeUpgrade", "X");
			}else {
				// Number Portability
				writeTextToPdf(contentStream, "numberPortability", "X");
			}
			
			//Personal Details -- START
			if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
				writeTextToPdf(contentStream, "customerName", acquisitionForm.getCustomerName().trim());
				writeTextToPdf(contentStream, "broadBandAgreeName", acquisitionForm.getCustomerName().trim());
			}
			
			if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
				writeTextToPdf(contentStream, "customerIdNumber", acquisitionForm.getCustomerCprId().trim());
			}
			
			if(acquisitionForm.getCustomerContactNumber() != null && (acquisitionForm.getCustomerContactNumber().length() > 0)) {
				writeTextToPdf(contentStream, "customerContactNumber", acquisitionForm.getCustomerContactNumber().trim());
			}
			
			if(acquisitionForm.getCustomerEmail() != null && (acquisitionForm.getCustomerEmail().length() > 0)) {
				writeTextToPdf(contentStream, "customerContactEmail", acquisitionForm.getCustomerEmail().trim());
			}
			
			if(acquisitionForm.getCircuitNumber() != null && (acquisitionForm.getCircuitNumber().length() > 0)) {
				writeTextToPdf(contentStream, "customerCircuitNumber", acquisitionForm.getCircuitNumber().trim());
			}
			
			if(acquisitionForm.getPreferredLang() != null && acquisitionForm.getPreferredLang().equalsIgnoreCase("Yes") && (acquisitionForm.getPreferredLang().length() > 0)) {
				writeTextToPdf(contentStream, "customerPreferredLangArabicChk", "X");
			}else if(acquisitionForm.getPreferredLang() != null && acquisitionForm.getPreferredLang().equalsIgnoreCase("No") && (acquisitionForm.getPreferredLang().length() > 0)) {
				writeTextToPdf(contentStream, "customerPreferredLangEnglishChk", "X");
			}
			
			if(acquisitionForm.getActivateEBilling() != null && (acquisitionForm.getActivateEBilling().length() > 0)) {
				writeTextToPdf(contentStream, "customerActivateEBillChk", "X");
			}
			
			if(acquisitionForm.getProductName() != null && (acquisitionForm.getProductName().length() > 0)) {
				//Product Name == Superfast 100 Mbps (1 TB)
				if(acquisitionForm.getProductName().contains("20")) {
					writeTextToPdf(contentStream, "valuePack202mbChk", "X");
				}else if(acquisitionForm.getProductName().contains("30")) {
					writeTextToPdf(contentStream, "valuePack305mbChk", "X");
				}else if(acquisitionForm.getProductName().contains("100")) {
					writeTextToPdf(contentStream, "valuePack10010mbChk", "X");
				}else {
					writeTextToPdf(contentStream, "valuePack50050mbChk", "X");
				}
			}
			
			if(acquisitionForm.getSignImageData() != null && (acquisitionForm.getSignImageData().length() > 0)) {
				writeImageToPdf(document, contentStream, "broadBandAgreeSignature", acquisitionForm.getSignImageData());
			}
			
			String dateTime = new java.text.SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss").format(new java.util.Date());
			writeTextToPdf(contentStream, "broadBandAgreeDate", dateTime.trim());
			
			contentStream.close();
			
			PDPage page4 = document.getPage(3);

			PDPageContentStream contentStream1 = new PDPageContentStream(document, page4, AppendMode.APPEND, true);
			contentStream1.setFont(PDType1Font.COURIER, 9);
			contentStream1.setNonStrokingColor(Color.BLACK);
			
			if(acquisitionForm.getRequestType().equalsIgnoreCase("New")) {
				writeTextToPdf(contentStream1, "fixedLineNewLineTelChk", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("NewISDN")) {
				writeTextToPdf(contentStream1, "fixedLineNewLineISDNChk", "X");
			}else if(acquisitionForm.getRequestType().equalsIgnoreCase("ValueAddedService")) {
				writeTextToPdf(contentStream1, "fixedLineValueAddedServiceChk", "X");
			}else {
				writeTextToPdf(contentStream1, "fixedLineCeaseLine", "X");
			}
			
			if(acquisitionForm.getCustomerEmail() != null && (acquisitionForm.getCustomerEmail().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineCustomerEmail", acquisitionForm.getCustomerEmail().trim());
			}
			
			if(acquisitionForm.getCustomerContactName() != null && (acquisitionForm.getCustomerContactName().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineContactName", acquisitionForm.getCustomerContactName().trim());
			}
			
			if(acquisitionForm.getCustomerContactNumber() != null && (acquisitionForm.getCustomerContactNumber().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineContactNumber", acquisitionForm.getCustomerContactNumber().trim());
			}
			
			if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineCustomerName", acquisitionForm.getCustomerName().trim());
			}
			
			if(acquisitionForm.getCustomerNationality() != null && (acquisitionForm.getCustomerNationality().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineNationality", acquisitionForm.getCustomerNationality().trim());
			}
			
			if(acquisitionForm.getCustomerCprId() != null && (acquisitionForm.getCustomerCprId().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineCPRIDNo", acquisitionForm.getCustomerCprId().trim());
			}
			
			if(acquisitionForm.getCustomerCrId() != null && (acquisitionForm.getCustomerCrId().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineCRNo", acquisitionForm.getCustomerCrId().trim());
			}
			
			if(acquisitionForm.getAddressBuilding() != null && (acquisitionForm.getAddressBuilding().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineLocalHouseOrBuilding", acquisitionForm.getAddressBuilding().trim());
			}
			
			if(acquisitionForm.getAddressRoad() != null && (acquisitionForm.getAddressRoad().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineLocalRoadOrStreet", acquisitionForm.getAddressRoad().trim());
			}
			
			if(acquisitionForm.getAddressBlock() != null && (acquisitionForm.getAddressBlock().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineLocalBlockNo", acquisitionForm.getAddressBlock().trim());
			}
			
			if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("Yes") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineTeleDirYesChk", "X");
			}else if(acquisitionForm.getTelephoneDirectory() != null && acquisitionForm.getTelephoneDirectory().equalsIgnoreCase("No") && (acquisitionForm.getTelephoneDirectory().length() > 0)) {
				writeTextToPdf(contentStream1, "fixedLineTeleDirNoChk", "X");
			}
			
			contentStream1.close();
			
			PDPage page5 = document.getPage(4);

			PDPageContentStream contentStream2 = new PDPageContentStream(document, page5, AppendMode.APPEND, true);
			contentStream2.setFont(PDType1Font.COURIER, 9);
			contentStream2.setNonStrokingColor(Color.BLACK);
			
			if(acquisitionForm.getCustomerName() != null && (acquisitionForm.getCustomerName().length() > 0)) {
				writeTextToPdf(contentStream2, "fixedLineAgreeCustName", acquisitionForm.getCustomerName().trim());
			}
			
			writeTextToPdf(contentStream2, "fixedLineAgreeCustDate",dateTime.trim());
			
			if(acquisitionForm.getSignImageData() != null && (acquisitionForm.getSignImageData().length() > 0)) {
				writeImageToPdf(document, contentStream2, "fixedLineAgreeCustSignature", acquisitionForm.getSignImageData());
			}
			
			contentStream2.close();
			
			String product = acquisitionForm.getProductName();
			String fileName = "FixedLine+HomeInternet-"+product;
			String fileExt = ".pdf";
			String filePath = fileName+fileExt;
			
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			document.save(byteArrayOutputStream);
			InputStream pdfInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			
			pdfGeneratedStreamData.setEntryNumber(cartEntryNumber);
			pdfGeneratedStreamData.setDocumentName(filePath);
			pdfGeneratedStreamData.setPdfInputStream(pdfInputStream);
			
			/*contentStream1.close();*/
			
			//document.save(targetPdf);
			document.save(new File(filePath));
			document.close();
			System.out.println("Updated PDF Document Successfully Generated!!!");
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		
		return pdfGeneratedStreamData;
	}
	
	private void writeTextToPdf(PDPageContentStream contentStream, String key, String value) throws IOException {
		
		System.out.println("*** PDFUtils == writeTextToPdf() Method Key == "+key+" Value == "+value);
		
		PDFFieldnameAndCoordinates fieldOffset = fieldMapper.get(key);
		float offsetX = fieldOffset.getOffsetX();
		float offsetY = fieldOffset.getOffsetY();
		
		contentStream.beginText();
		contentStream.newLineAtOffset(offsetX, offsetY);
		contentStream.showText(value);
		contentStream.endText();
	
	}
	
	private void writeImageToPdf(PDDocument document, PDPageContentStream contentStream, String key, String value) throws IOException {
		System.out.println("*** PDFUtils == writeImageToPdf() Method Key == "+key);
		
		PDFFieldnameAndCoordinates fieldOffset = fieldMapper.get(key);
		float offsetX = fieldOffset.getOffsetX();
		float offsetY = fieldOffset.getOffsetY();
		float width = fieldOffset.getWidth();
		float height = fieldOffset.getHeight();
		
		BufferedImage bufferedImage = decodeToImage(value);
		PDImageXObject image = LosslessFactory.createFromImage(document, bufferedImage);
		
		contentStream.drawImage(image, offsetX, offsetY, width, height);
		//contentStream.close();
	}
	
	private BufferedImage decodeToImage(String imageString) {
		 
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return image;
    }
	
	public static void readPDFDocument(String filePath) {
		try {
			System.out.println("PDF Utils === FilePath === "+filePath);
			
			File file = new File(filePath);
			PDDocument document = PDDocument.load(file);
			PDFTextStripper pdfStripper = new PDFTextStripper();
			String text = pdfStripper.getText(document);
			System.out.println(text);
		    document.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void readPDFDocumentFile(File file) {
		try {
			System.out.println("PDF Utils === readPDFDocumentFile === ");
			//File file = new File(filePath);
			PDDocument document = PDDocument.load(file);
			PDFTextStripper pdfStripper = new PDFTextStripper();
			String text = pdfStripper.getText(document);
			System.out.println(text);
		    document.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void readPDFDocumentStream(InputStream inputStream) {
		try {
			System.out.println("PDF Utils === InputStream === "+inputStream);
			
			PDDocument document = PDDocument.load(inputStream);
			PDFTextStripper pdfStripper = new PDFTextStripper();
			String text = pdfStripper.getText(document);
			System.out.println(text);
		    document.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
