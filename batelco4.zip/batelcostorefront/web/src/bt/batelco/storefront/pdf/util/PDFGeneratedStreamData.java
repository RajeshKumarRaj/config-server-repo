package bt.batelco.storefront.pdf.util;

import java.io.File;
import java.io.InputStream;

public class PDFGeneratedStreamData {
	
	int entryNumber;
	String documentName;
	InputStream pdfInputStream;
	File generatedPdfFile;
	
	public int getEntryNumber() {
		return entryNumber;
	}
	public void setEntryNumber(int entryNumber) {
		this.entryNumber = entryNumber;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public InputStream getPdfInputStream() {
		return pdfInputStream;
	}
	public void setPdfInputStream(InputStream pdfInputStream) {
		this.pdfInputStream = pdfInputStream;
	}
	public File getGeneratedPdfFile() {
		return generatedPdfFile;
	}
	public void setGeneratedPdfFile(File generatedPdfFile) {
		this.generatedPdfFile = generatedPdfFile;
	}

}
