package bt.batelco.storefront.pdf.util;

import java.util.HashMap;
import java.util.Map;

public class PDFCoordinateMapper {
	
	public String getSignatureText() {
		String signature = "iVBORw0KGgoAAAANSUhEUgAAApgAAAFoCAYAAADzS4tNAAAgAElEQVR4Xu3dC5gkZX3v8d/bM1y8IN6WcNudmt0VFAR2qmeVAAoc8WhQvAY0EiNoAicQL+AlOTk5B3iMJ3pUUAL7CMcjGFTMQryAwRvKeiXIdvduYFFh2aleYL2sAnJbLtP9nuft7pnu6q6e7p6pnqnq/tbz5IkzU/XWvz5vgT+r6n1fIzYEEEAAAQQQQAABBGIUMDG2RVMIIIAAAggggAACCIiAyU2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwABBBBAAAEEECBgcg8ggAACCCCAAAIIxCpAwIyVk8YQQAABBBBAAAEECJjcAwgggAACCCCAAAKxChAwY+WkMQQQQAABBBBAAAECJvcAAggggAACCCCAQKwCBMxYOWkMAQQQQAABBBBAgIDJPYAAAggggAACCCAQqwABM1ZOGkMAAQQQQAABBBAgYHIPIIAAAggggAACCMQqQMCMlZPGEEAAAQQQQAABBAiY3AMIIIAAAggggAACsQoQMGPlpDEEEEAAAQQQQAABAib3AAIIIIAAAggggECsAgTMWDlpDAEEEEAAAQQQQICAyT2AAAIIIIAAAgggEKsAATNWThpDAAEEEEAAAQQQIGByDyCAAAIIIIAAAgjEKkDAjJWTxhBAAAEEEEAAAQQImNwDCCCAAAIIIIAAArEKEDBj5aQxBBBAAAEEEEAAAQIm9wACCCCAAAIIIIBArAIEzFg5aQwBBBBAAAEEEECAgMk9gAACCCCAAAIIIBCrAAEzVk4aQwCBJRcYz18sq3dL9nJN7/nfde+h9y95TRSAAAIIDJkAAXPIOpzLRWCgBVbkT1BG3529Rqv/qaL/jwN9zVwcAgggkEABAmYCO4WSEEBgngJe7nzJnNdw9NUK/LfNszUOQwABBBCYpwABc55wHIYAAgkUGMtfLONej9c2az+hYvaDCayUkhBAAIGBFiBgDnT3cnEIDJlAyxNMe4GC7PlDpsDlIoAAAksuQMBc8i6gAAQQiE1gPHeprDkr1F7g8++52IBpCAEEEOhOgH/xdufEXgggkAYBr3CFZE8LlZrJnKRta76RhvKpEQEEEBgUAQLmoPQk14EAApKXv0nScU0Un1fgh0MnVggggAACfRUgYPaVl8YRQGBRBcby35XRCU3n3KHpPQ5jPsxF7QlOhgACQy5AwBzyG4DLR2CgBFqnKapd3gAO9lmdX6at/k55BU/BRDBQ/cjFIIBA6gUImKnvQi4AAQRmBdoGTAUK/PHUSO2/8fnaMfk7ueuxmd/K2BWSfVwyvqSTJLlAubek59Su6W0K/KtTc30UigACAy9AwBz4LuYCERgiAe/W46QR9x1mxFY6XsHaDaE/uP1HR7ZUngQuxTa++WDZJ/eTMgfJ6AhZc6JkypJd2VM5Vh9Q0f9kT8ewMwIIINBHAQJmH3FpGgEEFlHAPe0zmS2ydn2bs26W7NdkzdEy2kfSQZL2lPRAw5PA5kNzkh6WTCCVi5J5XLIHy2RukJ3eKTO6TLb8DEm7S3pSKodfVZuRZ1UatNY9eQykzIuk8i4Zc4Ks9pJ0eJdCro7dJLl11d0gpg2ydqOMHpUyY5Iu4DV5l5LshgACiyJAwFwUZk6CAAJ9FYgePd7XU/avcXOlJPda/HZZu4qJ4vsnTcsIINA/AQJm/2xpGQEEFksgfQFzh2Tck9OfSOVfVb6zLE6s08zAncVy4zwIIIBAnwQImH2CpVkEEFhkAfeKPGN+rPLI86VSmwEv9kpZPUPGHNzwitx9f7msTbXRr8ilH1Rfi5txyexbfT3ufrZe/XW6azHzNKn8c0nHqqxLtD2b08qNK1TOnCjpLfVzmk3S9Nel0b2l6T9Io0HllfdSB87Vd+2hpx55u1T2ZLRVZfMzbffvWOSe5XQIIJBCAQJmCjuNkhFAoINA2yeaZjz0raIb5FPeY7O2H+6eJi7O5uWnJHk9nMx91xlI5usypTs0NfmdHo6d/67jhZNl7SVS5XvVxu2bUun/tAyYmv+ZOBIBBAZQgIA5gJ3KJSEw9AJjhRNl7L+3OtjTFWTdN45Ls40VfiRjj1ngye+T9JRkNkjmP6WSC8eeSrtfpXsOu3uBbVcPr4bLdoOl3B47VS4dqe1rt8VyPhpBAIGBEyBgDlyXckEIIFAR8PI2ImB+WkH2fUsm5OX/IKk6srw/2w6pfLY0skHBxIPzOkV1qqcvStp/zuOtvUbF7CnzOgcHIYDAwAsQMAe+i7lABIZUwMtdKJlzQldvzRdUnHj7kok0h15r1smUb5XViTL6L5JxUx65qZMWum2SrAvTvT+tbT9ZfURe140q+q9caLEcjwACgydAwBy8PuWKEEDACazcdJDKZTcgZaQBJKfAn1wyIG/TOVL5wrb1HHL77nps11HV+TWna5O/Z9zAoXfMDh4y5miV7b4yGSPZ50va1f6bznkskdn6/eq3pdJHNZK5VyV9WTLZhvrvU+AfuGSenBgBBBIrQMBMbNdQGAJDKjBWOFvG/mltQvHfSOZ3knXfGl7e88ASL/97Sc9NTMA84JbnaXS3TTJqCGURKwzNp+u9wnmSfamkPwkfbi9SkD236ybHC/fI2sbQ+AMFvpvcvbo1P4Ud1T5LthJS1xfFjgggsNgCBMzFFud8CCDQXsDLuxHTbmWaNpt1q+qsk8xnulq5Ziy/U0buKd/MtrRPMCsBrfnVvT1HQfZTsd0WXuEKyZ4Was/oRpVKZ3Y1KGcsv1VGqxqO/5YCvxpaW2o3D2v0mcu09QVPxFY/DSGAwEAIEDAHohu5CARSLtB51HLrBRpziqYmrpnzylsD5tUK/LctqVbzeundXEevBVe/o/yAJPdNZ23r8nW5l/+8pL9oOOVOBX51qiIv96vavJ+9tdlr/eyPAAKpFyBgpr4LuQAEUi6wIn+IMtoyv6voEJq8vJvC59n1jKVLVPTfPb9zxXSUl7tMMmfMtpbJnKRta74RU+v1ZprP4/5izWtUnLhhznN5udMkc0VoH2MekZX7VCE8f2dZhzLxeuw9R4MIDIQAAXMgupGLQGABAl6hGhrcyjFLsUVOim7dt5Nuku9ARmtlzRvaTpsT+O3/PdYyVVGXT/F6dXAhudsVbrz89yQ3Yry2mfKFmpp8f6+n7Lj/2B37Sbs+LWNOru9rLlcwcWbHY73C7ZI9dO79zFcVTLypY1vsgAACQylAwBzKbueiEXBfOuZ/IqM9JFVHBRv7RdnyZ3seSLMQTC93pGRuDjXR7pXxytypsua5KutDoUEy7fb3CmskWwiXF9OAGteoC+bGfkJWb66dY4NUumBOv+bX45UDY6ypuS8O3PJcjT5xW1M43yCrv1fRD7s3Huvl/0zSlzp3rdkiW/4juSeclYnfy8XqMZn9JHtQfeS7lslm1kq2JJlf1Pczx1b3N4FM+bGO+8jukuyIrHlEpvI9bvV4Y++QzLc15V/XuWb2QACBxRAgYC6GMudAIGkCXv7Xkv6oTVm/l8qvUTB5S9/LHitcJWP/vOE8GxT4x8953rH8h2X0Dw37bJJK50iZ4xRkz5/9fes8mI8p8Bu+SVzg1Xm5n0vmha2tmCsl+20F/pdb/tYyx6T5joKJVy2wkrkP9/IflfS3ETu5oHmVdtP1mnbzb057oXA8lrtKLrxX1lhPxbb0A7hSwUSRCCyOAAFzcZw5CwKtAl7+rZJ1q7o8KZN5VFa3Lspr6rbrdDeX2OdlFZfftkojT20NndWas1WcWDfn7TKef7msftCwz1OSdmv4+aNS6dvSiFvqcFnD78sa1b6xTKmzYvMrlCnd2OG2dks53imVc5U+VuZiye4VPqZPr+wbT1KZD9R+X7IHdPGP4Y5KrVbTMlrdxf5J2oWAmaTeoJahFyBgDv0tAMCiCqzefKCmS+6J3UmSjmo9t3v6pQv6FjTHCqfK2C90ec07pdIpfXtlPp53r5cbvj20JQXZ0Y61LWRQ0Fzfa3Y8ccMOrSH9/qb5NrtrLa56Op2t8p1t+SKp8i3rQra7JL2g1sAOyTxQeUUuU5TR8yrfzFY3F6Tdpxc7JbtOpi+vyH8pGfcqn1fkC+lRjkWgTwIEzD7B0iwCLQKVYGSul+zKDjp3KvAP7ovgeO4LsubUUNujI8s1PX2CZNwa3Uc0nbfzK+v5FuoVHmp6onexAv+9HZurflfoBgHNY+tx0vF2ZxjL3zP7HajVvTL2LysjtI16GKHex28v29ZdOFUZ+8aG70a7Ndwuq7fO+d1mty2xHwIIDIUAAXMoupmLXHKB3p+6xf+6r/IUy06FLZpe0UatQ53JHKxta+6M1TBqsEu3U96M5d4oY74SUY9bMvFpHetc6FPDZkdrr1Ex675VlKrXdbWkfeeo4zYF/uEd6+znDpU6My+RMa+TlfvE4OimzwxqZzeXS+WfxzoRfD+vi7YRQCAxAgTMxHQFhQy0gJf/lqTWwRxG07Lmc5J1gePIsIEZj/VVeeRk5hHnaFkJpvzXCiY/M2f/jG16k0zZPb2rTnlk7a0yJifZB6TynS2v2b3cGZK5bLZNo59oyj+mq3vAy7t5HJuWQ5w90gXhgxra+YNk3xee19GeqyB7UVfnitqpJRxHrMRTDXCerE6UyRwiWTe4KJA116o4cem8z93PA13N5ZHfKmMeq5xmqaat6uc10jYCCCyaAAFz0ag50dAKRA1mkW6WSn8fCl4tczbOI2C6J5CNI6kb0aOeTkY9zRvPnSJr/rV+aPnvFUz+U2T/rcqtVkk/Cq/uErmnG/AyJZUflMncLGOXq6xP1ve0lyvIdp6fcSx3l4xpN/gkUOCPV54i2swJUuZXmv79l3XfCb/XeO5SWXNW9Xz217LWV3HyV/O6J1scl+BV97wK5yAEEEBg8QQImItnzZmGVaBlMIsk993j1iPunSWJemXc66vc+sCT6O8muw2YY7e+WWbk2tnajP2QprIfj+y+llDcZSdbW5IxIw0B89MKsu4b0NZt5abXqlw+RsYe2PL9aOPebsqdot+4xGH9r+O5k2RNwxyJCxi97eW+Ipk31hqP/1OGLgnZDQEEEEiyAAEzyb1DbYMh0DyYxerfVPT/NHRxXs69xm18bXu9Av91PQHMrr5itiiYeHHLsd1O8j1WOEvG1l/jtp3IvOk1d0/FRu68oToxupmQ0d2yelnT6+6mg8yTkq3P0dhpyUWv4OanfEelEffd5G6j54ZCfjf1e3k3n6SbV7K6ucnpp7KN83h20wr7IIAAAgMvQMAc+C7mApdUYEUuq4zZGKohUz5c2ybd6ir1rTm4aJ5P2OZ6Re7O1vzEMWreSa/wVcnOTGcTaI/HDtcvj3m4NbDmzpfMeeHfZ86VSnvX0tfrZfRiWXWeeqj3TtrZNMelWyTmT1Vc+29tm/I2vlTKuMFB+1dDpv5ZRf89PZ3ay7v5N19eD5jmFE1NXNNTG+yMAAIIDIEAAXMIOplLXEKB5sEsbqCH+06wefPyX5fU+MTyOgX+62OvfCy/VUarGtr9jAL/r2d/Hts8LlPaNvuztZ9QMfvByDqiXrlHLXvonpya0WWy5UMrk3fbzOtaJxzv+kp3ylbmCn1Qxn6k4Si3cs6rO7YS7o+7FfjdTybePEjK6B5N+Ss6npMdEEAAgSEUIGAOYadzyYso0Bowo7+PDA1CcfWZKxVMnB57pWP5z8roXQ3t7lTg7zP7s1f4kGQ/Vvt5l6zNqpj9eZuAeVp4dHal7s4j38dvPVh25Bf1No2V7Fz/LnLfPD4koxv0WOYG/eaIR8ODdlxLPTzx9fK/rL96t2cqyF4+p/PYHfvJ7Po3yfxxeD8G98R+f9IgAggMjAABc2C6kgtJpEC3AbNlP3O5gonOo6p7vejlG1dpJNO0PKO9Rqa8rjKi3cv/pGGFoV0K/Ke3PcV4/i7Z0HKC0U9nmxuImo/TmEdk7UdkzT0y5RdIo/fL2Ps1tSa86tCqzS9WqeRegzdORSRFPTltV/hY/l0y+uzsn8t2UtuzbjnH+jb71FWrZew7m67TBdqLFGTP7ZWf/RFAAIFhESBgDktPc51LIxD1DWbUhOKLFTCdQngUdM3FbJGm/0YauakBqv0qPlFzahp9UlP+B7qC9vK3Szq0i33d2tj1Sd6Nzcqa8HrevQ60WZ1fpmltCX/DWZlQfGbaonMk49aIb7OZWxRMNM1Z2sWVsAsCCCAwRAIEzCHqbC51iQS8wuOS3aN+duPWGj8//MQs1/S6uU+vyCsBs7Kij3tSWR3sMru5kGnroS9qAFA1oEYM7nGrwdi3K8g2zJ/ZwdvL/1RS02vnnvvoTlVHj/e20lD0NXRz8p8q8N2qN2wIIIAAAnMIEDC5PRDot4CX/46kV4azXNPo4/HCpbK2NhG427OHbwrnU383S1dGPWl13yPq8Z/NrsM9c273eruY/YeeSqkEXZ0n2dN6Oq6+88LCnpf7uWRe2NW5rbbK2I9LmfUKJh7s6hh2QgABBIZYgIA5xJ3PpS+SQOQa4E0h0sv/UKrM+1jb7HoF2bf0tcLqijdnyZiTW87TbulGL+/mgHRzQda3dvNkdlt8xad8mqw5WqYypdFza99Y7tmmiRtkzb/L6EsLCnvuvLb8zzLmtW3O81PJ3iKb2ajixJe6vRz2QwABBBCQCJjcBQgshkDL+t6zQfKCytKO9VV4ZgLm6Qqybjqe/m9ebrtklodP1OYJavM8kP180jqzNvao9le5ND1bnxuMFPdWeWVe2R5UZuQGlZ/av2X99LjPSXsIIIDAAAsQMAe4c7m0hAmM5da3eVr4L7IKL3Fo9S4V/c/1/Qraf4v4gMo6Rtv9O0I1jOc3y+rw2u+ekN1zXMVD5remd98vjhMggAACCCyVAAFzqeQ573AKeIWLJBu95nZIZHo/BS/5dV+RokaCN57Qmv+h4sT/nv1V84j4XkaN9/VCaBwBBBBAIGkCBMyk9Qj1DIfAWP67MjqhzcX2tg55JfjpJBktUzmzRSPmxo6veKOfXDYvv7hJgT8xW2PLt6R28V7jD8ddwVUigAACAyNAwByYruRCUifQ/gni5xX43Y2snnu6nQ2SuVOmvFG72a/qzsnfyX3XqBH3VDJieiB7gawOCb3GtzpRRf+bFduWkeesZNP1PVcN52OSWeMmepLKnmTcKPpnRy4d2nXD7IgAAggkU4CAmcx+oaphEfAKX5HsG0OXa+01KmZP6Ujg5a6WzFs77lfd4X4ZPUu2Mko7YqsN6vE2vkHKfLVhhx8p8F9e+bl5MvioFXC6LGagd6tOv3SEpDWSPa4aKCv/12brYnnNgQbj4hBAYBAFCJiD2KtcUzoEvMKzJetWznFPtZo29zTxaZe1HUAznn+3rC6O5UIbV8Kp1nRdw5RJT0ilV1eXkcydIZnLZs9JwHST1ru+mwmT7j+7QDnX9gNJgWQDKbOp8p+DCff/2RBAAIGBEiBgDlR3cjGpEvDyfyZprvkVd8iY98nqu6H5HquvuRuXdJSsvUTWfE0j9k2y5q8k7daFxf0y5r9pauKa0L6rbluu0pN3SmZmHsrqGuPDGDArgbvyPwD2rv5/92pbz5bMWkkHzGFclLRJspukjJtWadOC5uzsojPZBQEEEEiSAAEzSb1BLUsnUF2h5ocyWi2p/lq4nxV5hbslu7LjKaz9uIrZD83uN567VNY0rvpzkfbYdZ5+eczDs/u4EGpGl8naN0h6W9M5bpPshZre8zrde+j9kef3chdK5pzZv7nX9jL/KqNr6/sPyKvd6lPIsXqArH0bGflkuUWrFiT1YC1MuiAZ/zydHW8SdkAAAQSSJUDATFZ/UM1SCXiFWyT7kobT5xX42b6W4+XvbXoKdr2MuUple2HLUoxqWJvcy/9W0rJabTkF/uScdY5tHpeZfoekHbJmuqv5NVflVquU+XYoAFt9TkbvnD1X4Kfv3x9ewQXuMal8nGTc08lOr7RnLte92q6HSF5t9/UfDRpHAIH0C6TvvyDSb84VJFFgPH+XbOXpZX0rj5yg7Ud8r2/levlHJD2j2r4pS+V3VVbvqQwSKX1EyjQ9ebQXqGzWK6Mt9Zr6uGa5lztNMle0vf5R7aOtvpvaKJmbV3Dh8QipvEYy7n8sHDZHoZtr30a67yEfrH0fKZ5GJrNrqQoBBJIvQMBMfh9R4WIIeHkbcZoNCvzj+3L65YW1GrE/m23bmh+rONGwFnnEqG23s3tVHVo7vM9TBY3n1stGrFVeqcWcreLEur749Npo9VvJ19eeTLpX3hEDpyqNuiDpvo1kkI18iK8AABgbSURBVE2vxuyPAAII9CBAwOwBi10HWMDLT0VOJdOv18DhidafUuDvHqnr5T8q6W/rf7MlyYzUfv6pAv/ovvdK8+Ceeiq+UkH29L6fv90Jqq+7j61NBRQVKP9QDZPGren+oIKJry1ZrZwYAQQQGDIBAuaQdTiX20bAK9wu2UNb/9qH1WpaJ1i/WoHfPBCnXoqXdyPGI74V7ENtUTwH/3gvPfmMV8va9U1/7t8T3qg6qoNxjq09pXThsnkrSvZrtVHbTP/DP+wIIIDAEgoQMJcQn1MnSMDLb5QUMajHfkpBtj6aeqElu7D2+NO/El4mssNo7KhpiaSnJHOQgolgoSV1dXzzOuT1g+7Q9B4vazsavavG59jJK5wmlY+VzMyE5Y07uyeUX6uN3v7aolks9Jo4HgEEEBgCAQLmEHQyl9hBYHzzwbKlX7TZq6jAn2MVlh51W59e7lTg79OxFS/3Kcm8N7xfHwf4NBfUPmBKxr5cU9kfdbyGTjvUn1C6QTmHSGoc1T9z9A8ku0HKuEDJBOWdTPk7AgggsEQCBMwlgue0CRJoWWO7ubaYBtIcsOkg7VbaKJm9KmewulfGHNbVBNzLN79YI6XbWtViqq1Td8wVMN11FP3lnZpo+Xt1lPfMN5TtpgvaXHvt7eaX5BvKnpE5AAEEEFgaAQLm0rhz1sUWcK+ZS3veo3sOuzsi6DStB26sGyI9u5/RJzXlf2DBJY/nfyyr6qCcXkNZ9Gvy6qjybtYtX3DxbghU4SHJVsNx82bsOk1lz257mur63Mc2rM/dbpS3m7h8g2Q2KJhwg3PYEEAAAQRSKEDATGGnUXIPApVgY2+WtG/tqOs0utcp2vqCJyo/u28in3j6Q+EWzc/Ck67bXyjIvqiHs7bu6uXOl8x5s3+w+l8q+h/uus3qdbiR7r2Hu65P0mHH8fwnZPX+9ns1fEtanTbIBcrj5hjlPdPUzGtvFypZBSeu/qIdBBBAYAkFCJhLiM+p5ylQeZqXqX4X6SYmn2vzCv8h2ZdG7HKWVPq5NHpJy+hxa/9Bxvxj6Jgny8u0Y/J386q45btLe5GC7Lk9tTX3pOdPaFTL+z7puZd7i2Tc2umZ6KCrT8qah2uBcq4VcmaeUrpX3i5UPtiTBTsjgAACCCRegICZ+C6iwJCAl/udZJ4XVpljsEv0BOpzoV6vwH+dmo9byHyYobbmOTCnZZCPvUcy9e8ejTlFUxPX9P1u8XKfkcyZPZ7Hjfbe0DA4Z3FGvvdYJLsjgAACCMQnQMCMz5KW+i3g5baHQlX4fHdqdK/DZ199u79VRiXbQk9lZfRKZbRZ03LrfTds9tUKst/uqa1qDfUnqJ2+U5yr8bHCVTL2z2d3MfqerF4x+/NifIu5Or9M0/Y1UuY9kp3oYMFo755vFg5AAAEEBkeAgDk4fZneK/Fu2lN65pHV197mabVX14H2ePT3+uUxD1curN0gl/BV/0HG/FXoSV73TzAfkDFnzh7rFW4JfYdp7ZtVzH6lJ+Sx/MUyenftmE0affJYbT2y6XvPLltsWWnIvE+y7pvO58y2UNah2u7f0WWLnXfbf+PTtbs5RTLvkOQG90TME1prxmhaVl+UjJs+iNHenXXZAwEEEBhoAQLmQHdvwi/ODVwx5Q/KZt7eZnRyIJlHJX1WI+VvqGTu6nhFzU/yWlfBuVXSYZL2rLdVWUrwgtBE3c3fPFpdpaL/Fx3PP7NDSyDuMJl6p4a9/H2S9q/vVjpeNnNWeF3yeb5+bz73WOFUGU1K9n1zlLVTRt+X9Ihs6UYFa7/c6RL4OwIIIIDA8AgQMIenr5N3pe3W/46q1Op+GT039CdjL5U1p0pyI5Yb8mL5VZqa/E7lF17uMsmc0fDXjynw/07exhdKdl8Fa6NHLUeN2u72O8zVmw/UdPlbs4OH4vg+smWlIXu6jLlfVl9vuLbq96Pz3aoj3d3TyjYTy5stMuUfyIx8U4+am/SbI1z4Z0MAAQQQQKBFgIDJTbH4AtXwlg+93u2mCqtpGY02JMkrZXRDxBrZ1RBZDZjfl8zxDc1fp8B/fTenk5f/vKT6U8tug2JoSiKzRcHEi7s631w7eYUrJHtaKCjLbJPsZQ0e6xVMvKWnc3m5V0nGTT3kRn3v1nqs2SKVr1XZrI/19XtPRbIzAggggEDaBAiYaeuxQai3/dRBvV+de6roFW4PTzXU8Kq49RX5BgV+Y+Bsf04v/1ZJV8/u0M1AmuYpiboNpZ2uvHkOSquNyuhiWf1Lw6H/osB3TyA7b17hvZL9VOSOxn5RZXOTjPke63t3pmQPBBBAAIGIxxOgILCoAis2v0KZ0o1N53xAKv+JgslbtLLwApWnD5AZXaay9pGxbjLy+kCW0IG1IDmW+7iMaVhpJ6aAueq25SpNf7MhvD6qwH/mnF6hsBvTN5HuhM0TtbvfucBrzMn1AKy/VNH/f3PXlztNMm+SdFKY0i1bqZ8o8F2oZkMAAQQQQGBBAjzBXBAfB/csMJ8nil7eTRm0rPVcdr2C7Fvk5T8q6W8b/v6kAn+Pys/zOV/jibyNn65Oy1PbynZS27O5yOtufnoZ96juTiPiM5mDtW3NnZG1rcxPqmQ/FB4UVNlzp2TXKcie33NfcgACCCCAAAJtBAiY3BqLK9Ackrp5hRz19K5a9R0K/EM1VniNjP1G04XskORWiDmk6ffdvyKvBFS3atDITfU22jyVXJ6f1IjcCPXaVjq+7QCi+YhXll60W8IjyUMNRV/XWP6dMvqvkpq/zdwh2e9o1+jfMFhnPh3CMQgggAACcwkQMLk/Fk8gai7LbkZmt50DsyHEjeXvkdGBXVzM2xT49e8quzhAXv7+htf0rUFuVW61SvqRZGbWO+8txHZTQyXs5je2n4uyKdCu3PRalUvvlMwbJDX/c75BMqfzfWW38OyHAAIIINCrAAGzVzH2n7/AeO4SWXN2QwO/UeDPhLL27Vam/Snd07KDW3Vnm1//ntPLuyd8zU8sGw/bVBlR3uva12O59aFXy82h2CtcJtmZqZByCvzJ+SPNceR47nBZs7l1j4anqis3HqPyiJtXtHFqptoh5gqVy5e2fcXfl6JpFAEEEEBgGAUImMPY60t1zWP5rTJa1XD6QIE/3lU5Ud8fjkyv0N0vqQdP9w1kuXxyxHeGktUjMqWT5vXaeqxwltycmzNb43eYXu5CyZxTv4YFTqjeiHHI7bvrsV1HSaNB5Wnj/hufr90ya2X0fyUdIGunldHlsqUPy+z2Mlm9TbLuiWV4s7pPGft3msp+oStrdkIAAQQQQGCBAgTMBQJyeA8CLa94yx9TMFmdr7LT5uU3STpidjdrf6xi9mWRh1VfqbtlFI+T7A9lM7drj5FP6s7Dt3U6TeTfV+Syyhj3erq21Z4YVr8NPWt2AFI335O2K6DSloLan92SmW7OS7dyT+vclG5VIdk9lcnsJ2ufLsmPbtZNjK4LQktnzguAgxBAAAEEEOhNgIDZmxd7z1egJaRVGtqswF/TVZMrN65Q2fyHZPaTdJtkv7KoI58bv/GsTA+kOyTjQuzMdrMC/6iurqV5p9aR7vNqJnSQNR+X0Tq+s1w4JS0ggAACCPQuQMDs3Ywj5iPgXu/untkZDkHle1WcXN5Tc+7pZLvlHXtqqMedG7/DtOYxmcqTw/rWzWCldqeMLWDWlnK05WuWxKhHUnZHAAEEEBhcAQLm4PZt8q7My/9O0vPqhdmHFWSflbxCIypaWThVZTvzDWNZUmZ2L6ujVPRvXtB19PKKPHyiB6XSG6XMHhp96mZtPfKhBdXBwQgggAACCMQgQMCMAZEmuhTwctslE35i+WR5mXZMuuCZ7K26fvpUU5EPyJgz+/aNY+MgH2tfJFPaJWXcmuGBbObpGjE3tp1YPdmaVIcAAgggMOACBMwB7+BEXZ5X+IVkDw7VZPUuFf3PJarOdsV4hfsk6wbe1DZ7kYLsuamonSIRQAABBBBYRAEC5iJiD/2pxgp3ydjV4YBpr1Exe0ribbz/fKE07eag3H221lHto61++LvSxF8IBSKAAAIIINB/AQJm/405w4yAlztDMpc1gfRn1Zu41cfzt8oqPIG6mzS+OLEu7lPRHgIIIIAAAmkXIGCmvQfTVH/Uko9Wl6jovzvRl9FuLXQ3XVEanr4mGpfiEEAAAQQGUYCAOYi9mtRr8nKnSeaKUHlGP9GUf0xSS1ZLKLZuLs4jK/Va84iKE3sltnYKQwABBBBAYIkECJhLBD+Up40eiZ3sV+RjuY/LmA9U+8tskbUflNEN1Z/t4xo1K/gOcyjvZi4aAQQQQGAOAQImt8fiCazOL9O0uVuyjU/9NinwJxaviB7O1Pz0MpM5SWV7e2i6Ive7bWu+0UOr7IoAAggggMDACxAwB76LE3aBXt6GK7KPK8g+LWFVVstpXL1H+pIC/9TK7738b2fXH1dtXfJEXgBFIYAAAgggsDQCBMylcR/es3r5TZKOmAUw2qgpf20iQby8m1jdq9TWuFqPl79O0knVms2VCiZOT2T9FIUAAggggMASCRAwlwh+aE+7cuMKlUa2yNhnStol2TcpyH4rcR6rcqtVMnfV6rpPgX/gbI1e4TLJnlH7eacCf5/E1U9BCCCAAAIILKEAAXMJ8Yf61F7ufQqyn0qswVj+YhnVpk8yP1QwcWw9YObOl8x5tSeY9yuYaFhfPbFXRGEIIIAAAggsmgABc9GoOVGqBBq/FbU6UUX/m7P1j+X/hJHkqepNikUAAQQQWGQBAuYig3O6FAiM518nq6/XKt2h0SdfpK1HPlR/glnwGEmegn6kRAQQQACBJRMgYC4ZPSdOrMB47lJZc1a1PrNFwcSLW2r18g9Ienb19/ZMBdnLE3s9FIYAAggggMAiCxAwFxmc06VAwCtcIdnTapVer8B/XUTAvEnScbXfJ3uy+BSQUyICCCCAwGAJEDAHqz+5mjgEQnN1tpnnsnnZy8Dnn6U47GkDAQQQQGAgBPgvxYHoRi4iVoH5BEyj12vKd/NjsiGAAAIIIDD0AgTMob8FAGgRCAXM0vEK1m5o2aey7KXcij61jRV9uJMQQAABBBCYESBgci8g0CzQGDBHtY+2+jsjkbw832Fy9yCAAAIIIBAhQMDktkCgUcDLv1XS1dVf2ZJGdh/X3YfdEx0wc2dI5rLavg8pyO4NJgIIIIAAAghIBEzuAgRCAbMxNErKZA7WtjV3RiKtyGWVMT9ze0l6XKNa0fZpJ8oIIIAAAggMkQABc4g6m0vtQiD82luaa3S4x4TrXYiyCwIIIIDAEAoQMIew07nkOQS8wmWSPaO2R6DAH5/Ty8u7gT7Lqvsw0Id7CwEEEEAAASdAwOQ+QKBRIPwEM6fAn5wTaCy3XsacXN3HXKlg4nRAEUAAAQQQGHYBAuaw3wFcf1jAy09J8mq/3KHAP2DuJ5ihbzZ3KvD3gRQBBBBAAIFhFyBgDvsdwPU3B8zGqYcktZkHc+Yo79bjpBF3TG0z4womAlgRQAABBBAYZgEC5jD3PtfeKhBeh1wq61Bt9+9oS7V684F6qjQlo1FJT2lUBzCSnBsLAQQQQGDYBQiYw34HcP1hgbH8+2X0ifov7ekKsle2D5hNK/pkMidp25pvwIoAAggggMAwCxAwh7n3ufZWgZWbXqty+frZPxizTlMTZ3cdMK05W8WJddAigAACCCAwzAIEzGHufa69VWDs1jfLjFzb8IefKvCPnpMqtHY5UxVxWyGAAAIIIEDA5B5AoFGgefJ06UEF/nM6BMzrJJ1U3cdcrmDiTFARQAABBBAYZgEC5jD3PtceLeDlN0rKzv6x00AfL3e+ZM6r7b9BgX88tAgggAACCAyzAAFzmHufa28XMH8q6Y9n/2h1lIr+zZE7u1Hk06Utkp5VfYBprtXURG3idYARQAABBBAYTgEC5nD2O1c9l0DzeuSyFynInht5yHjhZFm7viGMXquiT8DkDkMAAQQQGGoBAuZQdz8XHykQfuXtdtkplU5RsHbD7P5e/q2y5rkyOkuyh9bbKX9MweTfIYsAAggggMAwCxAwh7n3ufZogZUb91Y54yZX379hh01S6Rxp5NWSXibpqIiDd0jmaFby4cZCAAEEEBh2AQLmsN8BXH+0wFj+Yhm9uzcepijqzYu9EUAAAQQGVYCAOag9y3UtXKD1VXm7NgPJ/pOC7OULPyktIIAAAgggkH4BAmb6+5Ar6KeAl/+VpH2jT2EflvQe7Rq9Rr854tF+lkHbCCCAAAIIpEmAgJmm3qLWxRfwbj1OduQUyRwmYw+UTFmyt0ily0ODfha/Ms6IAAIIIIBAYgUImIntGgpDAAEEEEAAAQTSKUDATGe/UTUCCCCAAAIIIJBYAQJmYruGwhBAAAEEEEAAgXQKEDDT2W9UjQACCCCAAAIIJFaAgJnYrqEwBBBAAAEEEEAgnQIEzHT2G1UjgAACCCCAAAKJFSBgJrZrKAwBBBBAAAEEEEinAAEznf1G1QgggAACCCCAQGIFCJiJ7RoKQwABBBBAAAEE0ilAwExnv1E1AggggAACCCCQWAECZmK7hsIQQAABBBBAAIF0ChAw09lvVI0AAggggAACCCRWgICZ2K6hMAQQQAABBBBAIJ0CBMx09htVI4AAAggggAACiRUgYCa2aygMAQQQQAABBBBIpwABM539RtUIIIAAAggggEBiBQiYie0aCkMAAQQQQAABBNIpQMBMZ79RNQIIIIAAAgggkFgBAmZiu4bCEEAAAQQQQACBdAoQMNPZb1SNAAIIIIAAAggkVoCAmdiuoTAEEEAAAQQQQCCdAgTMdPYbVSOAAAIIIIAAAokVIGAmtmsoDAEEEEAAAQQQSKcAATOd/UbVCCCAAAIIIIBAYgUImIntGgpDAAEEEEAAAQTSKUDATGe/UTUCCCCAAAIIIJBYAQJmYruGwhBAAAEEEEAAgXQKEDDT2W9UjQACCCCAAAIIJFaAgJnYrqEwBBBAAAEEEEAgnQIEzHT2G1UjgAACCCCAAAKJFSBgJrZrKAwBBBBAAAEEEEinAAEznf1G1QgggAACCCCAQGIFCJiJ7RoKQwABBBBAAAEE0ilAwExnv1E1AggggAACCCCQWAECZmK7hsIQQAABBBBAAIF0ChAw09lvVI0AAggggAACCCRWgICZ2K6hMAQQQAABBBBAIJ0CBMx09htVI4AAAggggAACiRUgYCa2aygMAQQQQAABBBBIpwABM539RtUIIIAAAggggEBiBQiYie0aCkMAAQQQQAABBNIpQMBMZ79RNQIIIIAAAgggkFgBAmZiu4bCEEAAAQQQQACBdAoQMNPZb1SNAAIIIIAAAggkVoCAmdiuoTAEEEAAAQQQQCCdAgTMdPYbVSOAAAIIIIAAAokVIGAmtmsoDAEEEEAAAQQQSKcAATOd/UbVCCCAAAIIIIBAYgUImIntGgpDAAEEEEAAAQTSKUDATGe/UTUCCCCAAAIIIJBYAQJmYruGwhBAAAEEEEAAgXQKEDDT2W9UjQACCCCAAAIIJFaAgJnYrqEwBBBAAAEEEEAgnQIEzHT2G1UjgAACCCCAAAKJFSBgJrZrKAwBBBBAAAEEEEinAAEznf1G1QgggAACCCCAQGIFCJiJ7RoKQwABBBBAAAEE0ilAwExnv1E1AggggAACCCCQWAECZmK7hsIQQAABBBBAAIF0ChAw09lvVI0AAggggAACCCRWgICZ2K6hMAQQQAABBBBAIJ0CBMx09htVI4AAAggggAACiRUgYCa2aygMAQQQQAABBBBIpwABM539RtUIIIAAAggggEBiBQiYie0aCkMAAQQQQAABBNIpQMBMZ79RNQIIIIAAAgggkFgBAmZiu4bCEEAAAQQQQACBdAoQMNPZb1SNAAIIIIAAAggkVoCAmdiuoTAEEEAAAQQQQCCdAgTMdPYbVSOAAAIIIIAAAokVIGAmtmsoDAEEEEAAAQQQSKcAATOd/UbVCCCAAAIIIIBAYgUImIntGgpDAAEEEEAAAQTSKUDATGe/UTUCCCCAAAIIIJBYAQJmYruGwhBAAAEEEEAAgXQKEDDT2W9UjQACCCCAAAIIJFaAgJnYrqEwBBBAAAEEEEAgnQIEzHT2G1UjgAACCCCAAAKJFSBgJrZrKAwBBBBAAAEEEEinAAEznf1G1QgggAACCCCAQGIFCJiJ7RoKQwABBBBAAAEE0ilAwExnv1E1AggggAACCCCQWAECZmK7hsIQQAABBBBAAIF0Cvx/vp5WHYDUI38AAAAASUVORK5CYII=";
		return signature;
	}
	
	public Map<String, PDFFieldnameAndCoordinates> getFieldNameAndCoordinatePostpaid() {
		
		Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		
		//Page -1 -- START
		
		PDFFieldnameAndCoordinates newCustomer = new PDFFieldnameAndCoordinates("newCustomer", 346, 818);
		PDFFieldnameAndCoordinates changeOfPackage = new PDFFieldnameAndCoordinates("changeOfPackage", 346, 809);
		PDFFieldnameAndCoordinates renewContract = new PDFFieldnameAndCoordinates("renewContract", 346, 800);
		PDFFieldnameAndCoordinates changeOfAddress = new PDFFieldnameAndCoordinates("changeOfAddress", 346, 791);
		PDFFieldnameAndCoordinates miscellaneous = new PDFFieldnameAndCoordinates("miscellaneous", 346, 783);
		PDFFieldnameAndCoordinates numberPortability = new PDFFieldnameAndCoordinates("numberPortability", 346, 774);
		fieldMapper.put("newCustomer", newCustomer);
		fieldMapper.put("changeOfPackage", changeOfPackage);
		fieldMapper.put("renewContract", renewContract);
		fieldMapper.put("changeOfAddress", changeOfAddress);
		fieldMapper.put("miscellaneous", miscellaneous);
		fieldMapper.put("numberPortability", numberPortability);
		
		//Personal Details
		PDFFieldnameAndCoordinates name = new PDFFieldnameAndCoordinates("name", 38, 706);
		PDFFieldnameAndCoordinates nationality = new PDFFieldnameAndCoordinates("nationality", 48, 692);
		PDFFieldnameAndCoordinates cprNo = new PDFFieldnameAndCoordinates("cprNo", 38, 679);
		PDFFieldnameAndCoordinates crNo = new PDFFieldnameAndCoordinates("crNo", 167, 679);
		PDFFieldnameAndCoordinates mobileNumber = new PDFFieldnameAndCoordinates("mobileNumber", 99, 665);
		PDFFieldnameAndCoordinates contactName = new PDFFieldnameAndCoordinates("contactName", 61, 650);
		PDFFieldnameAndCoordinates contactNumber = new PDFFieldnameAndCoordinates("contactNumber", 52, 638);
		fieldMapper.put("name", name);
		fieldMapper.put("nationality", nationality);
		fieldMapper.put("cprNo", cprNo);
		fieldMapper.put("crNo", crNo);
		fieldMapper.put("mobileNumber", mobileNumber);
		fieldMapper.put("contactName", contactName);
		fieldMapper.put("contactNumber", contactNumber);
		
		//Local Address
		PDFFieldnameAndCoordinates flatNo = new PDFFieldnameAndCoordinates("flatNo", 37, 602);
		PDFFieldnameAndCoordinates houseOrBuildingNo = new PDFFieldnameAndCoordinates("houseOrBuildingNo", 189, 602);
		PDFFieldnameAndCoordinates roadOrStreetName = new PDFFieldnameAndCoordinates("roadOrStreetName", 63, 589);
		PDFFieldnameAndCoordinates blockNo = new PDFFieldnameAndCoordinates("blockNo", 172, 589);
		PDFFieldnameAndCoordinates emailId = new PDFFieldnameAndCoordinates("emailId", 65, 575);
		PDFFieldnameAndCoordinates iOptChk = new PDFFieldnameAndCoordinates("iOptChk", 16, 555);
		fieldMapper.put("flatNo", flatNo);
		fieldMapper.put("houseOrBuildingNo", houseOrBuildingNo);
		fieldMapper.put("roadOrStreetName", roadOrStreetName);
		fieldMapper.put("blockNo", blockNo);
		fieldMapper.put("emailId", emailId);
		fieldMapper.put("iOptChk", iOptChk);
		
		//Mailing Address
		PDFFieldnameAndCoordinates mailingFlatNo = new PDFFieldnameAndCoordinates("mailingFlatNo", 39, 494);
		PDFFieldnameAndCoordinates mailingHouseOrBuildingNo = new PDFFieldnameAndCoordinates("mailingHouseOrBuildingNo", 192, 493);
		PDFFieldnameAndCoordinates mailingRoadOrStreetName = new PDFFieldnameAndCoordinates("mailingRoadOrStreetName", 61, 480);
		PDFFieldnameAndCoordinates mailingBlockNo = new PDFFieldnameAndCoordinates("mailingBlockNo", 171, 480);
		PDFFieldnameAndCoordinates mailingArea = new PDFFieldnameAndCoordinates("mailingArea", 30, 466);
		PDFFieldnameAndCoordinates mailingPOBoxNo = new PDFFieldnameAndCoordinates("mailingPOBoxNo", 168, 466);
		fieldMapper.put("mailingFlatNo", mailingFlatNo);
		fieldMapper.put("mailingHouseOrBuildingNo", mailingHouseOrBuildingNo);
		fieldMapper.put("mailingRoadOrStreetName", mailingRoadOrStreetName);
		fieldMapper.put("mailingBlockNo", mailingBlockNo);
		fieldMapper.put("mailingArea", mailingArea);
		fieldMapper.put("mailingPOBoxNo", mailingPOBoxNo);
		
		//Telephone Directory
		PDFFieldnameAndCoordinates teleDirYesCHk = new PDFFieldnameAndCoordinates("teleDirYesCHk", 16, 435);
		PDFFieldnameAndCoordinates teleDirNoChk = new PDFFieldnameAndCoordinates("teleDirNoChk", 118, 434);
		PDFFieldnameAndCoordinates teleDirName = new PDFFieldnameAndCoordinates("teleDirName", 90, 413);
		fieldMapper.put("teleDirYesCHk", teleDirYesCHk);
		fieldMapper.put("teleDirNoChk", teleDirNoChk);
		fieldMapper.put("teleDirName", teleDirName);
		
		//2. Mobile Package
		PDFFieldnameAndCoordinates smartChk = new PDFFieldnameAndCoordinates("smartChk", 17, 287);
		PDFFieldnameAndCoordinates smartText = new PDFFieldnameAndCoordinates("smartText", 50, 289);
		PDFFieldnameAndCoordinates superChk = new PDFFieldnameAndCoordinates("superChk", 17, 277);
		PDFFieldnameAndCoordinates superText = new PDFFieldnameAndCoordinates("superText", 48, 279);
		PDFFieldnameAndCoordinates heroChk = new PDFFieldnameAndCoordinates("heroChk", 75, 287);
		PDFFieldnameAndCoordinates mpOthersChk = new PDFFieldnameAndCoordinates("mpOthersChk", 75, 277);
		PDFFieldnameAndCoordinates mpOthersText = new PDFFieldnameAndCoordinates("mpOthersText", 104, 269);
		PDFFieldnameAndCoordinates tunailChk = new PDFFieldnameAndCoordinates("tunailChk", 140, 290);
		PDFFieldnameAndCoordinates tunailMobileNumber = new PDFFieldnameAndCoordinates("tunailMobileNumber", 230, 290);
		PDFFieldnameAndCoordinates twinChk = new PDFFieldnameAndCoordinates("twinChk", 140, 277);
		PDFFieldnameAndCoordinates twinMobileNumber = new PDFFieldnameAndCoordinates("twinMobileNumber", 230, 277);
		
		fieldMapper.put("smartChk", smartChk);
		fieldMapper.put("smartText", smartText);
		fieldMapper.put("superChk", superChk);
		fieldMapper.put("superText", superText);
		fieldMapper.put("heroChk", heroChk);
		fieldMapper.put("mpOthersChk", mpOthersChk);
		fieldMapper.put("mpOthersText", mpOthersText);
		fieldMapper.put("tunailChk", tunailChk);
		fieldMapper.put("tunailMobileNumber", tunailMobileNumber);
		fieldMapper.put("twinChk", twinChk);
		fieldMapper.put("twinMobileNumber", twinMobileNumber);
		
		// Credit Limit
		PDFFieldnameAndCoordinates clBD50 = new PDFFieldnameAndCoordinates("clBD50", 98, 256);
		PDFFieldnameAndCoordinates cl25fills = new PDFFieldnameAndCoordinates("cl25fills", 16, 243);
		PDFFieldnameAndCoordinates clOthers = new PDFFieldnameAndCoordinates("clOthers", 165, 255);
		fieldMapper.put("clBD50", clBD50);
		fieldMapper.put("cl25fills", cl25fills);
		fieldMapper.put("clOthers", clOthers);
		
		//3. Handset Installments
		PDFFieldnameAndCoordinates hiBrand = new PDFFieldnameAndCoordinates("hiBrand", 35, 162);
		PDFFieldnameAndCoordinates hiModel = new PDFFieldnameAndCoordinates("hiModel", 180, 162);
		PDFFieldnameAndCoordinates hiSerialNo = new PDFFieldnameAndCoordinates("hiSerialNo", 60, 149);
		PDFFieldnameAndCoordinates hiContractTerm12 = new PDFFieldnameAndCoordinates("hiContractTerm12", 218, 127);
		PDFFieldnameAndCoordinates hiContractTerm18 = new PDFFieldnameAndCoordinates("hiContractTerm18", 300, 127);
		PDFFieldnameAndCoordinates hiContractTerm24 = new PDFFieldnameAndCoordinates("hiContractTerm24", 382, 127);
		fieldMapper.put("hiBrand", hiBrand);
		fieldMapper.put("hiModel", hiModel);
		fieldMapper.put("hiSerialNo", hiSerialNo);
		fieldMapper.put("hiContractTerm12", hiContractTerm12);
		fieldMapper.put("hiContractTerm18", hiContractTerm18);
		fieldMapper.put("hiContractTerm24", hiContractTerm24);
		
		//Page -1 -- END
		
		//Page -2 -- START
		//4. Miscellaneous
		PDFFieldnameAndCoordinates miscSimReplacementChk = new PDFFieldnameAndCoordinates("miscSimReplacementChk", 18, 713);
		PDFFieldnameAndCoordinates miscSimReplacement = new PDFFieldnameAndCoordinates("miscSimReplacement", 147, 711);
		PDFFieldnameAndCoordinates miscReconnectionChk = new PDFFieldnameAndCoordinates("miscReconnectionChk", 18, 699);
		PDFFieldnameAndCoordinates miscDisconnectionChk = new PDFFieldnameAndCoordinates("miscDisconnectionChk", 18, 687);
		PDFFieldnameAndCoordinates miscDisconnectionPermanentChk = new PDFFieldnameAndCoordinates("miscDisconnectionPermanentChk", 50, 687);
		PDFFieldnameAndCoordinates miscDisconnectionTemporaryChk = new PDFFieldnameAndCoordinates("miscDisconnectionTemporaryChk", 70, 687);
		PDFFieldnameAndCoordinates miscStartingDate = new PDFFieldnameAndCoordinates("miscStartingDate", 57, 668);
		fieldMapper.put("miscSimReplacementChk", miscSimReplacementChk);
		fieldMapper.put("miscSimReplacement", miscSimReplacement);
		fieldMapper.put("miscReconnectionChk", miscReconnectionChk);
		fieldMapper.put("miscDisconnectionChk", miscDisconnectionChk);
		fieldMapper.put("miscDisconnectionPermanentChk", miscDisconnectionPermanentChk);
		fieldMapper.put("miscDisconnectionTemporaryChk", miscDisconnectionTemporaryChk);
		fieldMapper.put("miscStartingDate", miscStartingDate);
		
		// Changing of Ownership
		PDFFieldnameAndCoordinates cooChangeOfOwnerChk = new PDFFieldnameAndCoordinates("cooChangeOfOwnerChk", 18, 630);
		PDFFieldnameAndCoordinates cooNewOwnerName = new PDFFieldnameAndCoordinates("cooNewOwnerName", 76, 614);
		PDFFieldnameAndCoordinates cooNationality = new PDFFieldnameAndCoordinates("cooNationality", 52, 600);
		PDFFieldnameAndCoordinates cooIdNo = new PDFFieldnameAndCoordinates("cooIdNo", 171, 599);
		fieldMapper.put("cooChangeOfOwnerChk", cooChangeOfOwnerChk);
		fieldMapper.put("cooNewOwnerName", cooNewOwnerName);
		fieldMapper.put("cooNationality", cooNationality);
		fieldMapper.put("cooIdNo", cooIdNo);
		
		//Local Address
		PDFFieldnameAndCoordinates localAddrsFlatNo = new PDFFieldnameAndCoordinates("localAddrsFlatNo", 39, 529);
		PDFFieldnameAndCoordinates localAddrsHouseOrBuilding = new PDFFieldnameAndCoordinates("localAddrsHouseOrBuilding", 194, 530);
		PDFFieldnameAndCoordinates localAddrsRoadOrStreet = new PDFFieldnameAndCoordinates("localAddrsRoadOrStreet", 64, 516);
		PDFFieldnameAndCoordinates localAddrsBlock = new PDFFieldnameAndCoordinates("localAddrsBlock", 176, 516);
		PDFFieldnameAndCoordinates localAddrsArea = new PDFFieldnameAndCoordinates("localAddrsArea", 33, 503);
		PDFFieldnameAndCoordinates localAddrsPOBox = new PDFFieldnameAndCoordinates("localAddrsPOBox", 172, 503);
		fieldMapper.put("localAddrsFlatNo", localAddrsFlatNo);
		fieldMapper.put("localAddrsHouseOrBuilding", localAddrsHouseOrBuilding);
		fieldMapper.put("localAddrsRoadOrStreet", localAddrsRoadOrStreet);
		fieldMapper.put("localAddrsBlock", localAddrsBlock);
		fieldMapper.put("localAddrsArea", localAddrsArea);
		fieldMapper.put("localAddrsPOBox", localAddrsPOBox);
		
		//Mailing Address
		PDFFieldnameAndCoordinates mailingAddrsFlatNo = new PDFFieldnameAndCoordinates("mailingAddrsFlatNo", 41, 451);
		PDFFieldnameAndCoordinates mailingAddrsHouseOrBuilding = new PDFFieldnameAndCoordinates("mailingAddrsHouseOrBuilding", 195, 450);
		PDFFieldnameAndCoordinates mailingAddrsRoadOrStreet = new PDFFieldnameAndCoordinates("mailingAddrsRoadOrStreet", 63, 437);
		PDFFieldnameAndCoordinates mailingAddrsBlock = new PDFFieldnameAndCoordinates("mailingAddrsBlock", 174, 437);
		PDFFieldnameAndCoordinates mailingAddrsArea = new PDFFieldnameAndCoordinates("mailingAddrsArea", 32, 424);
		PDFFieldnameAndCoordinates mailingAddrsPOBox = new PDFFieldnameAndCoordinates("mailingAddrsPOBox", 172, 424);
		fieldMapper.put("mailingAddrsFlatNo", mailingAddrsFlatNo);
		fieldMapper.put("mailingAddrsHouseOrBuilding", mailingAddrsHouseOrBuilding);
		fieldMapper.put("mailingAddrsRoadOrStreet", mailingAddrsRoadOrStreet);
		fieldMapper.put("mailingAddrsBlock", mailingAddrsBlock);
		fieldMapper.put("mailingAddrsArea", mailingAddrsArea);
		fieldMapper.put("mailingAddrsPOBox", mailingAddrsPOBox);
		
		//New Subscriber Sign and Date
		PDFFieldnameAndCoordinates newSubscriberSignature = new PDFFieldnameAndCoordinates("newSubscriberSignature", 96, 382, 100, 40);
		PDFFieldnameAndCoordinates newSubscriberDate = new PDFFieldnameAndCoordinates("newSubscriberDate", 180, 383);
		fieldMapper.put("newSubscriberSignature", newSubscriberSignature);
		fieldMapper.put("newSubscriberDate", newSubscriberDate);
		
		//Number Portability
		PDFFieldnameAndCoordinates numPortMobile1 = new PDFFieldnameAndCoordinates("numPortMobile1", 61, 296);
		PDFFieldnameAndCoordinates numPortPackage1 = new PDFFieldnameAndCoordinates("numPortPackage1", 215, 296);
		PDFFieldnameAndCoordinates numPortSIMNo1 = new PDFFieldnameAndCoordinates("numPortSIMNo1", 60, 281);
		PDFFieldnameAndCoordinates numPortMobile2 = new PDFFieldnameAndCoordinates("numPortMobile2", 61, 257);
		PDFFieldnameAndCoordinates numPortPackage2 = new PDFFieldnameAndCoordinates("numPortPackage2", 215, 257);
		PDFFieldnameAndCoordinates numPortSIMNo2 = new PDFFieldnameAndCoordinates("numPortSIMNo2", 60, 242);
		PDFFieldnameAndCoordinates numPortMobile3 = new PDFFieldnameAndCoordinates("numPortMobile3", 61, 218);
		PDFFieldnameAndCoordinates numPortPackage3 = new PDFFieldnameAndCoordinates("numPortPackage3", 215, 217);
		PDFFieldnameAndCoordinates numPortSIMNo3 = new PDFFieldnameAndCoordinates("numPortSIMNo3", 60, 203);
		fieldMapper.put("numPortMobile1", numPortMobile1);
		fieldMapper.put("numPortPackage1", numPortPackage1);
		fieldMapper.put("numPortSIMNo1", numPortSIMNo1);
		fieldMapper.put("numPortMobile2", numPortMobile2);
		fieldMapper.put("numPortPackage2", numPortPackage2);
		fieldMapper.put("numPortSIMNo2", numPortSIMNo2);
		fieldMapper.put("numPortMobile3", numPortMobile3);
		fieldMapper.put("numPortPackage3", numPortPackage3);
		fieldMapper.put("numPortSIMNo3", numPortSIMNo3);
		
		//Page -2 -- END
		
		//Page -3 -- START
		
		//Non Bahrainis
		PDFFieldnameAndCoordinates nonBahrainDirectChk = new PDFFieldnameAndCoordinates("nonBahrainDirectChk", 92, 711);
		PDFFieldnameAndCoordinates nonBahrainBD100Chk = new PDFFieldnameAndCoordinates("nonBahrainBD100Chk", 205, 712);
		PDFFieldnameAndCoordinates nonBahrainCompanyChk = new PDFFieldnameAndCoordinates("nonBahrainCompanyChk", 93, 697);
		PDFFieldnameAndCoordinates nonBahrainRoamingChk = new PDFFieldnameAndCoordinates("nonBahrainRoamingChk", 92, 683);
		PDFFieldnameAndCoordinates nonBahrainNoRoamingChk = new PDFFieldnameAndCoordinates("nonBahrainNoRoamingChk", 205, 688);
		PDFFieldnameAndCoordinates nonBahrainCompany = new PDFFieldnameAndCoordinates("nonBahrainCompany", 93, 697);
		PDFFieldnameAndCoordinates nonBahrainContactPerson = new PDFFieldnameAndCoordinates("nonBahrainContactPerson", 92, 683);
		PDFFieldnameAndCoordinates nonBahrainSignature = new PDFFieldnameAndCoordinates("nonBahrainSignature", 200, 558, 100, 40);
		fieldMapper.put("nonBahrainDirectChk", nonBahrainDirectChk);
		fieldMapper.put("nonBahrainBD100Chk", nonBahrainBD100Chk);
		fieldMapper.put("nonBahrainCompanyChk", nonBahrainCompanyChk);
		fieldMapper.put("nonBahrainRoamingChk", nonBahrainRoamingChk);
		fieldMapper.put("nonBahrainNoRoamingChk", nonBahrainNoRoamingChk);
		fieldMapper.put("nonBahrainCompany", nonBahrainCompany);
		fieldMapper.put("nonBahrainContactPerson", nonBahrainContactPerson);
		fieldMapper.put("nonBahrainSignature", nonBahrainSignature);
		
		//Aggreement
		PDFFieldnameAndCoordinates agreeAppName = new PDFFieldnameAndCoordinates("agreeAppName", 63, 313);
		PDFFieldnameAndCoordinates agreeSignature = new PDFFieldnameAndCoordinates("agreeSignature", 153, 313, 100, 40);
		PDFFieldnameAndCoordinates agreeDate = new PDFFieldnameAndCoordinates("agreeDate", 250, 313);
		PDFFieldnameAndCoordinates agreeIDNo = new PDFFieldnameAndCoordinates("agreeIDNo", 43, 298);
		PDFFieldnameAndCoordinates agreeCustomerName = new PDFFieldnameAndCoordinates("agreeCustomerName", 63, 280);
		PDFFieldnameAndCoordinates agreeCustomerSign = new PDFFieldnameAndCoordinates("agreeCustomerSign", 153, 270, 100, 40);
		PDFFieldnameAndCoordinates agreeCustomerDate = new PDFFieldnameAndCoordinates("agreeCustomerDate", 250, 280);
		PDFFieldnameAndCoordinates agreeCustomerIDNo = new PDFFieldnameAndCoordinates("agreeCustomerIDNo", 43, 265);

		fieldMapper.put("agreeAppName", agreeAppName);
		fieldMapper.put("agreeSignature", agreeSignature);
		fieldMapper.put("agreeDate", agreeDate);
		fieldMapper.put("agreeIDNo", agreeIDNo);
		fieldMapper.put("agreeCustomerName", agreeCustomerName);
		fieldMapper.put("agreeCustomerSign", agreeCustomerSign);
		fieldMapper.put("agreeCustomerDate", agreeCustomerDate);
		fieldMapper.put("agreeCustomerIDNo", agreeCustomerIDNo);
		
		//Page -3 -- END
		
		return fieldMapper;
	}
	
	public Map<String, PDFFieldnameAndCoordinates> getFieldNameAndCoordinateMobile(){
		Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		
		fieldMapper = getFieldNameAndCoordinatePostpaid();
		
		return fieldMapper;
	}
	
	public Map<String, PDFFieldnameAndCoordinates> getFieldNameAndCoordinateHomeInternet(){
		Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		
		PDFFieldnameAndCoordinates requestTypeNew = new PDFFieldnameAndCoordinates("requestTypeNew", 420, 821);
		PDFFieldnameAndCoordinates requestTypeUpgrade = new PDFFieldnameAndCoordinates("requestTypeUpgrade", 420, 809);
		PDFFieldnameAndCoordinates requestTypeTerminate = new PDFFieldnameAndCoordinates("requestTypeTerminate", 420, 797);
		fieldMapper.put("requestTypeNew", requestTypeNew);
		fieldMapper.put("requestTypeUpgrade", requestTypeUpgrade);
		fieldMapper.put("requestTypeTerminate", requestTypeTerminate);
		
		//Customer
		PDFFieldnameAndCoordinates customerName = new PDFFieldnameAndCoordinates("customerName", 40, 755);
		PDFFieldnameAndCoordinates customerIdNumber = new PDFFieldnameAndCoordinates("customerIdNumber", 40, 741);
		PDFFieldnameAndCoordinates customerContactNumber = new PDFFieldnameAndCoordinates("customerContactNumber", 50, 726);
		PDFFieldnameAndCoordinates customerContactEmail = new PDFFieldnameAndCoordinates("customerContactEmail", 60, 713);
		PDFFieldnameAndCoordinates customerCircuitNumber = new PDFFieldnameAndCoordinates("customerCircuitNumber", 70, 700);
		PDFFieldnameAndCoordinates customerPreferredLangArabicChk = new PDFFieldnameAndCoordinates("customerPreferredLangArabicChk", 85, 685);
		PDFFieldnameAndCoordinates customerPreferredLangEnglishChk = new PDFFieldnameAndCoordinates("customerPreferredLangEnglishChk", 130, 685);
		PDFFieldnameAndCoordinates customerActivateEBillChk = new PDFFieldnameAndCoordinates("customerActivateEBillChk", 16, 669);
		fieldMapper.put("customerName", customerName);
		fieldMapper.put("customerIdNumber", customerIdNumber);
		fieldMapper.put("customerContactNumber", customerContactNumber);
		fieldMapper.put("customerContactEmail", customerContactEmail);
		fieldMapper.put("customerCircuitNumber", customerCircuitNumber);
		fieldMapper.put("customerPreferredLangArabicChk", customerPreferredLangArabicChk);
		fieldMapper.put("customerPreferredLangEnglishChk", customerPreferredLangEnglishChk);
		fieldMapper.put("customerActivateEBillChk", customerActivateEBillChk);
		
		//Home Internet Package
		PDFFieldnameAndCoordinates valuePack1015mbChk = new PDFFieldnameAndCoordinates("valuePack1015mbChk", 16, 617);
		PDFFieldnameAndCoordinates valuePack202mbChk = new PDFFieldnameAndCoordinates("valuePack202mbChk", 124, 617);
		PDFFieldnameAndCoordinates valuePack305mbChk = new PDFFieldnameAndCoordinates("valuePack305mbChk", 124, 603);
		PDFFieldnameAndCoordinates valuePack10010mbChk = new PDFFieldnameAndCoordinates("valuePack10010mbChk", 124, 589);
		PDFFieldnameAndCoordinates valuePack50050mbChk = new PDFFieldnameAndCoordinates("valuePack50050mbChk", 124, 576);
		fieldMapper.put("valuePack1015mbChk", valuePack1015mbChk);
		fieldMapper.put("valuePack202mbChk", valuePack202mbChk);
		fieldMapper.put("valuePack305mbChk", valuePack305mbChk);
		fieldMapper.put("valuePack10010mbChk", valuePack10010mbChk);
		fieldMapper.put("valuePack50050mbChk", valuePack50050mbChk);
		
		//BillingDate
		PDFFieldnameAndCoordinates billingDate = new PDFFieldnameAndCoordinates("billingDate", 52, 575);
		PDFFieldnameAndCoordinates autoContractRenewChk = new PDFFieldnameAndCoordinates("autoContractRenewChk", 16, 559);
		fieldMapper.put("billingDate", billingDate);
		fieldMapper.put("autoContractRenewChk", autoContractRenewChk);
		
		//Home Internet Bolton
		PDFFieldnameAndCoordinates smartSaverChk = new PDFFieldnameAndCoordinates("smartSaverChk", 16, 527);
		PDFFieldnameAndCoordinates homeInternetInBoxChk = new PDFFieldnameAndCoordinates("homeInternetInBoxChk", 153, 527);
		PDFFieldnameAndCoordinates unlimitedYoutubeChk = new PDFFieldnameAndCoordinates("unlimitedYoutubeChk", 16, 513);
		PDFFieldnameAndCoordinates unlimitedStreamingChk = new PDFFieldnameAndCoordinates("unlimitedStreamingChk", 153, 513);
		PDFFieldnameAndCoordinates unlimitedNetflixChk = new PDFFieldnameAndCoordinates("unlimitedNetflixChk", 16, 500);
		PDFFieldnameAndCoordinates unlimitedInternetChk = new PDFFieldnameAndCoordinates("unlimitedInternetChk", 153, 500);
		PDFFieldnameAndCoordinates gamingAddonChk = new PDFFieldnameAndCoordinates("gamingAddonChk", 153, 488);
		fieldMapper.put("smartSaverChk", smartSaverChk);
		fieldMapper.put("homeInternetInBoxChk", homeInternetInBoxChk);
		fieldMapper.put("unlimitedYoutubeChk", unlimitedYoutubeChk);
		fieldMapper.put("unlimitedStreamingChk", unlimitedStreamingChk);
		fieldMapper.put("unlimitedNetflixChk", unlimitedNetflixChk);
		fieldMapper.put("unlimitedInternetChk", unlimitedInternetChk);
		fieldMapper.put("gamingAddonChk", gamingAddonChk);
		
		
		//Customer User ID
		PDFFieldnameAndCoordinates firstChoice = new PDFFieldnameAndCoordinates("firstChoice", 50, 405);
		PDFFieldnameAndCoordinates secondChoice = new PDFFieldnameAndCoordinates("secondChoice", 210, 405);
		fieldMapper.put("firstChoice", firstChoice);
		fieldMapper.put("secondChoice", secondChoice);
		
		//Value Added Service
		PDFFieldnameAndCoordinates vasHomeInternetChk = new PDFFieldnameAndCoordinates("vasHomeInternetChk", 180, 370);
		PDFFieldnameAndCoordinates vasHomeInternetBrand = new PDFFieldnameAndCoordinates("vasHomeInternetBrand", 40, 352);
		PDFFieldnameAndCoordinates vasHomeInternetModel = new PDFFieldnameAndCoordinates("vasHomeInternetModel", 195, 352);
		PDFFieldnameAndCoordinates vasContract12Chk = new PDFFieldnameAndCoordinates("vasContract12Chk", 74, 330);
		PDFFieldnameAndCoordinates vasContract18Chk = new PDFFieldnameAndCoordinates("vasContract18Chk", 142, 330);
		PDFFieldnameAndCoordinates vasContract24Chk = new PDFFieldnameAndCoordinates("vasContract24Chk", 208, 330);
		fieldMapper.put("vasHomeInternetChk", vasHomeInternetChk);
		fieldMapper.put("vasHomeInternetBrand", vasHomeInternetBrand);
		fieldMapper.put("vasHomeInternetModel", vasHomeInternetModel);
		fieldMapper.put("vasContract12Chk", vasContract12Chk);
		fieldMapper.put("vasContract18Chk", vasContract18Chk);
		fieldMapper.put("vasContract24Chk", vasContract24Chk);
		
		//Non-Bahrain
		PDFFieldnameAndCoordinates nonBahrainCompanyName = new PDFFieldnameAndCoordinates("nonBahrainCompanyName", 74, 300);
		PDFFieldnameAndCoordinates nonBahrainCR = new PDFFieldnameAndCoordinates("nonBahrainCR", 40, 285);
		PDFFieldnameAndCoordinates nonBahrainSignature = new PDFFieldnameAndCoordinates("nonBahrainSignature", 50, 235, 100, 40);
		PDFFieldnameAndCoordinates nonBahrainStamp = new PDFFieldnameAndCoordinates("nonBahrainStamp", 195, 235);
		fieldMapper.put("nonBahrainCompanyName", nonBahrainCompanyName);
		fieldMapper.put("nonBahrainCR", nonBahrainCR);
		fieldMapper.put("nonBahrainSignature", nonBahrainSignature);
		fieldMapper.put("nonBahrainStamp", nonBahrainStamp);
		
		//Extra - Email
		PDFFieldnameAndCoordinates extraEmailFirstChoice = new PDFFieldnameAndCoordinates("extraEmailFirstChoice", 220, 212);
		PDFFieldnameAndCoordinates extraEmailSecondChoice = new PDFFieldnameAndCoordinates("extraEmailSecondChoice", 220, 197);
		fieldMapper.put("extraEmailFirstChoice", extraEmailFirstChoice);
		fieldMapper.put("extraEmailSecondChoice", extraEmailSecondChoice);
		
		//Service Termination
		PDFFieldnameAndCoordinates serviceTermPermanetChk = new PDFFieldnameAndCoordinates("serviceTermPermanetChk", 16, 157);
		PDFFieldnameAndCoordinates serviceTermTemporaryChk = new PDFFieldnameAndCoordinates("serviceTermTemporaryChk", 73, 157);
		PDFFieldnameAndCoordinates serviceTermPeriod = new PDFFieldnameAndCoordinates("serviceTermPeriod", 230, 155);
		fieldMapper.put("serviceTermPermanetChk", serviceTermPermanetChk);
		fieldMapper.put("serviceTermTemporaryChk", serviceTermTemporaryChk);
		fieldMapper.put("serviceTermPeriod", serviceTermPeriod);
		
		//Agreement
		PDFFieldnameAndCoordinates agreeCustomerName = new PDFFieldnameAndCoordinates("agreeCustomerName", 50, 80);
		PDFFieldnameAndCoordinates agreeCustomerSignature = new PDFFieldnameAndCoordinates("agreeCustomerSignature", 145, 80, 100, 40);
		PDFFieldnameAndCoordinates agreeCustomerDate = new PDFFieldnameAndCoordinates("agreeCustomerDate", 230, 80);
		fieldMapper.put("agreeCustomerName", agreeCustomerName);
		fieldMapper.put("agreeCustomerSignature", agreeCustomerSignature);
		fieldMapper.put("agreeCustomerDate", agreeCustomerDate);
		
		PDFFieldnameAndCoordinates broadBandAgreeName = new PDFFieldnameAndCoordinates("broadBandAgreeName", 50, 55);
		PDFFieldnameAndCoordinates broadBandAgreeSignature = new PDFFieldnameAndCoordinates("broadBandAgreeSignature", 145, 55, 100, 40);
		PDFFieldnameAndCoordinates broadBandAgreeDate = new PDFFieldnameAndCoordinates("broadBandAgreeDate", 230, 55);
		fieldMapper.put("broadBandAgreeName", broadBandAgreeName);
		fieldMapper.put("broadBandAgreeSignature", broadBandAgreeSignature);
		fieldMapper.put("broadBandAgreeDate", broadBandAgreeDate);
		

		PDFFieldnameAndCoordinates agreeStaffCode = new PDFFieldnameAndCoordinates("agreeStaffCode", 50, 20);
		PDFFieldnameAndCoordinates agreeStaffSignature = new PDFFieldnameAndCoordinates("agreeStaffSignature", 145, 20, 100, 40);
		PDFFieldnameAndCoordinates agreeStaffShop = new PDFFieldnameAndCoordinates("agreeStaffShop", 235, 20);
		fieldMapper.put("agreeStaffCode", agreeStaffCode);
		fieldMapper.put("agreeStaffSignature", agreeStaffSignature);
		fieldMapper.put("agreeStaffShop", agreeStaffShop);
		
		return fieldMapper;
	}
	
	public Map<String, PDFFieldnameAndCoordinates> getFieldNameAndCoordinateFixedLine(){
		Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		
		PDFFieldnameAndCoordinates fixedLineNewLineTelChk = new PDFFieldnameAndCoordinates("fixedLineNewLineTelChk", 495, 900);
		PDFFieldnameAndCoordinates fixedLineNewLineISDNChk = new PDFFieldnameAndCoordinates("fixedLineNewLineISDNChk", 495, 888);
		PDFFieldnameAndCoordinates fixedLineValueAddedServiceChk = new PDFFieldnameAndCoordinates("fixedLineValueAddedServiceChk", 495, 877);
		PDFFieldnameAndCoordinates fixedLineCeaseLine = new PDFFieldnameAndCoordinates("fixedLineCeaseLine", 495, 865);
		fieldMapper.put("fixedLineNewLineTelChk", fixedLineNewLineTelChk);
		fieldMapper.put("fixedLineNewLineISDNChk", fixedLineNewLineISDNChk);
		fieldMapper.put("fixedLineValueAddedServiceChk", fixedLineValueAddedServiceChk);
		fieldMapper.put("fixedLineCeaseLine", fixedLineCeaseLine);

		
		PDFFieldnameAndCoordinates fixedLineCustomerEmail = new PDFFieldnameAndCoordinates("fixedLineCustomerEmail", 115, 830);
		PDFFieldnameAndCoordinates fixedLineCustomerName = new PDFFieldnameAndCoordinates("fixedLineCustomerName", 390, 830);
		PDFFieldnameAndCoordinates fixedLineContactName = new PDFFieldnameAndCoordinates("fixedLineContactName", 120, 815);
		PDFFieldnameAndCoordinates fixedLineNationality = new PDFFieldnameAndCoordinates("fixedLineNationality", 395, 815);
		PDFFieldnameAndCoordinates fixedLineContactNumber = new PDFFieldnameAndCoordinates("fixedLineContactNumber", 120, 800);
		PDFFieldnameAndCoordinates fixedLineCPRIDNo = new PDFFieldnameAndCoordinates("fixedLineCPRIDNo", 395, 802);
		PDFFieldnameAndCoordinates fixedLineCRNo = new PDFFieldnameAndCoordinates("fixedLineCRNo", 395, 788);
		PDFFieldnameAndCoordinates fixedLineMobileNo = new PDFFieldnameAndCoordinates("fixedLineMobileNo", 450, 774);
		fieldMapper.put("fixedLineCustomerEmail", fixedLineCustomerEmail);
		fieldMapper.put("fixedLineCustomerName", fixedLineCustomerName);
		fieldMapper.put("fixedLineContactName", fixedLineContactName);
		fieldMapper.put("fixedLineNationality", fixedLineNationality);
		fieldMapper.put("fixedLineContactNumber", fixedLineContactNumber);
		fieldMapper.put("fixedLineCPRIDNo", fixedLineCPRIDNo);
		fieldMapper.put("fixedLineCRNo", fixedLineCRNo);
		fieldMapper.put("fixedLineMobileNo", fixedLineMobileNo);
		
		//Local Address
		PDFFieldnameAndCoordinates fixedLineLocalHouseOrBuilding = new PDFFieldnameAndCoordinates("fixedLineLocalHouseOrBuilding", 120, 748);
		PDFFieldnameAndCoordinates fixedLineLocalRoadOrStreet = new PDFFieldnameAndCoordinates("fixedLineLocalRoadOrStreet", 120, 733);
		PDFFieldnameAndCoordinates fixedLineLocalBlockNo = new PDFFieldnameAndCoordinates("fixedLineLocalBlockNo", 292, 733);
		PDFFieldnameAndCoordinates fixedLineLocalArea = new PDFFieldnameAndCoordinates("fixedLineLocalArea", 100, 720);
		PDFFieldnameAndCoordinates fixedLineLocalPOBox = new PDFFieldnameAndCoordinates("fixedLineLocalPOBox", 287, 720);
		fieldMapper.put("fixedLineLocalHouseOrBuilding", fixedLineLocalHouseOrBuilding);
		fieldMapper.put("fixedLineLocalRoadOrStreet", fixedLineLocalRoadOrStreet);
		fieldMapper.put("fixedLineLocalBlockNo", fixedLineLocalBlockNo);
		fieldMapper.put("fixedLineLocalArea", fixedLineLocalArea);
		fieldMapper.put("fixedLineLocalPOBox", fixedLineLocalPOBox);
		
		//Telephone Directory
		PDFFieldnameAndCoordinates fixedLineTeleDirYesChk = new PDFFieldnameAndCoordinates("fixedLineTeleDirYesChk", 73, 663);
		PDFFieldnameAndCoordinates fixedLineTeleDirNoChk = new PDFFieldnameAndCoordinates("fixedLineTeleDirNoChk", 241, 664);
		fieldMapper.put("fixedLineTeleDirYesChk", fixedLineTeleDirYesChk);
		fieldMapper.put("fixedLineTeleDirNoChk", fixedLineTeleDirNoChk);
		
		
		//Agreement
		PDFFieldnameAndCoordinates fixedLineAgreeAppName = new PDFFieldnameAndCoordinates("fixedLineAgreeAppName", 135, 192);
		PDFFieldnameAndCoordinates fixedLineAgreeAppSignature = new PDFFieldnameAndCoordinates("fixedLineAgreeAppSignature", 245, 192, 100, 40);
		PDFFieldnameAndCoordinates fixedLineAgreeAppDate = new PDFFieldnameAndCoordinates("fixedLineAgreeAppDate", 315, 192);
		PDFFieldnameAndCoordinates fixedLineAgreeCustName = new PDFFieldnameAndCoordinates("fixedLineAgreeCustName", 135, 177);
		PDFFieldnameAndCoordinates fixedLineAgreeCustSignature = new PDFFieldnameAndCoordinates("fixedLineAgreeCustSignature", 245, 177, 100, 40);
		PDFFieldnameAndCoordinates fixedLineAgreeCustDate = new PDFFieldnameAndCoordinates("fixedLineAgreeCustDate", 315, 177);
		fieldMapper.put("fixedLineAgreeAppName", fixedLineAgreeAppName);
		fieldMapper.put("fixedLineAgreeAppSignature", fixedLineAgreeAppSignature);
		fieldMapper.put("fixedLineAgreeAppDate", fixedLineAgreeAppDate);
		fieldMapper.put("fixedLineAgreeCustName", fixedLineAgreeCustName);
		fieldMapper.put("fixedLineAgreeCustSignature", fixedLineAgreeCustSignature);
		fieldMapper.put("fixedLineAgreeCustDate", fixedLineAgreeCustDate);
		
		return fieldMapper;
	}
	
	public Map<String, PDFFieldnameAndCoordinates> getFieldNameAndCoordinateFixedLineAndHomeInternet(){
		Map<String, PDFFieldnameAndCoordinates> fieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		Map<String, PDFFieldnameAndCoordinates> homeInternetFieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		Map<String, PDFFieldnameAndCoordinates> fixedLineFieldMapper = new HashMap<String, PDFFieldnameAndCoordinates>();
		
		fixedLineFieldMapper = getFieldNameAndCoordinateFixedLine();
		homeInternetFieldMapper = getFieldNameAndCoordinateHomeInternet();
		
		fieldMapper.putAll(fixedLineFieldMapper);
		fieldMapper.putAll(homeInternetFieldMapper);
		
		return fieldMapper;
	}

}
