package bt.batelco.storefront.pdf.util;

public class AcquisitionForm {
	
	private String requestType;
	private String customerName;
	private String customerNationality;
	private String customerCprId;
	private String customerCrId;
	private String customerMobileNumber;
	private String customerContactName;
	private String customerContactNumber;
	
	private String addressFlatNo;
	private String addressBuilding;
	private String addressRoad;
	private String addressBlock;
	private String customerEmail;
	
	private String telephoneDirectory;
	private String mobilePackage;
	
	private String productName;
	private String productBrand;
	private String productModel;
	private String productSerialNumber;
	private String productContractTerm;
	
	private String circuitNumber;
	private String preferredLang;
	private String activateEBilling;
	
	private String signImageData;

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerNationality() {
		return customerNationality;
	}

	public void setCustomerNationality(String customerNationality) {
		this.customerNationality = customerNationality;
	}

	public String getCustomerCprId() {
		return customerCprId;
	}

	public void setCustomerCprId(String customerCprId) {
		this.customerCprId = customerCprId;
	}

	public String getCustomerCrId() {
		return customerCrId;
	}

	public void setCustomerCrId(String customerCrId) {
		this.customerCrId = customerCrId;
	}

	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomerContactName() {
		return customerContactName;
	}

	public void setCustomerContactName(String customerContactName) {
		this.customerContactName = customerContactName;
	}

	public String getCustomerContactNumber() {
		return customerContactNumber;
	}

	public void setCustomerContactNumber(String customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public String getAddressFlatNo() {
		return addressFlatNo;
	}

	public void setAddressFlatNo(String addressFlatNo) {
		this.addressFlatNo = addressFlatNo;
	}

	public String getAddressBuilding() {
		return addressBuilding;
	}

	public void setAddressBuilding(String addressBuilding) {
		this.addressBuilding = addressBuilding;
	}

	public String getAddressRoad() {
		return addressRoad;
	}

	public void setAddressRoad(String addressRoad) {
		this.addressRoad = addressRoad;
	}

	public String getAddressBlock() {
		return addressBlock;
	}

	public void setAddressBlock(String addressBlock) {
		this.addressBlock = addressBlock;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getTelephoneDirectory() {
		return telephoneDirectory;
	}

	public void setTelephoneDirectory(String telephoneDirectory) {
		this.telephoneDirectory = telephoneDirectory;
	}

	public String getMobilePackage() {
		return mobilePackage;
	}

	public void setMobilePackage(String mobilePackage) {
		this.mobilePackage = mobilePackage;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getProductSerialNumber() {
		return productSerialNumber;
	}

	public void setProductSerialNumber(String productSerialNumber) {
		this.productSerialNumber = productSerialNumber;
	}

	public String getProductContractTerm() {
		return productContractTerm;
	}

	public void setProductContractTerm(String productContractTerm) {
		this.productContractTerm = productContractTerm;
	}

	public String getCircuitNumber() {
		return circuitNumber;
	}

	public void setCircuitNumber(String circuitNumber) {
		this.circuitNumber = circuitNumber;
	}

	public String getPreferredLang() {
		return preferredLang;
	}

	public void setPreferredLang(String preferredLang) {
		this.preferredLang = preferredLang;
	}

	public String getActivateEBilling() {
		return activateEBilling;
	}

	public void setActivateEBilling(String activateEBilling) {
		this.activateEBilling = activateEBilling;
	}

	public String getSignImageData() {
		return signImageData;
	}

	public void setSignImageData(String signImageData) {
		this.signImageData = signImageData;
	}
	
	

}