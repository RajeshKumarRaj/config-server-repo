package bt.batelco.storefront.pdf.util;

public class PDFConstants {
	
	public static final String POSTPAID = "Postpaid";
	public static final String MOBILE = "Mobile";
	public static final String MOBILE_INTERNET = "Mobile Internet";
	public static final String HOME_INTERNET = "Home Internet";

}
