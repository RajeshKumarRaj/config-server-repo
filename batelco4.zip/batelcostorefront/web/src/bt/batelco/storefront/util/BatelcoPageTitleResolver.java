package bt.batelco.storefront.util;

import de.hybris.platform.acceleratorservices.storefront.util.PageTitleResolver;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

public class BatelcoPageTitleResolver extends PageTitleResolver {

  @Override
  public String resolveCategoryPageTitle(CategoryModel category) {
    final StringBuilder stringBuilder = new StringBuilder();
    String displayedCategory = StringUtils.isNotEmpty(category.getTitle()) ? category.getTitle() : category.getName();
    stringBuilder.append(displayedCategory).append(TITLE_WORD_SEPARATOR);

    final CMSSiteModel currentSite = getCmsSiteService().getCurrentSite();
    if (currentSite != null) {
      stringBuilder.append(currentSite.getName());
    }

    return StringEscapeUtils.escapeHtml(stringBuilder.toString());
  }


}
