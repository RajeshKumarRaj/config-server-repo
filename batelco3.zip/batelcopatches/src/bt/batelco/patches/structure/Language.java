package bt.batelco.patches.structure;

import de.hybris.platform.patches.organisation.ImportLanguage;


/**
 * Languages enumeration used in import process.
 */
public enum Language implements ImportLanguage {

  EN("en");

  private String code;

  Language(final String code) {
    this.code = code;
  }

  @Override
  public String getCode() {
    return this.code;
  }
}
