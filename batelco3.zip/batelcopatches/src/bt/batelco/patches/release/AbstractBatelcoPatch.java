/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company. All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.patches.release;

import de.hybris.platform.commerceservices.setup.SetupSyncJobService;
import de.hybris.platform.cronjob.enums.CronJobResult;
import de.hybris.platform.cronjob.enums.CronJobStatus;
import de.hybris.platform.patches.AbstractPatch;
import de.hybris.platform.patches.internal.logger.PatchLogger;
import de.hybris.platform.patches.internal.logger.PatchLoggerFactory;
import de.hybris.platform.patches.organisation.ImportLanguage;
import de.hybris.platform.patches.organisation.StructureState;
import de.hybris.platform.servicelayer.cronjob.PerformResult;

import org.springframework.beans.factory.annotation.Required;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import bt.batelco.patches.structure.Environment;
import bt.batelco.patches.structure.Language;

import static de.hybris.platform.patches.internal.logger.PatchLogger.LoggingMode.HAC_CONSOLE;


/**
 * Project specific parent class for all patches. It works as facade giving nice API for Patches class and translate
 * calls to not project specific format.
 */
public abstract class AbstractBatelcoPatch extends AbstractPatch implements BatelcoPatch {

  private static final PatchLogger LOG = PatchLoggerFactory.getLogger(AbstractBatelcoPatch.class);

  protected static final String BATELCO_PRODUCT_CATALOG = "batelcoProductCatalog";
  protected static final String BATELCO_CONTENT_CATALOG = "batelcoContentCatalog";

  private static final String ENV_DIRECTORY = "env/";
  private static final String CREATING_ENVIRONMENT_DATA_FOR = "Creating environment data for {}";
  private String environment;

  @Resource
  private SetupSyncJobService setupSyncJobService;

  public AbstractBatelcoPatch(final String patchId, final String patchName, final StructureState structureState) {
    super(patchId, patchName, null, structureState);
  }

  @Override
  public void createProjectData(final StructureState structureState) {
    final boolean update = structureState != this.structureState;
    createGlobalData(update);
    createEnvironmentData(update);
    performSynchronization();
  }

  /**
   * Run the catalog sync for the specified catalog.
   *
   * @param catalogName catalog name
   */
  protected void performSynchronization(final String catalogName) {
    final PerformResult syncCronJobResult = setupSyncJobService.executeCatalogSyncJob(catalogName);
    if (isSyncRerunNeeded(syncCronJobResult)) {
      LOG.warn(HAC_CONSOLE, String.format("Catalog [%s] sync has issues.", catalogName));
    }
  }

  /**
   * This method is responsible for update global data (for all environments).
   *
   * @param update if set to true:<br/>
   *               only language specific files will be imported (assumption is that not language specific files
   *               were
   *               imported before since this is just update). It also means that data will uploaded only for
   *               languages
   *               defined for organisations defined in this structureState that weren't introduced for other
   *               organisations
   *               before
   */
  protected void createGlobalData(final boolean update) {
    final Set<ImportLanguage> importLanguages = prepareLanguages();
    createGlobalData(importLanguages, update);
  }

  /**
   * This method is responsible for update environment specific data.
   *
   * @param update if set to true:<br/>
   *               only language specific files will be imported (assumption is that not language specific files
   *               were
   *               imported before since this is just update). It also means that data will uploaded only for
   *               languages
   *               defined for organisations defined in this structureState that weren't introduced for other
   *               organisations
   *               before
   */
  protected void createEnvironmentData(final boolean update) {
    final Set<ImportLanguage> importLanguages = prepareLanguages();
    createEnvironmentData(importLanguages, update);
  }

  /**
   * This method is responsible to import impex data for given environments and languages.
   *
   * @param fileName     of impex to be imported
   * @param languages    for which data should be imported
   * @param environments collection of {@link Environment}
   * @param runAgain     if patch should be executed again
   */
  protected void importEnvironmentData(final String fileName, final Set<ImportLanguage> languages,
                                       final EnumSet<Environment> environments, final boolean runAgain) {
    if (containsCurrentEnvironment(environments)) {
      importData(ENV_DIRECTORY + fileName, null, languages, runAgain, null, null);
    }
  }

  private boolean containsCurrentEnvironment(final EnumSet<Environment> environments) {
    return environments.stream()
        .map(Environment::getCode)
        .anyMatch(s -> s.equalsIgnoreCase(getEnvironment()));
  }

  private Set<ImportLanguage> prepareLanguages() {
    Set<ImportLanguage> importLanguages = Collections.singleton(Language.EN);
    final String languages = importLanguages.stream().map(ImportLanguage::getCode).collect(Collectors.joining(","));
    LOG.info(HAC_CONSOLE, CREATING_ENVIRONMENT_DATA_FOR, languages);

    return importLanguages;
  }

  private boolean isSyncRerunNeeded(final PerformResult syncCronJobResult) {
    return syncCronJobResult == null
           || (CronJobStatus.FINISHED.equals(syncCronJobResult.getStatus()) && !CronJobResult.SUCCESS
        .equals(syncCronJobResult
                    .getResult()));
  }

  @Required
  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public String getEnvironment() {
    return environment;
  }
}
