package bt.batelco.patches.release;

import de.hybris.platform.patches.organisation.ImportLanguage;
import org.apache.commons.lang.StringUtils;
import java.util.Set;
import bt.batelco.patches.structure.StructureState;

public class Patchx137 extends  AbstractBatelcoPatch {


    public Patchx137() {
        super("1.3.7", "1.3.7", StructureState.V1);
    }

    @Override
    public String getPatchDescription() {
        return StringUtils.EMPTY;
    }

    @Override
    public void createGlobalData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
        importGlobalData("facebook-product-feed-changes.impex", languages, updateLanguagesOnly);
        importGlobalData("bug-fix-changes.impex", languages, updateLanguagesOnly);
    }

    @Override
    public void createEnvironmentData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
        //not needed
    }

    @Override
    public void performSynchronization() {
    }
}
