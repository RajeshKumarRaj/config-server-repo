package bt.batelco.patches.release;

import de.hybris.platform.patches.organisation.ImportLanguage;

import org.apache.commons.lang.StringUtils;

import java.util.Set;

import bt.batelco.patches.structure.StructureState;

public class Patchx133 extends AbstractBatelcoPatch {
  public Patchx133() {
    super("1.3.3", "1.3.3", StructureState.V1);
  }

  @Override
  public String getPatchDescription() {
    return StringUtils.EMPTY;
  }

  @Override
  public void createGlobalData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importGlobalData("updateCategoryName.impex", languages, updateLanguagesOnly);
    importGlobalData("homepage-banners.impex", languages, updateLanguagesOnly);
    importGlobalData("pdp-consent-and-texts.impex", languages, updateLanguagesOnly);
    importGlobalData("disable-pages.impex", languages, updateLanguagesOnly);
  }

  @Override
  public void createEnvironmentData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    //no needed for the moment
  }

  @Override
  public void performSynchronization() {
    performSynchronization(BATELCO_PRODUCT_CATALOG);
    performSynchronization(BATELCO_CONTENT_CATALOG);
  }
}
