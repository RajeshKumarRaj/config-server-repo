package bt.batelco.patches.release;

import de.hybris.platform.patches.organisation.ImportLanguage;

import org.apache.commons.lang.StringUtils;

import java.util.EnumSet;
import java.util.Set;

import bt.batelco.patches.structure.Environment;
import bt.batelco.patches.structure.StructureState;

public class Patchx130 extends AbstractBatelcoPatch {
  public Patchx130() {
    super("1.3.0", "1.3.0", StructureState.V1);
  }

  @Override
  public String getPatchDescription() {
    return StringUtils.EMPTY;
  }

  @Override
  public void createGlobalData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importGlobalData("allEnvImpex.impex", languages, updateLanguagesOnly);
    importGlobalData("BAT-169_preorder-changes.impex", languages, updateLanguagesOnly);
  }

  @Override
  public void createEnvironmentData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importEnvironmentData("impex_dev.impex", languages, EnumSet.of(Environment.DEV),
                          updateLanguagesOnly);
    importEnvironmentData("BAT-169_preorder-example.impex", languages, EnumSet.of(Environment.DEV, Environment.QA),
                          updateLanguagesOnly);
  }

  @Override
  public void performSynchronization() {
    performSynchronization(BATELCO_PRODUCT_CATALOG);
  }
}
