package bt.batelco.patches.release;

import de.hybris.platform.patches.organisation.ImportLanguage;

import org.apache.commons.lang.StringUtils;

import java.util.EnumSet;
import java.util.Set;

import bt.batelco.patches.structure.Environment;
import bt.batelco.patches.structure.StructureState;

public class Patchx134 extends AbstractBatelcoPatch {
  public Patchx134() {
    super("1.3.4", "1.3.4", StructureState.V1);
  }

  @Override
  public String getPatchDescription() {
    return StringUtils.EMPTY;
  }

  @Override
  public void createGlobalData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importGlobalData("addon_page.impex", languages, updateLanguagesOnly);
    importGlobalData("category-title-description-update.impex", languages, updateLanguagesOnly);
    importGlobalData("page-title-description-update.impex", languages, updateLanguagesOnly);
    importGlobalData("update-site-url-attributes.impex", languages, updateLanguagesOnly);
    importGlobalData("update-products.impex", languages, updateLanguagesOnly);
    importGlobalData("homepage-iphone-banner.impex", languages, updateLanguagesOnly);
    importGlobalData("configuration-update.impex", languages, updateLanguagesOnly);
  }

  @Override
  public void createEnvironmentData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importEnvironmentData("update-preorder-products.impex", languages, EnumSet.of(Environment.DEV, Environment.QA),
                          updateLanguagesOnly);
  }

  @Override
  public void performSynchronization() {
    performSynchronization(BATELCO_CONTENT_CATALOG);
    performSynchronization(BATELCO_PRODUCT_CATALOG);
  }
}
