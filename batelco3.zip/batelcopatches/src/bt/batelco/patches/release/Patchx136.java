package bt.batelco.patches.release;

import de.hybris.platform.patches.organisation.ImportLanguage;
import bt.batelco.patches.structure.Environment;
import bt.batelco.patches.structure.StructureState;
import java.util.EnumSet;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class Patchx136 extends AbstractBatelcoPatch {
  public Patchx136() {
    super("1.3.6", "1.3.6", StructureState.V1);
  }

  @Override
  public String getPatchDescription() {
    return StringUtils.EMPTY;
  }

  @Override
  public void createGlobalData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    importGlobalData("subscriptionterm.impex", languages, updateLanguagesOnly);
    importGlobalData("vat-labels.impex", languages, updateLanguagesOnly);
    importGlobalData("awaiting-payment-changes.impex", languages, updateLanguagesOnly);
  }

  @Override
  public void createEnvironmentData(Set<ImportLanguage> languages, boolean updateLanguagesOnly) {
    //not needed
  }

  @Override
  public void performSynchronization() {
  }
}
