/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company. All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.payment.service;

import org.springframework.http.ResponseEntity;

import bt.batelco.facades.payment.dto.InitRequest;


public interface BatelcoPaymentService
{
	String getHybrisLogoUrl(String logoCode);

	void createLogo(String logoCode);

	void methodCheck();

	ResponseEntity<String> initPaymentRequest(InitRequest initPaymentRequest);

	ResponseEntity<String> userRedirecttoPayment(String paymentCustomerRedirectURL);

}
