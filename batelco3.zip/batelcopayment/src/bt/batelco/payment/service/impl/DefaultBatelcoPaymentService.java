/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company. All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.payment.service.impl;

import static com.iquest.config.provider.IncorrectConfigurationActions.throwInvalidConfigException;
import static com.iquest.config.provider.IncorrectConfigurationActions.throwMissingConfigException;

import de.hybris.platform.catalog.model.CatalogUnawareMediaModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.exceptions.SystemException;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;

import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.iquest.config.service.ConfigProviderService;

import bt.batelco.facades.payment.dto.InitRequest;
import bt.batelco.payment.service.BatelcoPaymentService;


public class DefaultBatelcoPaymentService implements BatelcoPaymentService
{
	private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoPaymentService.class);

	private MediaService mediaService;
	private ModelService modelService;
	private FlexibleSearchService flexibleSearchService;
	private ConfigProviderService configProviderService;

	private static final String INIT_PAYMENT_URL_CFG_KEY = "payment.gateway.init.transaction.url";

	public RestTemplate getRestTemplate()
	{
		return restTemplate;
	}

	public void setRestTemplate(final RestTemplate restTemplate)
	{
		this.restTemplate = restTemplate;
	}

	private RestTemplate restTemplate;

	@Override
	public String getHybrisLogoUrl(final String logoCode)
	{
		final MediaModel media = mediaService.getMedia(logoCode);

		// Keep in mind that with Slf4j you don't need to check if debug is enabled, it is done under the hood.
		LOG.debug("Found media [code: {}]", media.getCode());

		return media.getURL();
	}

	@Override
	public void createLogo(final String logoCode)
	{
		final Optional<CatalogUnawareMediaModel> existingLogo = findExistingLogo(logoCode);

		final CatalogUnawareMediaModel media = existingLogo.isPresent() ? existingLogo.get()
				: modelService.create(CatalogUnawareMediaModel.class);
		media.setCode(logoCode);
		media.setRealFileName("sap-hybris-platform.png");
		modelService.save(media);

		mediaService.setStreamForMedia(media, getImageStream());
	}

	private final static String FIND_LOGO_QUERY = "SELECT {" + CatalogUnawareMediaModel.PK + "} FROM {"
			+ CatalogUnawareMediaModel._TYPECODE + "} WHERE {" + CatalogUnawareMediaModel.CODE + "}=?code";

	private Optional<CatalogUnawareMediaModel> findExistingLogo(final String logoCode)
	{
		final FlexibleSearchQuery fQuery = new FlexibleSearchQuery(FIND_LOGO_QUERY);
		fQuery.addQueryParameter("code", logoCode);

		try
		{
			return Optional.of(flexibleSearchService.searchUnique(fQuery));
		}
		catch (final SystemException e)
		{
			return Optional.empty();
		}
	}

	private InputStream getImageStream()
	{
		return DefaultBatelcoPaymentService.class.getResourceAsStream("/batelcopayment/sap-hybris-platform.png");
	}

	@Required
	public void setMediaService(final MediaService mediaService)
	{
		this.mediaService = mediaService;
	}

	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	@Required
	public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService)
	{
		this.flexibleSearchService = flexibleSearchService;
	}

	@Override
	public void methodCheck()
	{
		LOG.info("its working -- batelcoPaymentService");

	}

	@Override
	public ResponseEntity<String> initPaymentRequest(final InitRequest initPaymentRequest)
	{
		LOG.info("DefaultBatelcoPaymentService -- ResponseEntity()  -- its calling and gatewayURL" + getInitPaymentGatewayUrl());
		return getRestTemplate().postForEntity(getInitPaymentGatewayUrl(), initPaymentRequest, String.class);
	}

	public ConfigProviderService getConfigProviderService()
	{
		return configProviderService;
	}

	public void setConfigProviderService(final ConfigProviderService configProviderService)
	{
		this.configProviderService = configProviderService;
	}

	private String getInitPaymentGatewayUrl()
	{
		return getConfigProviderService().<String> get(INIT_PAYMENT_URL_CFG_KEY).conversion(source -> source)
				.onMissing(throwMissingConfigException()).onInvalid(throwInvalidConfigException()).convert();
	}

	@Override
	public ResponseEntity<String> userRedirecttoPayment(final String paymentCustomerRedirectURL)
	{
		// XXX Auto-generated method stub

		try
		{
			final URI uri = new URI(paymentCustomerRedirectURL);
			final HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setLocation(uri);
			return new ResponseEntity<String>(httpHeaders, HttpStatus.SEE_OTHER);
		}
		catch (final URISyntaxException e)
		{
			// XXX Auto-generated catch block
			e.printStackTrace();
			return null;
		}


	}

}
