/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2020 SAP SE
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 */
package bt.batelco.logger;


import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;


/**
 * Custom class used to log request/response for a REST integration between Hybris and a standalone component.
 */
public class BatelcoRestIntegrationLoggingInterceptor implements ClientHttpRequestInterceptor
{
	private static final Logger LOG = LoggerFactory.getLogger(BatelcoRestIntegrationLoggingInterceptor.class);

	@Override
	public ClientHttpResponse intercept(final HttpRequest httpRequest, final byte[] body,
			final ClientHttpRequestExecution clientHttpRequestExecution) throws IOException
	{
		logRequest(httpRequest, body);
		final ClientHttpResponse response = clientHttpRequestExecution.execute(httpRequest, body);

		if (isErrorResponse(response))
		{
			logErrorResponse(response);
		}
		else //if (LOG.isDebugEnabled())
		{
			logResponse(response);
		}

		return response;
	}

	private boolean isErrorResponse(final ClientHttpResponse response) throws IOException
	{
		final HttpStatus responseStatus = response.getStatusCode();
		final String responseBody = IOUtils.toString(response.getBody(), StandardCharsets.UTF_8);

		return responseStatus.is5xxServerError() || responseStatus.is4xxClientError() || StringUtils.isEmpty(responseBody);
	}

	private void logRequest(final HttpRequest request, final byte[] body)
	{
		LOG.info("======================================== Request begin ================================================");
		LOG.info("URI         : {}", request.getURI());
		LOG.info("Method      : {}", request.getMethod());
		LOG.info("Headers     : {}", request.getHeaders());
		LOG.info("Request body: {}", new String(body));
		LOG.info("======================================== Request End =================================================");
	}

	private void logResponse(final ClientHttpResponse response) throws IOException
	{
		LOG.info("======================================= Response begin ================================================");
		LOG.info("Status code  : {}", response.getRawStatusCode());
		LOG.info("Headers      : {}", response.getHeaders());
		LOG.info("Response body: {}", getResponseBody(response));
		LOG.info("======================================= Response end ==================================================");
	}

	private void logErrorResponse(final ClientHttpResponse response) throws IOException
	{
		final String responseBody = getResponseBody(response);

		LOG.error("===================================== Error Response begin ===========================================");
		LOG.error("Status code  : {}", response.getRawStatusCode());
		LOG.error("Headers      : {}", response.getHeaders());
		LOG.error("Response body: {}", StringUtils.isNotEmpty(responseBody) ? responseBody : StringUtils.EMPTY);
		LOG.error("==================================== Error Response end ==============================================");
	}

	private String getResponseBody(final ClientHttpResponse response) throws IOException
	{
		return IOUtils.toString(response.getBody(), StandardCharsets.UTF_8);
	}
}
