package bt.batelco.addon.validation;

/**
 * A validator for inputs.
 *
 * @param <T> input type
 */
public interface Validator<T> {

  /**
   * Validates the given input
   *
   * @param input input to be validated
   * @return validation result
   */
  ValidationResult validate(T input);
}
