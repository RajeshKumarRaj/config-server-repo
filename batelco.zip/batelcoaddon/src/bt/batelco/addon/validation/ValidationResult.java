package bt.batelco.addon.validation;

import java.util.ArrayList;
import java.util.List;


/**
 * Holds the result of a validation.
 * The errors are given as internationalized text resource keys.
 */
public class ValidationResult {

  private List<String> errors = new ArrayList<>();

  public void addError(String error) {
    errors.add(error);
  }

  public void setErrors(List<String> errors) {
    this.errors = errors;
  }

  public List<String> getErrors() {
    return errors;
  }

  public boolean isValid() {
    return errors.isEmpty();
  }
}
