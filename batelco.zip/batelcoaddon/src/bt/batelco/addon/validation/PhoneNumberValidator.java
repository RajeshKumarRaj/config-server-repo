package bt.batelco.addon.validation;


import java.util.regex.Pattern;

/**
 * Validator that checks if the input is a Bahrain phone number.
 */
public class PhoneNumberValidator implements Validator<String> {

  private static final String INVALID_PHONE_NUMBER = "basket.error.phoneNumber.invalid";

  private static final Pattern PHONE_NUMBER_REGEX = Pattern.compile("[0-9]{8}");

  @Override
  public ValidationResult validate(String input) {
    ValidationResult result = new ValidationResult();
    if (!PHONE_NUMBER_REGEX.matcher(input).matches()) {
      result.addError(INVALID_PHONE_NUMBER);
    }
    return result;
  }
}
