package bt.batelco.addon.jalo;

import bt.batelco.addon.constants.BatelcoaddonConstants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.extension.ExtensionManager;
import org.apache.log4j.Logger;

@SuppressWarnings("PMD")
public class BatelcoaddonManager extends GeneratedBatelcoaddonManager
{
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger( BatelcoaddonManager.class.getName() );
	
	public static final BatelcoaddonManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (BatelcoaddonManager) em.getExtension(BatelcoaddonConstants.EXTENSIONNAME);
	}
	
}
