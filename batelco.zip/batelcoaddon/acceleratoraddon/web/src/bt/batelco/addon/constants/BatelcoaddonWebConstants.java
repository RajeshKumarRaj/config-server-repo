/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.addon.constants;

/**
 * Global class for all Batelcoaddon web constants. You can add global constants for your extension into this class.
 */
public final class BatelcoaddonWebConstants // NOSONAR
{
	public static final String ADD_EDIT_DELIVERY_ADDRESS_PAGE = "pages/checkout/multi/addEditDeliveryAddressPage";
	  public static final String CHOOSE_DELIVERY_METHOD_PAGE = "pages/checkout/multi/chooseDeliveryMethodPage";
	  public static final String ADD_PAYMENT_METHOD_PAGE = "pages/checkout/multi/addPaymentMethodPage";
	  public static final String CHECKOUT_SUMMARY_PAGE = "pages/checkout/multi/checkoutSummaryPage";
	  
	  public static final String REDIRECT_TO_PAYMENT_PAGE = "checkout/multi/payment-method/add";

	  public static final String CART_REQUIRED_DOCUMENTS_ERROR = "cart.required.documents.error";
	  public static final String CART_ACQUISITION_FORM_MISSING_ERROR = "cart.acquisition.form.missing.error";

	  public static final String PAYMENT_DETAILS_FORM = "paymentDetailsForm";
	  public static final String BATELCO_PAYMENT_TYPES = "paymentTypes";
  private BatelcoaddonWebConstants() {
    //empty to avoid instantiating this constant class
  }

  // implement here constants used by this extension
}
