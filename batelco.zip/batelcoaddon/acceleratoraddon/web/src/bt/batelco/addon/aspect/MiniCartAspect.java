package bt.batelco.addon.aspect;

import org.aspectj.lang.ProceedingJoinPoint;

import bt.batelco.addon.controllers.BatelcoaddonControllerConstants;

/**
 * An aspect for MiniCart; returning cart pop-up from batelcoaddon instead of b2ctelcoaddon
 */
public class MiniCartAspect {

  public Object rolloverMiniCart(final ProceedingJoinPoint joinPoint) throws Throwable {
    joinPoint.proceed();
    return BatelcoaddonControllerConstants.Views.Fragments.Cart.CART_POPUP;
  }

}
