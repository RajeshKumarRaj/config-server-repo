package bt.batelco.addon.constants;

public class BatelcoValidationConstants {
  public static final int MAX_FIELD_LENGTH = 255;
  public static final int MAX_POSTCODE_LENGTH = 10;

  private BatelcoValidationConstants() {
    //empty to avoid instantiating this constant class
  }
}
