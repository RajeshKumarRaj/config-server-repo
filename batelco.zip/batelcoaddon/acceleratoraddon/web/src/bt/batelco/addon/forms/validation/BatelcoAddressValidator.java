package bt.batelco.addon.forms.validation;

import de.hybris.platform.acceleratorstorefrontcommons.forms.AddressForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.AddressValidator;

import org.apache.commons.lang.StringUtils;
import org.springframework.validation.Errors;

import bt.batelco.addon.constants.BatelcoValidationConstants;

/**
 * Validator for address forms.
 */
public class BatelcoAddressValidator extends AddressValidator {

  private static final int MAX_LENGTH = 255;
  private static final String ADDRESS_PHONE_ERROR_KEY = "address.phone.invalid";
  private static final String PHONE_FILED_NAME = "phone";

  @Override
  public void validate(Object object, Errors errors) {
    final AddressForm addressForm = (AddressForm) object;
    validateStandardFields(addressForm, errors);

    validatePhone(addressForm.getPhone(), MAX_LENGTH, errors);
  }

  @Override
  @SuppressWarnings("Duplicates")
  protected void validateStandardFields(final AddressForm addressForm, final Errors errors) {
    validateStringField(addressForm.getCountryIso(), AddressField.COUNTRY, BatelcoValidationConstants.MAX_FIELD_LENGTH,
                        errors);
    validateStringField(addressForm.getFirstName(), AddressField.FIRSTNAME, BatelcoValidationConstants.MAX_FIELD_LENGTH,
                        errors);
    validateStringField(addressForm.getLastName(), AddressField.LASTNAME, BatelcoValidationConstants.MAX_FIELD_LENGTH,
                        errors);
    validateStringField(addressForm.getLine1(), AddressField.LINE1, BatelcoValidationConstants.MAX_FIELD_LENGTH,
                        errors);
    validateStringField(addressForm.getTownCity(), AddressField.TOWN, BatelcoValidationConstants.MAX_FIELD_LENGTH,
                        errors);

    if (StringUtils.isNotEmpty(addressForm.getPostcode())) {
      validateStringField(addressForm.getPostcode(), AddressField.POSTCODE,
                          BatelcoValidationConstants.MAX_POSTCODE_LENGTH, errors);
    }
  }

  private void validatePhone(String addressField, int maxFieldLength, Errors errors) {
    if (addressField == null || StringUtils.isEmpty(addressField) || (StringUtils.length(addressField)
                                                                      > maxFieldLength)) {
      errors.rejectValue(PHONE_FILED_NAME, ADDRESS_PHONE_ERROR_KEY);
    }
  }
}
