package bt.batelco.addon.controllers.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.pdfbox.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import bt.batelco.addon.controllers.FileProcessor;
import bt.batelco.addon.forms.AcquisitionFormNew;
import bt.batelco.addon.forms.FileUploadForm;
import bt.batelco.facades.cart.BatelcoCartFacade;
import bt.batelco.facades.customer.BatelcoCustomerFacade;
import bt.batelco.facades.fileupload.FileUploadFacade;
import bt.batelco.storefront.pdf.util.AcquisitionForm;
import bt.batelco.storefront.pdf.util.PDFConstants;
import bt.batelco.storefront.pdf.util.PDFCoordinateMapper;
import bt.batelco.storefront.pdf.util.PDFGeneratedStreamData;
import bt.batelco.storefront.pdf.util.PDFUtils;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;

@Controller
@RequestMapping(value = "/acquisitionForm")
public class AcquisitionPageController extends AbstractPageController{
	
	private static final Logger LOG = LoggerFactory.getLogger(AcquisitionPageController.class);
	
	public static final String REDIRECT_TO_CART = REDIRECT_PREFIX + "/cart";
	
	/*@Resource(name = "cartFacade")
	private BatelcoCartFacade batelcoCartFacade;*/
	
	@Resource(name = "fileProcessor")
	private FileProcessor fileProcessor;
	
	@Resource(name = "fileUploadFacade")
	private FileUploadFacade fileUploadFacade;
	
	@Resource(name = "batelcoCartFacade")
	private BatelcoCartFacade batelcoCartFacade;
	
	@Resource(name = "batelcoCustomerFacade")
	private BatelcoCustomerFacade customerFacade;
	
	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;
	
	/*private CartService cartService;
	private MediaService mediaService;
	private BatelcoCartConfigService cartConfigService;*/
	
	
	
	
	
	 /*@RequestMapping(value = "/fill/acquisition-form/{entryNumber:.*}", method = RequestMethod.GET)
		public String showAcquisitionForm(@PathVariable("entryNumber") final int entryNumber,
				final Model model)
		{
		  System.out.println("*** AcquisitionPageController == showAcquisitionForm() Method *****");
			
		  
		  final CustomerData customerData = customerFacade.getCurrentCustomer();
		  String title = customerData.getTitleCode();
		  String displayUid = customerData.getDisplayUid();
		  String customerId = customerData.getCustomerId();
		  String firstName = customerData.getFirstName();
		  String lastName = customerData.getLastName();
		  String name = customerData.getName();
		  
		  
		  AddressData shippingAddressData = customerData.getDefaultShippingAddress();
		  
		  String addressLine1 = shippingAddressData.getLine1();
		  String addressLine2 = shippingAddressData.getLine2();
		  String town = shippingAddressData.getTown();
		  String postalCode = shippingAddressData.getPostalCode();
		  String phone = shippingAddressData.getPhone();
		  String email = shippingAddressData.getEmail();
		  
		  
		  
		  List<String> requestTypeList = new ArrayList<>();
		  requestTypeList.add("Choose...");
		  requestTypeList.add("New Customer");
		  requestTypeList.add("Change of Package");
		  requestTypeList.add("Renew Contract");
		  requestTypeList.add("New Device");
		  requestTypeList.add("SIM Replacement");
		  
		  List<String> mobilePackageList = new ArrayList<>();
		  mobilePackageList.add("Choose...");
		  mobilePackageList.add("Contracted 8 BD8.4");
		  mobilePackageList.add("Contracted 12 BD12.6");
		  mobilePackageList.add("Contracted 16 BD16.8");
		  mobilePackageList.add("Other...");
		  
		 
		  
		  return ControllerConstants.Views.Pages.Cart.AcquisitionFormPage_01;
		}*/
	 
	
	 
	
	private ProductData getProductData(int entryNumber) {
		ProductData productData = null;
		try {

			AbstractOrderEntryModel entry = batelcoCartFacade.getCartEntry(entryNumber);
			final List<ProductOption> PRODUCT_OPTIONS = Arrays.asList(ProductOption.BASIC, ProductOption.PRICE,
					ProductOption.CATEGORIES);

			final String productCode = entry.getProduct().getCode();
			productData = productFacade.getProductForCodeAndOptions(productCode, PRODUCT_OPTIONS);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return productData;
	}
	
	
	@RequestMapping(value = "/generate/generatePdfDocument01", method = RequestMethod.POST)
	public void generatePdfDocument01(@RequestBody AcquisitionFormNew acquisitionFormNew, 
			HttpServletRequest request, HttpServletResponse response) {
		//String responseString;

		/*System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Cart Entry Number == "
				+ acquisitionFormNew.getCartEntryNumber());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Product Name == "
				+ acquisitionFormNew.getProductName());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Contract name == "
				+ acquisitionFormNew.getContractName());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Product Category == "
				+ acquisitionFormNew.getProductCategory());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Customer Name == "
				+ acquisitionFormNew.getCustomerName());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Customer Id == "
				+ acquisitionFormNew.getCustomerId());*/
		try {

			String documentType = acquisitionFormNew.getProductCategory();
			int entryNumber = Integer.parseInt(acquisitionFormNew.getCartEntryNumber());

			AcquisitionForm acquisitionForm = new AcquisitionForm();

			final CustomerData customerData = customerFacade.getCurrentCustomer();
			String title = customerData.getTitleCode();
			String displayUid = customerData.getDisplayUid();
			String cprId = customerData.getCprId();
			String firstName = customerData.getFirstName();
			String lastName = customerData.getLastName();
			String name = customerData.getName();

			AddressData shippingAddressData = customerData.getDefaultShippingAddress();

			String addressLine1 = shippingAddressData.getLine1();
			String addressLine2 = shippingAddressData.getLine2();
			String town = shippingAddressData.getTown();
			String postalCode = shippingAddressData.getPostalCode();
			String phone = shippingAddressData.getPhone();
			String email = shippingAddressData.getEmail();

			ProductData productData = getProductData(entryNumber);
			String productCode = productData.getCode();
			String productName = productData.getName();

			PDFCoordinateMapper mapper = new PDFCoordinateMapper();
			String signature = mapper.getSignatureText();

			acquisitionForm.setCustomerName(name);
			acquisitionForm.setCustomerNationality("Indian");
			acquisitionForm.setCustomerCprId(cprId);
			acquisitionForm.setCustomerMobileNumber(phone);
			acquisitionForm.setCustomerContactName(name);
			acquisitionForm.setCustomerContactNumber(phone);
			acquisitionForm.setCustomerEmail(email);

			acquisitionForm.setAddressFlatNo(addressLine1);
			acquisitionForm.setAddressBuilding(addressLine2);
			acquisitionForm.setAddressRoad(town);
			acquisitionForm.setAddressBlock("4A");

			acquisitionForm.setSignImageData(signature);

			if (documentType.equalsIgnoreCase(PDFConstants.POSTPAID)) {
				acquisitionForm.setRequestType("New");
				acquisitionForm.setTelephoneDirectory("No");
				acquisitionForm.setMobilePackage(productName);

			} else if (documentType.equalsIgnoreCase(PDFConstants.MOBILE)) {
				// Apple iPhone XS Gold 64GB
				String prodNameSplit[] = productName.split(" ");
				String productBrand = prodNameSplit[0];

				int modelIndex = productName.indexOf(productBrand) + productBrand.length();
				String productModel = productName.substring(modelIndex, productName.length()).trim();
				/*String productContractName = acquisitionFormNew.getContractName();*/

				acquisitionForm.setProductBrand(productBrand);
				acquisitionForm.setProductModel(productModel);
				/*acquisitionForm.setProductContractTerm(productContractName);*/

			} else {

			}

			AbstractOrderEntryModel entry = batelcoCartFacade.getCartEntry(entryNumber);
			MediaModel documentMediaModel = batelcoCartFacade.getAcquisitionForm(entry);
			InputStream is = batelcoCartFacade.getStreamForMedia(documentMediaModel);

			PDFUtils pdfUtils = new PDFUtils();
			PDFGeneratedStreamData pdfGeneratedStreamData = pdfUtils.generatePDFDocumentFromStream(is, acquisitionForm,
					entryNumber, documentType);

			int entryNumber01 = pdfGeneratedStreamData.getEntryNumber();
			String documentName = pdfGeneratedStreamData.getDocumentName();
			InputStream pdfInputStream = pdfGeneratedStreamData.getPdfInputStream();
			

			int available = pdfInputStream.available();
			System.out
					.println("*** AcquisitionPageController == generatePdfDocument() Method available ===" + available);

			MultipartFile multipartFile = new MockMultipartFile(documentName, documentName, "application/pdf",
					IOUtils.toByteArray(pdfInputStream));
			
			System.out
			.println("*** AcquisitionPageController == generatePdfDocument() Method Created Multipart File ===" + multipartFile);

			FileUploadForm form = new FileUploadForm();
			form.setFile(multipartFile);
			
			System.out
			.println("*** AcquisitionPageController == generatePdfDocument() Method Created File upload Form ===" + form);


			ResponseEntity<String> responseEntity = fileProcessor.processForm(form,
					fileUploadFacade.getAcquisitionFormMaxSize(),
					inputStream -> fileUploadFacade.attachAcquisitionForm(form.getFile(), inputStream, entryNumber));
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Attached Generated PDF to cart entry ===" + entryNumber);
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Start File Download *****");
			
	        downloadFile(documentName, request, response);
		    
		    System.out.println("*** AcquisitionPageController == generatePdfDocument() Method End File Download *****");

		} catch (Exception e) {
			e.printStackTrace();
		}

		/*responseString = "Success";
		return responseString;*/
	}
	
	@RequestMapping(value = "/generate/generatePdfDocument/{entryNumber:.*}", method = RequestMethod.POST)
	public void generatePdfDocument(@PathVariable("entryNumber") final int entryNumber, 
			@ModelAttribute("acquisitionForm") final AcquisitionFormNew acquisitionFormNew, 
			HttpServletRequest request, HttpServletResponse response) {
		//String responseString;
		
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Path Variable Entry Number == "
				+ entryNumber);

		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Cart Entry Number == " + acquisitionFormNew.getCartEntryNumber());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Product Category == " + acquisitionFormNew.getProductCategory());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Contract Name == " + acquisitionFormNew.getContractName());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Contact name == " + acquisitionFormNew.getContactName());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Contact Number == " + acquisitionFormNew.getContactNumber());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Flat == " + acquisitionFormNew.getFlat());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Building == " + acquisitionFormNew.getBuilding());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Road == " + acquisitionFormNew.getRoad());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Block == " + acquisitionFormNew.getBlock());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Telephone Directory == " + acquisitionFormNew.getTelephoneDirectory());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Signature Data == " + acquisitionFormNew.getSignImageData());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Consent == " + acquisitionFormNew.getConsent());
		
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Circuit Number == " + acquisitionFormNew.getCircuitNumber());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Preferred language == " + acquisitionFormNew.getPreferredLang());
		System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Activate EBilling == " + acquisitionFormNew.getActivateEBilling());
		
		
		try {
			
			String contactName = checkNull(acquisitionFormNew.getContactName());
			String contactNumber = checkNull(acquisitionFormNew.getContactNumber());
			String flat = checkNull(acquisitionFormNew.getFlat());
			String building = checkNull(acquisitionFormNew.getBuilding());
			String road = checkNull(acquisitionFormNew.getRoad());
			String block = checkNull(acquisitionFormNew.getBlock());
			String telephoneDir = checkNull(acquisitionFormNew.getTelephoneDirectory());
			String signature = checkNull(acquisitionFormNew.getSignImageData());
			
			String circuitNumber = checkNull(acquisitionFormNew.getCircuitNumber());
			String preferredLanguage = checkNull(acquisitionFormNew.getPreferredLang());
			
			String activateEBilling = checkNull(acquisitionFormNew.getActivateEBilling());
			

			String documentType = acquisitionFormNew.getProductCategory();
			//int entryNumber = Integer.parseInt(acquisitionFormNew.getCartEntryNumber());

			AcquisitionForm acquisitionForm = new AcquisitionForm();

			final CustomerData customerData = customerFacade.getCurrentCustomer();
			String title = customerData.getTitleCode();
			String displayUid = customerData.getDisplayUid();
			String cprId = customerData.getCprId();
			String firstName = customerData.getFirstName();
			String lastName = customerData.getLastName();
			String name = customerData.getName();

			AddressData shippingAddressData = customerData.getDefaultShippingAddress();

			String addressLine1 = shippingAddressData.getLine1();
			String addressLine2 = shippingAddressData.getLine2();
			String town = shippingAddressData.getTown();
			String postalCode = shippingAddressData.getPostalCode();
			String phone = shippingAddressData.getPhone();
			String email = shippingAddressData.getEmail();

			ProductData productData = getProductData(entryNumber);
			String productCode = productData.getCode();
			String productName = productData.getName();
			
			System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Product Code == " + productCode);
			System.out.println("***** Acquisition Page Controller === generatePdfDocument01 === Product Name == " + productName);

			/*PDFCoordinateMapper mapper = new PDFCoordinateMapper();
			String signature = mapper.getSignatureText();*/

			acquisitionForm.setCustomerName(name);
			acquisitionForm.setCustomerNationality("Bahranian");
			acquisitionForm.setCustomerCprId(cprId);
			acquisitionForm.setCustomerMobileNumber(phone);
			acquisitionForm.setCustomerContactName(contactName);
			acquisitionForm.setCustomerContactNumber(contactNumber);
			acquisitionForm.setCustomerEmail(email);

			acquisitionForm.setAddressFlatNo(flat);
			acquisitionForm.setAddressBuilding(building);
			acquisitionForm.setAddressRoad(road);
			acquisitionForm.setAddressBlock(block);

			acquisitionForm.setSignImageData(signature);

			if (documentType.equalsIgnoreCase(PDFConstants.POSTPAID)
					|| documentType.equalsIgnoreCase(PDFConstants.MOBILE_INTERNET)) {
				System.out.println("***** Document Created for POSTPAID *****");
				acquisitionForm.setRequestType("New");
				acquisitionForm.setTelephoneDirectory(telephoneDir);
				acquisitionForm.setMobilePackage(productName);

			} else if (documentType.equalsIgnoreCase(PDFConstants.MOBILE)) {
				System.out.println("***** Document Created for MOBILE DEVICE *****");
				// Apple iPhone XS Gold 64GB
				acquisitionForm.setRequestType("miscellaneous");
				String prodNameSplit[] = productName.split(" ");
				String productBrand = prodNameSplit[0];

				int modelIndex = productName.indexOf(productBrand) + productBrand.length();
				String productModel = productName.substring(modelIndex, productName.length()).trim();
				String productContractName = acquisitionFormNew.getContractName();

				acquisitionForm.setProductBrand(productBrand);
				acquisitionForm.setProductModel(productModel);
				acquisitionForm.setProductContractTerm(productContractName);

			} else if(documentType.equalsIgnoreCase(PDFConstants.HOME_INTERNET)){
				acquisitionForm.setRequestType("New");
				acquisitionForm.setCircuitNumber(circuitNumber);
				acquisitionForm.setPreferredLang(preferredLanguage);
				acquisitionForm.setActivateEBilling(activateEBilling);
				acquisitionForm.setTelephoneDirectory(telephoneDir);
				acquisitionForm.setProductName(productName);
			}

			AbstractOrderEntryModel entry = batelcoCartFacade.getCartEntry(entryNumber);
			MediaModel documentMediaModel = batelcoCartFacade.getAcquisitionForm(entry);
			InputStream is = batelcoCartFacade.getStreamForMedia(documentMediaModel);

			PDFUtils pdfUtils = new PDFUtils();
			PDFGeneratedStreamData pdfGeneratedStreamData = pdfUtils.generatePDFDocumentFromStream(is, acquisitionForm,
					entryNumber, documentType);

			int entryNumber01 = pdfGeneratedStreamData.getEntryNumber();
			String documentName = pdfGeneratedStreamData.getDocumentName();
			InputStream pdfInputStream = pdfGeneratedStreamData.getPdfInputStream();
			

			int available = pdfInputStream.available();
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method available ===" + available);

			MultipartFile multipartFile = new MockMultipartFile(documentName, documentName, "application/pdf",
					IOUtils.toByteArray(pdfInputStream));
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Created Multipart File ===" + multipartFile);

			FileUploadForm form = new FileUploadForm();
			form.setFile(multipartFile);
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Created File upload Form ===" + form);


			ResponseEntity<String> responseEntity = fileProcessor.processForm(form,
					fileUploadFacade.getAcquisitionFormMaxSize(),
					inputStream -> fileUploadFacade.attachAcquisitionForm(form.getFile(), inputStream, entryNumber));
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Attached Generated PDF to cart entry ===" + entryNumber);
			
			System.out.println("*** AcquisitionPageController == generatePdfDocument() Method Start File Download *****");
			
	        downloadFile(documentName, request, response);
		    
		    System.out.println("*** AcquisitionPageController == generatePdfDocument() Method End File Download *****");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private String checkNull(String str) {
		String returnString = "";
		if(null == str) {
			returnString = "";
		}else {
			returnString = str.trim();
		}
		return returnString;
	}
	
	private void downloadFile(String filePath, HttpServletRequest request, HttpServletResponse response) {
		try {
			System.out.println("***** Calling Download File Method() *******");
			//File downloadFile = new File(targetPdf);
			File downloadFile = new File(filePath);
		    FileInputStream inStream = new FileInputStream(downloadFile);
		    String mimeType = request.getServletContext().getMimeType(filePath);
		    System.out.println("Mime Type ==== "+mimeType);
		    response.setContentType(mimeType);
		    response.setContentLength((int) downloadFile.length());
		    String headerKey = "Content-Disposition";
		    String headerValue = String.format("attachment; filename=\"%s\"", filePath);
		    response.setHeader(headerKey, headerValue);
		    
		    OutputStream outStream = response.getOutputStream();
		    byte[] buffer = new byte[4096];
		    int bytesRead = -1;
		    while ((bytesRead = inStream.read(buffer)) != -1){
		    	outStream.write(buffer, 0, bytesRead); 
		    }
		    inStream.close();
		    outStream.close();
		    System.out.println("***** File Downloaded Successfully.....!!! *******");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	 	
	/*@Required
	public void setCartService(CartService cartService) {
		this.cartService = cartService;
	}
	
	protected MediaService getMediaService() {
		return mediaService;
	}

	@Required
	public void setMediaService(MediaService mediaService) {
		this.mediaService = mediaService;
	}
	
	protected BatelcoCartConfigService getCartConfigService() {
		return cartConfigService;
	}

	@Required
	public void setCartConfigService(BatelcoCartConfigService cartConfigService) {
		this.cartConfigService = cartConfigService;
	}*/
	 	
	 	
	 	/*protected CartService getCartService()
		{
			return cartService;
		}*/
	 	
}
