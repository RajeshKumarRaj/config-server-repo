package bt.batelco.addon.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.b2ctelcoaddon.controllers.TelcoControllerConstants;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commercefacades.order.CheckoutFacade;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bt.batelco.addon.forms.BatelcoRegisterForm;
import bt.batelco.facades.cart.BatelcoCartFacade;

import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CART_ACQUISITION_FORM_MISSING_ERROR;
import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CART_REQUIRED_DOCUMENTS_ERROR;
import static de.hybris.platform.b2ctelcoaddon.controllers.pages.CartPageController.REDIRECT_TO_CART_URL;

/**
 * Checkout Login Controller. Handles login and register for the checkout flow.
 * This controller was added to override TelcoCheckoutLoginController, in order to use BatelcoRegisterForm
 */
@Controller
@RequestMapping(value = "/login/checkout")
public class BatelcoCheckoutLoginController extends BatelcoAbstractLoginPageController {

  @Resource(name = "acceleratorCheckoutFacade")
  private CheckoutFacade checkoutFacade;

  @Resource(name = "cartFacade")
  private BatelcoCartFacade batelcoCartFacade;

  protected CheckoutFacade getCheckoutFacade() {
    return checkoutFacade;
  }

  @Override
  protected String getView() {
    return TelcoControllerConstants.Views.Pages.Checkout.CHECKOUT_LOGIN_PAGE;
  }

  @Override
  protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response) {
    return "/";
  }

  @Override
  protected AbstractPageModel getCmsPage() throws CMSItemNotFoundException {
    return getContentPageForLabelOrId("checkout-login");
  }

  @RequestMapping(method = RequestMethod.GET)
  public String doCheckoutLogin(@RequestParam(value = "error", defaultValue = "false") final boolean loginError,
                                final HttpSession session, final Model model, final RedirectAttributes redirectModel)
      throws CMSItemNotFoundException {

    if (!batelcoCartFacade.isAcquisitionFormConfiguredOnEntries()) {
      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
                                     CART_ACQUISITION_FORM_MISSING_ERROR, null);
      return REDIRECT_TO_CART_URL;
    }

    if (!batelcoCartFacade.hasAllRequiredDocuments()) {
      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
                                     CART_REQUIRED_DOCUMENTS_ERROR, null);
      return REDIRECT_TO_CART_URL;
    }

    return getDefaultLoginPage(loginError, session, model);
  }

  /**
   * Registration.
   */
  @RequestMapping(value = "/register", method = RequestMethod.POST)
  public String doRegister(@ModelAttribute("registerForm") final BatelcoRegisterForm form,
                           final BindingResult bindingResult, final Model model, final HttpServletRequest request,
                           final HttpServletResponse response, final RedirectAttributes redirectModel)
      throws CMSItemNotFoundException {
    return processRegisterUserRequest(null, form, bindingResult, model, request, response, redirectModel);
  }
}
