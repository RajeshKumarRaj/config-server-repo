package bt.batelco.addon.forms.validation;

import org.apache.commons.lang.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class BatelcoPaymentTypeValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    return String.class.equals(aClass);
  }

  @Override
  public void validate(Object o, Errors errors) {
    final String paymentTypeCode = (String) o;
    if (StringUtils.isEmpty(paymentTypeCode)) {
      errors.rejectValue("paymentTypeCode", "payment.type.invalid");
      return;
    }
  }
}
