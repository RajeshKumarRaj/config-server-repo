package bt.batelco.addon.controllers;

import de.hybris.platform.commerceservices.i18n.CommerceCommonI18NService;
import de.hybris.platform.core.locking.ItemLockedForProcessingException;
import de.hybris.platform.core.suspend.SystemIsSuspendedException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.servicelayer.exceptions.ModelSavingException;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.io.IOException;
import java.io.InputStream;
import java.util.function.Consumer;

import javax.annotation.Resource;

import bt.batelco.addon.forms.FileUploadForm;

public class FileProcessor {
  private static final Logger LOG = LoggerFactory.getLogger(FileProcessor.class);
  private static final String FILE_UPLOAD_ERROR = "file.upload.error";
  private static final String FILE_UPLOAD_ERROR_MIME_TYPE = "file.upload.error.mimeType";
  private static final String FILE_UPLOAD_ERROR_MAX_SIZE = "file.upload.error.maxSize";

  @Resource(name = "messageSource")
  private MessageSource messageSource;

  @Resource(name = "commerceCommonI18NService")
  private CommerceCommonI18NService i18NService;

  public ResponseEntity<String> processForm(FileUploadForm form, Double maxSize,
                                            Consumer<InputStream> inputStreamConsumer) {
    if (form == null || form.getFile() == null) {
      LOG.error("Uploaded form or file cannot be null");
      return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
    try (final InputStream inputStream = form.getFile().getInputStream()) {
      inputStreamConsumer.accept(inputStream);
      return new ResponseEntity<>(HttpStatus.OK);
    } catch (final IOException | SystemIsSuspendedException | ItemLockedForProcessingException | ModelSavingException | JaloSystemException e) {
      LOG.error("An error occurred while uploading form", e);
      return new ResponseEntity<>(messageSource.getMessage(FILE_UPLOAD_ERROR, null, i18NService.getCurrentLocale()),
                                  HttpStatus.INTERNAL_SERVER_ERROR);
    } catch (final IllegalArgumentException e) {
      LOG.error("File mime type not supported");
      return new ResponseEntity<>(
          messageSource.getMessage(FILE_UPLOAD_ERROR_MIME_TYPE, null, i18NService.getCurrentLocale()),
          HttpStatus.BAD_REQUEST);
    } catch (final MaxUploadSizeExceededException e) {
      LOG.error("File exceeds max size limit");
      String humanReadableMaxSize = FileUtils.byteCountToDisplaySize(maxSize.longValue());
      return new ResponseEntity<>(
          messageSource.getMessage(FILE_UPLOAD_ERROR_MAX_SIZE, new String[]{humanReadableMaxSize},
                                   i18NService.getCurrentLocale()),
          HttpStatus.BAD_REQUEST);
    }
  }

}
