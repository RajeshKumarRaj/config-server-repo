package bt.batelco.addon.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.b2ctelcoaddon.controllers.TelcoControllerConstants;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bt.batelco.addon.forms.BatelcoRegisterForm;

/**
 * Login Controller. Handles login and register for the account flow.
 * This controller was added to override TelcoLoginPageController, in order to use BatelcoRegisterForm and other
 * classes related to batelco business logic
 */
@Controller
@RequestMapping(value = "/login")
public class BatelcoLoginPageController extends BatelcoAbstractLoginPageController {

  private static final Logger LOG = LoggerFactory.getLogger(BatelcoLoginPageController.class);
  private static final String REGISTRATION_CONFIRMATION_SUCCESS = "registration.confirmation.success";
  private static final String REGISTRATION_CONFIRMATION_ERROR = "registration.confirmation.error";

  private HttpSessionRequestCache httpSessionRequestCache;

  @RequestMapping(method = RequestMethod.GET)
  public String doLogin(@RequestHeader(value = "referer", required = false) final String referer,
                        @RequestParam(value = "error", defaultValue = "false") final boolean loginError,
                        final Model model, final HttpServletRequest request, final HttpServletResponse response,
                        final HttpSession session) throws CMSItemNotFoundException {

    if (!loginError) {
      storeReferer(referer, request, response);
    }
    return getDefaultLoginPage(loginError, session, model);
  }

  /**
   * Registration.
   */
  @RequestMapping(value = "/register", method = RequestMethod.POST)
  public String doRegister(@RequestHeader(value = "referer", required = false) final String referer,
                           @ModelAttribute("registerForm") final BatelcoRegisterForm form,
                           final BindingResult bindingResult,
                           final Model model, final HttpServletRequest request, final HttpServletResponse response,
                           final RedirectAttributes redirectModel) throws CMSItemNotFoundException {

    return processRegisterUserRequest(referer, form, bindingResult, model, request, response, redirectModel);
  }

  @RequestMapping(value = "/confirmRegistration", method = RequestMethod.GET)
  public String confirmRegistration(@RequestParam(value = "registrationId", required = false) final String customerId,
                                    final Model model, final HttpServletRequest request,
                                    final HttpServletResponse response, final RedirectAttributes redirectModel)
      throws CMSItemNotFoundException {
    String messageKey = REGISTRATION_CONFIRMATION_SUCCESS;
    try {
      getBatelcoCustomerFacade().updateCustomerRegistration(customerId);
    } catch (Exception ex) {
      LOG.warn("Registration confirmation error", ex);
      messageKey = REGISTRATION_CONFIRMATION_ERROR;
    }

    GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, messageKey);
    return REDIRECT_PREFIX + getSuccessRedirect(request, response);
  }

  private void storeReferer(final String referer, final HttpServletRequest request,
                            final HttpServletResponse response) {
    if (StringUtils.isNotBlank(referer)) {
      httpSessionRequestCache.saveRequest(request, response);
    }
  }

  @Override
  protected String getView() {
    return TelcoControllerConstants.Views.Pages.Account.ACCOUNT_LOGIN_PAGE;
  }

  @Override
  protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response) {
    if (httpSessionRequestCache.getRequest(request, response) != null) {
      return httpSessionRequestCache.getRequest(request, response).getRedirectUrl();
    }
    return "/";
  }

  @Override
  protected AbstractPageModel getCmsPage() throws CMSItemNotFoundException {
    return getContentPageForLabelOrId("login");
  }

  @Autowired
  @Qualifier("httpSessionRequestCache")
  public void setHttpSessionRequestCache(final HttpSessionRequestCache accHttpSessionRequestCache) {
    this.httpSessionRequestCache = accHttpSessionRequestCache;
  }

}
