package bt.batelco.addon.breadcrumb.impl;

import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.Breadcrumb;
import de.hybris.platform.b2ctelcoaddon.breadcrumb.TmaProductOfferingBreadcrumbBuilder;
import de.hybris.platform.catalog.model.classification.ClassificationClassModel;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.variants.model.VariantCategoryModel;

import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Custom Batelco product breadcrumb builder.
 */
public class BatelcoProductBreadcrumbBuilder extends TmaProductOfferingBreadcrumbBuilder {

  private static final String LAST_LINK_CLASS = "active";

  @Override
  public List<Breadcrumb> getBreadcrumbs(String productCode) {
    final ProductModel productModel = getProductService().getProductForCode(productCode);
    final List<Breadcrumb> breadcrumbs = new ArrayList<>();
    final Collection<CategoryModel> categoryModels = new ArrayList<>();

    final ProductModel baseProductModel = getBaseProduct(productModel);
    final Breadcrumb last = getProductBreadcrumb(baseProductModel);
    categoryModels.addAll(baseProductModel.getSupercategories());
    last.setLinkClass(LAST_LINK_CLASS);
    breadcrumbs.add(last);

    while (!categoryModels.isEmpty()) {
      CategoryModel toDisplay = null;
      toDisplay = processCategoryModels(categoryModels, toDisplay);
      categoryModels.clear();

      if (toDisplay != null) {
        if (toDisplay.getVisible() == Boolean.TRUE) {
          breadcrumbs.add(getCategoryBreadcrumb(toDisplay));
        }
        categoryModels.addAll(toDisplay.getSupercategories());
      }
    }

    Collections.reverse(breadcrumbs);
    return breadcrumbs;
  }

  @Override
  protected CategoryModel processCategoryModels(Collection<CategoryModel> categoryModels, CategoryModel toDisplay) {
    Optional<CategoryModel> priorityCategory =
        categoryModels.stream().filter(categoryModel -> categoryModel.getOrder() != null).findFirst();
    if (priorityCategory.isPresent()) {
      return priorityCategory.get();
    }

    CategoryModel categoryToDisplay = toDisplay;
    for (final CategoryModel categoryModel : categoryModels) {
      if (!(categoryModel instanceof ClassificationClassModel) &&
          !(categoryModel instanceof VariantCategoryModel) &&
          CollectionUtils.isNotEmpty(categoryModel.getSupercategories())) {
        if (categoryToDisplay == null) {
          categoryToDisplay = categoryModel;
        }
        if (getBrowseHistory().findEntryMatchUrlEndsWith(categoryModel.getCode()) != null) {
          break;
        }
      }
    }
    return categoryToDisplay;
  }
}
