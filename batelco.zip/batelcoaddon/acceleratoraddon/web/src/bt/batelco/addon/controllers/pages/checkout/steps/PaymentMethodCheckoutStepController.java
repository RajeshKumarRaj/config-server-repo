package bt.batelco.addon.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.AddressForm;
import de.hybris.platform.acceleratorstorefrontcommons.util.AddressDataUtil;
import de.hybris.platform.b2ctelcoaddon.controllers.util.CartHelper;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

import javax.annotation.Resource;

import bt.batelco.addon.controllers.FileProcessor;
import bt.batelco.addon.forms.FileUploadForm;
import bt.batelco.addon.forms.PaymentDetailsForm;
//import bt.batelco.addon.forms.validation.BatelcoPaymentTypeValidator;
import bt.batelco.facades.fileupload.FileUploadFacade;
import bt.batelco.facades.order.BatelcoCheckoutFacade;

import static bt.batelco.addon.constants.BatelcoaddonWebConstants.ADD_PAYMENT_METHOD_PAGE;
import static bt.batelco.addon.constants.BatelcoaddonWebConstants.BATELCO_PAYMENT_TYPES;
import static bt.batelco.addon.constants.BatelcoaddonWebConstants.PAYMENT_DETAILS_FORM;

@Controller
@RequestMapping(value = "/checkout/multi/payment-method")
public class PaymentMethodCheckoutStepController
    extends de.hybris.platform.b2ctelcoaddon.controllers.pages.checkout.steps.PaymentMethodCheckoutStepController {

  private static final String PAYMENT_EVIDENCE_MIME_TYPES = "paymentEvidenceMimeTypes";
  private static final String MAX_SIZE = "maxSize";
  private static final String PAYMENT_EVIDENCE_MISSING_ERROR_CODE = "checkout.multi.paymentEvidence.upload.missing";
  private static final String PAGE_TYPE = "pageType";
  private static final String CHECKOUT_STEP_NUMBER = "checkoutStepNumber";
  private static final String CHECKOUT_STEPS = "checkoutSteps";

  @Resource(name = "addressDataUtil")
  private AddressDataUtil addressDataUtil;

  @Resource(name = "fileProcessor")
  private FileProcessor fileProcessor;

  @Resource(name = "fileUploadFacade")
  private FileUploadFacade fileUploadFacade;

//  @Resource(name = "batelcoPaymentTypeValidator")
//  private BatelcoPaymentTypeValidator batelcoPaymentTypeValidator;

  @Override
  @RequestMapping(value = "/add", method = RequestMethod.GET)
  @RequireHardLogIn
  @PreValidateCheckoutStep(checkoutStep = PAYMENT_METHOD)
  public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws
                                                                                         CMSItemNotFoundException {
	  
	 System.out.println("--1 -- custom_batelco_batelcoaddon_acceleratoraddon_web_src_bt_batelco_addon_controllers_pages_checkout_steps_PaymentMethodCheckoutStepController");
    super.enterStep(model, redirectAttributes);
    setCheckoutStepNumber(model);
    model.addAttribute(PAYMENT_DETAILS_FORM, new PaymentDetailsForm());
    model.addAttribute(PAYMENT_EVIDENCE_MIME_TYPES, fileUploadFacade.getAllPaymentEvidenceMimeTypes());
    model.addAttribute(MAX_SIZE, fileUploadFacade.getPaymentEvidenceMaxSize());
    model.addAttribute(PAGE_TYPE, PageType.CHECKOUT_PAYMENT.name());
    model.addAttribute(BATELCO_PAYMENT_TYPES, getBatelcoCheckoutFacade().getCheckoutPaymentTypes());
    for(StandardPaymentModeModel standardPaymentModeModel : getBatelcoCheckoutFacade().getOnlinePaymentModes()) {
    	if(standardPaymentModeModel.getOnline() && standardPaymentModeModel.getChildren() != null  ) {
    		model.addAttribute("modeOfPayment",standardPaymentModeModel.getChildren());
    	}
    }
    
    return ADD_PAYMENT_METHOD_PAGE;
  }

  private void setCheckoutStepNumber(Model model) {
    List<CheckoutSteps> checkoutSteps = (List) model.asMap().get(CHECKOUT_STEPS);
    checkoutSteps.stream().filter(step -> step.getProgressBarId().equals(getCheckoutStep().getProgressBarId()))
        .findAny().ifPresent(found ->
                                 model.addAttribute(CHECKOUT_STEP_NUMBER, found.getStepNumber())
    );
  }

  @RequestMapping(value = "/add/billingAddress", method = RequestMethod.POST)
  @RequireHardLogIn
  public String add(final Model model, final PaymentDetailsForm paymentDetailsForm, final BindingResult bindingResult)
      throws CMSItemNotFoundException {
    setupPage(model);

    final CartData cartData = getCheckoutFacade().getCheckoutCart();
    if (cartData.getPreorder()) {
      if (cartData.isPreorderFee() && cartData.getPaymentEvidence() == null) {
        GlobalMessages.addErrorMessage(model, PAYMENT_EVIDENCE_MISSING_ERROR_CODE);
        return ADD_PAYMENT_METHOD_PAGE;
      }
    } else {
      //batelcoPaymentTypeValidator.validate(paymentDetailsForm.getPaymentTypeCode(), bindingResult);
      System.out.println("Payment mode" + paymentDetailsForm.getPaymentMode());
      model.addAttribute("paymentMode", paymentDetailsForm.getPaymentMode());
      if (bindingResult.hasErrors()) {
        return ADD_PAYMENT_METHOD_PAGE;
      }
    }

    AddressData billingAddress;

    if (paymentDetailsForm.isUseDeliveryAddress()) {
      billingAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
    } else {
      AddressForm addressForm = paymentDetailsForm.getBillingAddressForm();
      validateAddress(bindingResult, addressForm);

      if (bindingResult.hasErrors()) {
        GlobalMessages
            .addErrorMessage(model, "checkout.multi.paymentMethod.createSubscription.billingAddress.noneSelectedMsg");
        return ADD_PAYMENT_METHOD_PAGE;
      }

      if (paymentDetailsForm.isSaveInAddressBook()) {
        billingAddress = addNewAddressInAddressBookAsShippingAddress(addressForm);
      } else {
        billingAddress = constructNewAddress(paymentDetailsForm.getBillingAddressForm());
      }
    }

    billingAddress.setBillingAddress(true);

    model.addAttribute("billingAddress", billingAddress);
    getBatelcoCheckoutFacade().setInvoicePaymentDetails(billingAddress, paymentDetailsForm.getPaymentTypeCode());
    setCheckoutStepLinksForModel(model, getCheckoutStep());
    return getCheckoutStep().nextStep();
  }

  @ResponseBody
  @RequestMapping(value = "/upload/payment-evidence", method = RequestMethod.POST)
  public ResponseEntity<String> handlePaymentEvidenceUpload(
      @ModelAttribute("fileUploadForm") final FileUploadForm form) {
    return fileProcessor.processForm(form, fileUploadFacade.getPaymentEvidenceMaxSize(),
                                     inputStream -> fileUploadFacade
                                         .attachPaymentEvidence(form.getFile(), inputStream));
  }

  private void setupPage(Model model) throws CMSItemNotFoundException {
    setupAddPaymentPage(model);
    final CartData cartData = getCheckoutFacade().getCheckoutCart();
    cartData.setEntries(CartHelper.removeEmptyEntries(cartData.getEntries()));
    model.addAttribute(ATTR_CART_DATA, cartData);
    model.addAttribute("deliveryAddress", cartData.getDeliveryAddress());
    model.addAttribute(BATELCO_PAYMENT_TYPES, getBatelcoCheckoutFacade().getCheckoutPaymentTypes());
  }

  private void validateAddress(BindingResult bindingResult, AddressForm addressForm) {
    bindingResult.pushNestedPath("billingAddressForm");
    getAddressValidator().validate(addressForm, bindingResult);
    bindingResult.popNestedPath();
  }

  private AddressData addNewAddressInAddressBookAsShippingAddress(AddressForm addressForm) {
    AddressData newAddressData = constructNewAddress(addressForm);
    getUserFacade().addAddress(newAddressData);
    return newAddressData;
  }

  private AddressData constructNewAddress(final AddressForm addressForm) {
    AddressData addressData = getAddressDataUtil().convertToAddressData(addressForm);
    addressData.setVisibleInAddressBook(true);
    return addressData;
  }


  private AddressDataUtil getAddressDataUtil() {
    return addressDataUtil;
  }

  private BatelcoCheckoutFacade getBatelcoCheckoutFacade() {
    return (BatelcoCheckoutFacade) getCheckoutFacade();
  }

}
