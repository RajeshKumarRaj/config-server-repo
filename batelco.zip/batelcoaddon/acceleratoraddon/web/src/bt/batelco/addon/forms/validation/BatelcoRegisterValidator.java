package bt.batelco.addon.forms.validation;

import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.RegistrationValidator;
import de.hybris.platform.commerceservices.enums.CountryType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.validation.Errors;

import bt.batelco.addon.forms.BatelcoRegisterForm;
import bt.batelco.facades.country.BatelcoCountryFacade;

import bt.batelco.addon.constants.BatelcoValidationConstants;

/**
 * Validates registration forms.
 */
public class BatelcoRegisterValidator extends RegistrationValidator {

  private BatelcoCountryFacade batelcoCountryFacade;

  @Override
  public void validate(final Object object, final Errors errors) {
    super.validate(object, errors);
    final BatelcoRegisterForm registerForm = (BatelcoRegisterForm) object;
    validateField(errors, registerForm.getCprId(), "cprId", "register.cprId.invalid");
    validateField(errors, registerForm.getPhone(), "phone", "register.phone.invalid");
    validateCountry(errors, registerForm.getCountry(), "country", "register.country.invalid");
    validateField(errors, registerForm.getCity(), "city", "register.city.invalid");
    validateField(errors, registerForm.getAddressLine1(), "addressLine1", "register.addressLine1.invalid");
    if (StringUtils.isNotEmpty(registerForm.getAddressLine2())) {
      validateField(errors, registerForm.getAddressLine1(), "addressLine2", "register.addressLine2.invalid");
    }

    validateZipCode(errors, registerForm.getZipCode(), "zipCode", "register.zipCode.invalid");
  }

  protected void validateTitleCode(final Errors errors, final String titleCode) {
    //empty because titleCode is not present on registration form and in OOTB implementation was present
  }

  protected void validateCountry(final Errors errors, final String countryCode, final String propertyName,
                                 final String property) {

    boolean anyMatch = batelcoCountryFacade.getCountries(CountryType.SHIPPING).stream()
        .anyMatch(p -> p.getIsocode().equalsIgnoreCase(countryCode));

    if (!anyMatch) {
      errors.rejectValue(propertyName, property);
    }
  }

  private void validateField(final Errors errors, final String name, final String propertyName,
                             final String property) {
    if (StringUtils.isBlank(name) || StringUtils.length(name) > BatelcoValidationConstants.MAX_FIELD_LENGTH) {
      errors.rejectValue(propertyName, property);
    }
  }

  private void validateZipCode(final Errors errors, final String name, final String propertyName,
                             final String property) {
    if (StringUtils.isNotEmpty(name) && StringUtils.length(name) > BatelcoValidationConstants.MAX_POSTCODE_LENGTH) {
      errors.rejectValue(propertyName, property);
    }
  }

  @Required
  public void setBatelcoCountryFacade(BatelcoCountryFacade batelcoCountryFacade) {
    this.batelcoCountryFacade = batelcoCountryFacade;
  }
}
