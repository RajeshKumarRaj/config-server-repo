package bt.batelco.addon.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CHOOSE_DELIVERY_METHOD_PAGE;

/**
 * Delivery method page controller.
 */
@Controller
@RequestMapping(value = "/checkout/multi/delivery-method")
public class DeliveryMethodCheckoutStepController
    extends de.hybris.platform.b2ctelcoaddon.controllers.pages.checkout.steps.DeliveryMethodCheckoutStepController {

  private static final String DELIVERY_METHOD = "delivery-method";
  private static final String CHECKOUT_STEP_NUMBER = "checkoutStepNumber";
  private static final String CHECKOUT_STEPS = "checkoutSteps";
  private static final String PAGE_TYPE = "pageType";

  @RequestMapping(value = "/choose", method = RequestMethod.GET)
  @RequireHardLogIn
  @Override
  @PreValidateCheckoutStep(checkoutStep = DELIVERY_METHOD)
  public String enterStep(final Model model, final RedirectAttributes redirectAttributes)
      throws CMSItemNotFoundException {
    super.enterStep(model, redirectAttributes);
    setCheckoutStepNumber(model);
    model.addAttribute(PAGE_TYPE, PageType.CHECKOUT_DELIVERY_METHOD.name());
    return CHOOSE_DELIVERY_METHOD_PAGE;
  }

  private void setCheckoutStepNumber(Model model) {
    List<CheckoutSteps> checkoutSteps = (List) model.asMap().get(CHECKOUT_STEPS);
    checkoutSteps.stream().filter(step -> step.getProgressBarId().equals(getCheckoutStep().getProgressBarId()))
        .findAny().ifPresent(found ->
                                 model.addAttribute(CHECKOUT_STEP_NUMBER, found.getStepNumber())
    );
  }

}
