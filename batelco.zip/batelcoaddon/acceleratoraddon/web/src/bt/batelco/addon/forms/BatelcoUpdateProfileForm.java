package bt.batelco.addon.forms;

import de.hybris.platform.acceleratorstorefrontcommons.forms.UpdateProfileForm;

/**
 * Form bean for updating profile.
 */
public class BatelcoUpdateProfileForm extends UpdateProfileForm {

  private String cprId;
  private String phone;

  public String getCprId() {
    return cprId;
  }

  public void setCprId(String cprId) {
    this.cprId = cprId;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }
}
