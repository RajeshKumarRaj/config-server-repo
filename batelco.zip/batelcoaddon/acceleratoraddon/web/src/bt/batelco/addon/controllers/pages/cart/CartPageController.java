package bt.batelco.addon.controllers.pages.cart;

import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CART_ACQUISITION_FORM_MISSING_ERROR;
import static bt.batelco.addon.constants.BatelcoaddonWebConstants.CART_REQUIRED_DOCUMENTS_ERROR;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import bt.batelco.addon.controllers.FileProcessor;
import bt.batelco.addon.forms.FileUploadForm;
import bt.batelco.facades.cart.BatelcoCartFacade;
import bt.batelco.facades.customer.BatelcoCustomerFacade;
import bt.batelco.facades.fileupload.FileUploadFacade;
import de.hybris.platform.acceleratorfacades.flow.impl.SessionOverrideCheckoutFlowFacade;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.UpdateQuantityForm;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.data.CartModificationData;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.jalo.JaloObjectNoLongerValidException;

import de.hybris.platform.commercefacades.user.data.CustomerData;

@Controller
@RequestMapping(value = "/cart")
public class CartPageController extends de.hybris.platform.b2ctelcoaddon.controllers.pages.CartPageController {

  private static final Logger LOG = LoggerFactory.getLogger(CartPageController.class);
  private static final String SHOW_CPR_UPLOAD = "showCprUpload";
  private static final String CPR_MIME_TYPES = "cprMimeTypes";
  private static final String ACQUISITION_FORM_MIME_TYPES = "acquisitionFormMimeTypes";
  
  private static final String CUSTOMERDATAINCART = "customerDataInCart";

  @Resource(name = "cartFacade")
  private BatelcoCartFacade batelcoCartFacade;

  @Resource(name = "fileProcessor")
  private FileProcessor fileProcessor;

  @Resource(name = "fileUploadFacade")
  private FileUploadFacade fileUploadFacade;
  
  @Resource(name = "batelcoCustomerFacade")
  private BatelcoCustomerFacade customerFacade;


  @Override
  @RequestMapping(method = RequestMethod.GET)
  public String showCart(Model model) throws CMSItemNotFoundException {
	  
	CustomerData customerData = customerFacade.getCurrentCustomer();
	String customerId = customerData.getCustomerId();
	String idType = customerFacade.getIdType(customerId);
	customerData.setIdType(idType);
	  
    model.addAttribute(SHOW_CPR_UPLOAD, getBatelcoCartFacade().hasEntryWithAcquisitionForm());
    model.addAttribute(CPR_MIME_TYPES, fileUploadFacade.getAllCprMimeTypes());
    model.addAttribute(ACQUISITION_FORM_MIME_TYPES, fileUploadFacade.getAllAcquisitionFormMimeTypes());
    model.addAttribute(CUSTOMERDATAINCART, customerData);
	model.addAttribute("metaRobots", "noindex,follow");
    return super.showCart(model);
  }

  @Override
  @RequestMapping(value = "/checkout", method = RequestMethod.GET)
  @RequireHardLogIn
  public String cartCheck(final Model model, final RedirectAttributes redirectModel) {
    SessionOverrideCheckoutFlowFacade.resetSessionOverrides();

    if (!getCartFacade().hasEntries()) {
      LOG.debug("Missing or empty cart");
      return REDIRECT_TO_CART_URL;
    }

    if (!batelcoCartFacade.isAcquisitionFormConfiguredOnEntries()) {
      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
                                     CART_ACQUISITION_FORM_MISSING_ERROR, null);
      return REDIRECT_TO_CART_URL;
    }

    if (!batelcoCartFacade.hasAllRequiredDocuments()) {
      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
                                     CART_REQUIRED_DOCUMENTS_ERROR, null);
      return REDIRECT_TO_CART_URL;
    }

    if (validateCart(redirectModel)) {
      return REDIRECT_TO_CART_URL;
    }

    return REDIRECT_PREFIX + "/checkout";
  }

  @ResponseBody
  @RequestMapping(value = "/upload/acquisition-form/{entryNumber:.*}", method = RequestMethod.POST)
  public ResponseEntity<String> handleAcquisitionFormUpload(@PathVariable("entryNumber") final int entryNumber,
                                                            @ModelAttribute("fileUploadForm") final FileUploadForm form) {
    return fileProcessor.processForm(form, fileUploadFacade.getAcquisitionFormMaxSize(), inputStream -> fileUploadFacade
        .attachAcquisitionForm(form.getFile(), inputStream, entryNumber));
  }

  @ResponseBody
  @RequestMapping(value = "/upload/cpr/front", method = RequestMethod.POST)
  public ResponseEntity<String> handleCprFrontUpload(@ModelAttribute("fileUploadForm") final FileUploadForm form) {
    return fileProcessor.processForm(form, fileUploadFacade.getCprMaxSize(),
                                     inputStream -> fileUploadFacade.attachCprFront(form.getFile(), inputStream));
  }

  @ResponseBody
  @RequestMapping(value = "/upload/cpr/back", method = RequestMethod.POST)
  public ResponseEntity<String> handleCprBackUpload(@ModelAttribute("fileUploadForm") final FileUploadForm form) {
    return fileProcessor.processForm(form, fileUploadFacade.getCprMaxSize(),
                                     inputStream -> fileUploadFacade.attachCprBack(form.getFile(), inputStream));
  }

  /**
   * Update the quantity of the group
   *
   * @param groupNumber   the bundle group number
   * @param model         page model to be populated with information
   * @param form          update quantity form specifying the new quantity of the product from the entry with the number
   *                      given
   * @param bindingResult request binding result to retrieve validation errors from
   * @param request       http request to retrieve the url from
   * @param redirectModel redirect model to be populated with information
   * @return the url to the result page
   * @throws CMSItemNotFoundException if the CmsPage cannot be found, while populating the model with meta data or title
   *                                  information
   */
  @RequestMapping(value = "/bundle/update", method = RequestMethod.POST)
  public String updateBundleQuantities(@RequestParam("groupNumber") final int groupNumber, final Model model,
                                       @Valid final UpdateQuantityForm form, final BindingResult bindingResult,
                                       final HttpServletRequest request,
                                       final RedirectAttributes redirectModel) throws CMSItemNotFoundException {
    if (bindingResult.hasErrors()) {
      populatePageModelWithErrors(model, bindingResult);
    }

    if (!getCartFacade().hasEntries()) {
      prepareDataForPage(model);
      return REDIRECT_TO_CART_URL;
    }

    Map<Integer, Long> entries = batelcoCartFacade.getEntriesFromGroup(getCartFacade().getSessionCart(), groupNumber);

    if (entries.isEmpty()) {
      prepareDataForPage(model);
      return REDIRECT_TO_CART_URL;
    }

    boolean successUpdateFlag = true;
    for (Map.Entry<Integer, Long> groupEntry : entries.entrySet()) {
      try {
        final long newQuantity = form.getQuantity();
        final CartModificationData cartModification = getCartFacade().updateCartEntry(groupEntry.getKey(), newQuantity);

        if (cartModification.getQuantity() != newQuantity) {
          handleUpdateQuantityFailure(newQuantity, request, redirectModel, cartModification);
          batelcoCartFacade.checkRevertQuantityUpdate(entries);
          successUpdateFlag = false;
          break;
        }

      } catch (final JaloObjectNoLongerValidException | CommerceCartModificationException ex) {
        LOG.warn("Could not update quantity of product with entry number: {}.", groupEntry.getKey(), ex);
        batelcoCartFacade.checkRevertQuantityUpdate(entries);
        successUpdateFlag = false;
        break;

      } catch (final IllegalArgumentException e) {
        LOG.error("An error occurred while trying to update the quantity {}", e);
        if (e.getMessage().matches(SUBSCRIPTION_PRODUCT_ERROR_REGEX)) {
          GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
                                         SUBSCRIPTION_PRODUCT_BASKET_ERROR, new Object[]
                                             {form.getQuantity()});
        }

        batelcoCartFacade.checkRevertQuantityUpdate(entries);
        successUpdateFlag = false;
        break;
      }
    }

    if (successUpdateFlag) {
      GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, BASKET_UPDATE_MESSAGE);
    }

    prepareDataForPage(model);
    return REDIRECT_TO_CART_URL;
  }

  protected BatelcoCartFacade getBatelcoCartFacade() {
    return batelcoCartFacade;
  }
}
