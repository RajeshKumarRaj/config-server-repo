package bt.batelco.addon.component.renderer;

import de.hybris.platform.acceleratorcms.model.components.SearchBoxComponentModel;
import de.hybris.platform.b2ctelcoaddon.component.renderer.SearchBoxComponentRenderer;

import bt.batelco.addon.constants.BatelcoaddonConstants;


/**
 * Renderer for mini cart component - it shows only the total items count
 */
public class BatelcoSearchBoxComponentRenderer<C extends SearchBoxComponentModel>
    extends SearchBoxComponentRenderer<C> {
  @Override
  protected String getAddonUiExtensionName(final C component) {
    return BatelcoaddonConstants.EXTENSIONNAME;
  }
}
