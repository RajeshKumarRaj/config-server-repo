package bt.batelco.addon.populator;

import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import bt.batelco.addon.forms.BatelcoRegisterForm;

/**
 * Populator for register data from register form
 */
public class BatelcoRegisterDataPopulator implements Populator<BatelcoRegisterForm, RegisterData> {

  @Override
  public void populate(BatelcoRegisterForm form, RegisterData data) throws ConversionException {
    data.setFirstName(form.getFirstName());
    data.setLastName(form.getLastName());
    data.setLogin(form.getEmail());
    data.setPassword(form.getPwd());
    data.setCprId(form.getCprId());
    data.setPhone(form.getPhone());
    data.setCountryCode(form.getCountry());
    data.setCity(form.getCity());
    data.setAddressLine1(form.getAddressLine1());
    data.setAddressLine2(form.getAddressLine2());
    data.setZipCode(form.getZipCode());
  }
}
