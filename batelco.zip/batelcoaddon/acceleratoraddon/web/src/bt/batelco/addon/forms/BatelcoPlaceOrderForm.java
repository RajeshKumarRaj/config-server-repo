package bt.batelco.addon.forms;

import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.PlaceOrderForm;

public class BatelcoPlaceOrderForm extends PlaceOrderForm {
  private ConsentForm termsConsent;

  public ConsentForm getTermsConsent() {
    return termsConsent;
  }

  public void setTermsConsent(ConsentForm termsConsent) {
    this.termsConsent = termsConsent;
  }
}
