package bt.batelco.addon.checkout.steps.validation.impl;

import de.hybris.platform.acceleratorfacades.flow.CheckoutFlowFacade;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.validation.AbstractCheckoutStepValidator;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.validation.ValidationResults;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.storefront.checkout.steps.validation.impl.DefaultSummaryCheckoutStepValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public class DefaultBatelcoSummaryCheckoutStepValidator extends AbstractCheckoutStepValidator {
  private static final Logger LOG = LoggerFactory.getLogger(DefaultSummaryCheckoutStepValidator.class); // NOSONAR
  private static final String NO_DELIVERY_ADDRESS_ERROR_CODE = "checkout.multi.deliveryAddress.notprovided";
  private static final String NO_DELIVERY_METHOD_ERROR_CODE = "checkout.multi.deliveryMethod.notprovided";
  private static final String NO_PAYMENT_DETAILS_ERROR_CODE = "checkout.multi.paymentDetails.notprovided";
  private static final String PICKUP_DELIVERY_CODE = "pickup";

  @Override
  public ValidationResults validateOnEnter(final RedirectAttributes redirectAttributes) {
    final ValidationResults checkoutFlow = validateCheckoutFlow(redirectAttributes);
    if (checkoutFlow != null) {
      return checkoutFlow;
    }

    final CartData cartData = getCheckoutFacade().getCheckoutCart();

    if (!getCheckoutFacade().hasShippingItems()) {
      cartData.setDeliveryAddress(null);
    }

    if (!getCheckoutFacade().hasPickUpItems() && PICKUP_DELIVERY_CODE.equals(cartData.getDeliveryMode().getCode())) {
      return ValidationResults.REDIRECT_TO_PICKUP_LOCATION;
    }

    if (cartData.getPreorder() && cartData.isPreorderFee() && cartData.getPaymentEvidence() == null) {
      return ValidationResults.REDIRECT_TO_PAYMENT_METHOD;
    }

    return ValidationResults.SUCCESS;
  }

  private ValidationResults validateCheckoutFlow(final RedirectAttributes redirectAttributes) {
    final CheckoutFlowFacade checkoutFlowFacade = getCheckoutFlowFacade();
    if (!checkoutFlowFacade.hasValidCart()) {
      LOG.info("Missing, empty or unsupported cart");
      return ValidationResults.REDIRECT_TO_CART;
    }

    if (checkoutFlowFacade.hasNoDeliveryAddress()) {
      GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.INFO_MESSAGES_HOLDER,
              NO_DELIVERY_ADDRESS_ERROR_CODE);
      return ValidationResults.REDIRECT_TO_DELIVERY_ADDRESS;
    }

    if (checkoutFlowFacade.hasNoDeliveryMode()) {
      GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.INFO_MESSAGES_HOLDER,
              NO_DELIVERY_METHOD_ERROR_CODE);
      return ValidationResults.REDIRECT_TO_DELIVERY_METHOD;
    }

    if (checkoutFlowFacade.hasNoPaymentInfo()) {
      GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.INFO_MESSAGES_HOLDER,
              NO_PAYMENT_DETAILS_ERROR_CODE);
      return ValidationResults.REDIRECT_TO_PAYMENT_METHOD;
    }
    return null;
  }
}
